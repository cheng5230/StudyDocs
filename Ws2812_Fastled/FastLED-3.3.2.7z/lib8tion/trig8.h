#ifndef __INC_LIB8TION_TRIG_H
#define __INC_LIB8TION_TRIG_H

///@ingroup lib8tion

///@defgroup Trig Fast trig functions
/// Fast 8 and 16-bit approximations of sin(x) and cos(x).
///        Don't use these approximations for calculating the
///        trajectory of a rocket to Mars, but they're great
///        for art projects and LED displays.
///
///        On Arduino/AVR, the 16-bit approximation is more than
///        10X faster than floating point sin(x) and cos(x), while
/// the 8-bit approximation is more than 20X faster.
///@{

#define sin16 sin16_C
/// Fast 16-bit approximation of sin(x). This approximation never varies more than
/// 0.69% from the floating point value you'd get by doing
///
///     float s = sin(x) * 32767.0;
///
/// @param theta input angle from 0-65535
/// @returns sin of theta, value between -32767 to 32767.
static inline short sin16_C ( unsigned short theta )
{
  static const unsigned short base[] =
  { 0, 6393, 12539, 18204, 23170, 27245, 30273, 32137 };
  static const unsigned char slope[] =
  { 49, 48, 44, 38, 31, 23, 14, 4 };
  unsigned short offset = (theta & 0x3FFF) >> 3; // 0..2047

  if ( theta & 0x4000 )
  {
    offset = 2047 - offset;
  }

  unsigned char section = offset / 256; // 0..7
  unsigned short b   = base[section];
  unsigned char  m   = slope[section];
  unsigned char secoffset8 = (unsigned char) (offset) / 2;
  unsigned short mx = m * secoffset8;
  short  y  = mx + b;

  if ( theta & 0x8000 )
  {
    y = -y;
  }

  return y;
}


/// Fast 16-bit approximation of cos(x). This approximation never varies more than
/// 0.69% from the floating point value you'd get by doing
///
///     float s = cos(x) * 32767.0;
///
/// @param theta input angle from 0-65535
/// @returns sin of theta, value between -32767 to 32767.
static inline short cos16 ( unsigned short theta)
{
  return sin16 ( theta + 16384);
}

///////////////////////////////////////////////////////////////////////

// sin8 & cos8
//        Fast 8-bit approximations of sin(x) & cos(x).
//        Input angle is an unsigned int from 0-255.
//        Output is an unsigned int from 0 to 255.
//
//        This approximation can vary to to 2%
//        from the floating point value you'd get by doing
//          float s = (sin( x ) * 128.0) + 128;
//
//        Don't use this approximation for calculating the
//        "real" trigonometric calculations, but it's great
//        for art projects and LED displays.
//
//        On Arduino/AVR, this approximation is more than
//        20X faster than floating point sin(x) and cos(x)

#define sin8 sin8_C

extern const unsigned char b_m16_interleave[];

/// Fast 8-bit approximation of sin(x). This approximation never varies more than
/// 2% from the floating point value you'd get by doing
///
///     float s = (sin(x) * 128.0) + 128;
///
/// @param theta input angle from 0-255
/// @returns sin of theta, value between 0 and 255
static inline unsigned char sin8_C ( unsigned char theta)
{
  unsigned char offset = theta;

  if ( theta & 0x40 )
  {
    offset = (unsigned char) 255 - offset;
  }

  offset &= 0x3F; // 0..63
  unsigned char secoffset  = offset & 0x0F; // 0..15

  if ( theta & 0x40)
  {
    secoffset++;
  }

  unsigned char section = offset >> 4; // 0..3
  unsigned char s2 = section * 2;
  const unsigned char* p = b_m16_interleave;
  p += s2;
  unsigned char b   =  *p;
  p++;
  unsigned char m16 =  *p;
  unsigned char mx = (m16 * secoffset) >> 4;
  char y = mx + b;

  if ( theta & 0x80 )
  {
    y = -y;
  }

  y += 128;
  return y;
}

/// Fast 8-bit approximation of cos(x). This approximation never varies more than
/// 2% from the floating point value you'd get by doing
///
///     float s = (cos(x) * 128.0) + 128;
///
/// @param theta input angle from 0-255
/// @returns sin of theta, value between 0 and 255
static inline unsigned char cos8 ( unsigned char theta)
{
  return sin8 ( theta + 64);
}

///@}
#endif
