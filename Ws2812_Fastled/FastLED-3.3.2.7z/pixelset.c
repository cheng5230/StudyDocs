
#include "pixelset.h"
#include <stdio.h>


void CPixelView_dump(CPixelView* c_this)
{
  printf("len: %d, dir:%d, range:%x-%x, diff:%d",c_this->len, (int)(c_this->dir), (unsigned int)(c_this->leds), (unsigned int)(c_this->end_pos), (int)(c_this->end_pos - c_this->leds));
}


