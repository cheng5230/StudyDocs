#ifndef SMARTMATRIX_V4_H
#define SMARTMATRIX_V4_H

#define V4HEADER 1
#include "SmartMatrix3.h"

#endif
