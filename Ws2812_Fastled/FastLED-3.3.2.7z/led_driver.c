#include "tuya_device.h"
#include "spi_api.h"
#include "spi_ex_api.h"
#include "gpio_api.h"
#include "led_driver.h"
#include "pixeltypes.h"
#include "Blink_demo.h"


///@file chipsets.h
/// contains the bulk of the definitions for the various LED chipsets supported.
unsigned char _myfront_buf[DATA_BUF_SIZE];
unsigned char _myc = 0;
unsigned char _myw = 0;
MUTEX_HANDLE spidata_mutex;
BOOL_T upload_flag = FALSE;
spi_t spidma_master;
gpio_t gpiodma_spi;
unsigned char __is_driver_busy = 0;
unsigned int  _myfront_len;

/*** SPI DMA 中断发送函数 ***/
void master_spi_done_callback(void *pdata, SpiIrq event)
{
    switch(event){
        case SpiTxIrq:
            PR_NOTICE("Master TX done!\n");
            __is_driver_busy = 0;
            break;
        default:
          break;
            //PR_NOTICE("unknown interrput evnent!\n");
    }
}

OPERATE_RET spi_IoInit(void)
{
  gpio_init(&gpiodma_spi, SPI1_MOSI);
  gpio_set(SPI1_MOSI);
  gpio_mode(&gpiodma_spi, PullNone);     // No pull
  gpio_dir(&gpiodma_spi, PIN_OUTPUT);    // Direction: Output

  spidma_master.spi_idx=MBED_SPI1;
  spi_init(&spidma_master, SPI1_MOSI, SPI1_MISO, SPI1_SCLK, SPI1_CS);
  spi_frequency(&spidma_master, SCLK_FREQ_TEST);
  spi_format(&spidma_master,8,3,0);  
  spi_irq_hook(&spidma_master,(spi_irq_handler) master_spi_done_callback, (uint32_t)&spidma_master);
  PR_NOTICE("spi_led done!\n");
}


void spi_DmaInit(void)
{
    gpio_init(&gpiodma_spi, SPI1_MOSI);
    gpio_set(SPI1_MOSI);
    gpio_mode(&gpiodma_spi, PullNone);     // No pull
    gpio_dir(&gpiodma_spi, PIN_OUTPUT);    // Direction: Output

    spidma_master.spi_idx=MBED_SPI1;
    spi_init(&spidma_master, SPI1_MOSI, SPI1_MISO, SPI1_SCLK, SPI1_CS);
    spi_frequency(&spidma_master, SCLK_FREQ_TEST);
    spi_format(&spidma_master,8,3,0);  
    //spi_irq_hook(&spi_master,(spi_irq_handler) master_spi_done_callback, (uint32_t)&spi_master);
    PR_NOTICE("spi_dma done!\n");
}


STATIC void led_send_thread (PVOID pArg)
{
  BOOL_T flag;

  while(1)
  {
    flag = upload_flag;
    if(flag)
    {
        //MutexLock (spidata_mutex);    
        //MutexUnLock (spidata_mutex);
        upload_flag = FALSE;
        while(__is_driver_busy == 1);       //等待上一次数据发完
        __is_driver_busy = 1;
        PR_NOTICE("--------------------- %d %x %x %x %x\n",_myfront_len,_myfront_buf[0], _myfront_buf[1], _myfront_buf[2],_myfront_buf[3]);
        spi_master_write_stream_dma(&spidma_master, _myfront_buf, _myfront_len); 
        //spi_master_write_stream_dma(&spi_master, _myfront_buf, DATA_BUF_SIZE);  
    }
    else
    {
      SystemSleep(10);
    }
  }
}


void FastLedShow(void)
{
  BOOL_T flag;
  flag = upload_flag;
  PR_DEBUG("----------- %x %d",upload_flag,__is_driver_busy);
  if(flag)
  {
      upload_flag = FALSE;
      while(__is_driver_busy == 1);       //等待上一次数据发完
      __is_driver_busy = 1;
      spi_master_write_stream_dma(&spidma_master, _myfront_buf, _myfront_len); 
  }
}

void Fastled_ReadData(uint8_t *buf , uint16_t offset)
{
    // SPI 数据发送
    uint16_t len,index;
    #if LIGHT_DEFALT_RGB_or_GRB
      len  = (offset)*4;
      _myfront_buf[len]   =  ((buf[offset]&0x80)==0x80)? H_BIT_1 : H_BIT_0;
      _myfront_buf[len]   |= ((buf[offset]&0x40)==0x40)? L_BIT_1 : L_BIT_0;
      _myfront_buf[len+1] =  ((buf[offset]&0x20)==0x20)? H_BIT_1 : H_BIT_0;
      _myfront_buf[len+1] |= ((buf[offset]&0x10)==0x10)? L_BIT_1 : L_BIT_0;
      _myfront_buf[len+2] =  ((buf[offset]&0x08)==0x08)? H_BIT_1 : H_BIT_0;
      _myfront_buf[len+2] |= ((buf[offset]&0x04)==0x04)? L_BIT_1 : L_BIT_0;
      _myfront_buf[len+3] =  ((buf[offset]&0x02)==0x02)? H_BIT_1 : H_BIT_0;
      _myfront_buf[len+3] |= ((buf[offset]&0x01)==0x01)? L_BIT_1 : L_BIT_0;
   #else
        #if LIGHT_WS2812_RGBC_BALL
          len  = (offset)*4;
          index = (offset/3)*12;
          len = len + index;
          
          _myfront_buf[len]   =  ((buf[offset]&0x80)==0x80)? H_BIT_1 : H_BIT_0;
          _myfront_buf[len]   |= ((buf[offset]&0x40)==0x40)? L_BIT_1 : L_BIT_0;
          _myfront_buf[len+1] =  ((buf[offset]&0x20)==0x20)? H_BIT_1 : H_BIT_0;
          _myfront_buf[len+1] |= ((buf[offset]&0x10)==0x10)? L_BIT_1 : L_BIT_0;
          _myfront_buf[len+2] =  ((buf[offset]&0x08)==0x08)? H_BIT_1 : H_BIT_0;
          _myfront_buf[len+2] |= ((buf[offset]&0x04)==0x04)? L_BIT_1 : L_BIT_0;
          _myfront_buf[len+3] =  ((buf[offset]&0x02)==0x02)? H_BIT_1 : H_BIT_0;
          _myfront_buf[len+3] |= ((buf[offset]&0x01)==0x01)? L_BIT_1 : L_BIT_0;

         if((len+4)%12==0)
         {
            //w
            _myfront_buf[(len+4)+0] =  ((_myc&0x80)==0x80)? H_BIT_1 : H_BIT_0;
            _myfront_buf[(len+4)+0] |= ((_myc&0x40)==0x40)? L_BIT_1 : L_BIT_0;
            _myfront_buf[(len+4)+1] =  ((_myc&0x20)==0x20)? H_BIT_1 : H_BIT_0;
            _myfront_buf[(len+4)+1] |= ((_myc&0x10)==0x10)? L_BIT_1 : L_BIT_0;
            _myfront_buf[(len+4)+2] =  ((_myc&0x08)==0x08)? H_BIT_1 : H_BIT_0;
            _myfront_buf[(len+4)+2] |= ((_myc&0x04)==0x04)? L_BIT_1 : L_BIT_0;
            _myfront_buf[(len+4)+3] =  ((_myc&0x02)==0x02)? H_BIT_1 : H_BIT_0;
            _myfront_buf[(len+4)+3] |= ((_myc&0x01)==0x01)? L_BIT_1 : L_BIT_0;

            //0 -- 0xff
            _myfront_buf[(len+4)+4] =  H_BIT_1 ;
            _myfront_buf[(len+4)+4] |= L_BIT_1 ;
            _myfront_buf[(len+4)+5] =  H_BIT_1 ;
            _myfront_buf[(len+4)+5] |= L_BIT_1 ;
            _myfront_buf[(len+4)+6] =  H_BIT_1 ;
            _myfront_buf[(len+4)+6] |= L_BIT_1 ;
            _myfront_buf[(len+4)+7] =  H_BIT_1 ;
            _myfront_buf[(len+4)+7] |= L_BIT_1 ;
            //0 - 0xff
            _myfront_buf[(len+4)+8] =  H_BIT_1 ;
            _myfront_buf[(len+4)+8] |= L_BIT_1 ;
            _myfront_buf[(len+4)+9] =  H_BIT_1 ;
            _myfront_buf[(len+4)+9] |= L_BIT_1 ;
            _myfront_buf[(len+4)+10] =  H_BIT_1 ;
            _myfront_buf[(len+4)+10] |= L_BIT_1 ;
            _myfront_buf[(len+4)+11] =  H_BIT_1 ;
            _myfront_buf[(len+4)+11] |= L_BIT_1 ; 
         }
        #else
         len  = (offset)*4;
         _myfront_buf[len]   =  ((buf[offset]&0x80)==0x80)? H_BIT_1 : H_BIT_0;
         _myfront_buf[len]   |= ((buf[offset]&0x40)==0x40)? L_BIT_1 : L_BIT_0;
         _myfront_buf[len+1] =  ((buf[offset]&0x20)==0x20)? H_BIT_1 : H_BIT_0;
         _myfront_buf[len+1] |= ((buf[offset]&0x10)==0x10)? L_BIT_1 : L_BIT_0;
         _myfront_buf[len+2] =  ((buf[offset]&0x08)==0x08)? H_BIT_1 : H_BIT_0;
         _myfront_buf[len+2] |= ((buf[offset]&0x04)==0x04)? L_BIT_1 : L_BIT_0;
         _myfront_buf[len+3] =  ((buf[offset]&0x02)==0x02)? H_BIT_1 : H_BIT_0;
         _myfront_buf[len+3] |= ((buf[offset]&0x01)==0x01)? L_BIT_1 : L_BIT_0;
        #endif
   #endif
}

void Ws2812_DriverInit(void)
{
    spi_DmaInit();
    spi_IoInit();
}

int is_led_busy(void)
{
   return upload_flag;
}

void set_driver_busy(void)
{
   upload_flag = 1;
}

void get_driver_len(int len)
{
   _myfront_len = len<<2;
}

// 设置全灯带显示所有颜色 
void SetAllColor(uint32_t colors,uint16_t len)
{
    uint8_t index;
    for(index = 0; index<len;index++)
    {
      RGB_SetOnePixelColor(leds,index,colors);
    }
    PostSemaphore(__ledShow);
    //CFastLED_show(&fast_led);
    //FastLedShow();
}

int spi_threadInit(void)
{
   OPERATE_RET op_ret = OPRT_OK;
   THRD_HANDLE thread_touch;

  //op_ret = CreateMutexAndInit (&spidata_mutex);

  //if (OPRT_OK != op_ret)
  //{
  //  PR_ERR ("CreateMutexAndInit err ");
  //} 
  
  op_ret = tuya_light_CreateAndStart(&thread_touch, led_send_thread, NULL,1024,TRD_PRIO_2,"ledsend_thread");
	if(op_ret != OPRT_OK) {
		PR_ERR("light_gpio_init err:%d",op_ret);
		return op_ret;
	}
}

