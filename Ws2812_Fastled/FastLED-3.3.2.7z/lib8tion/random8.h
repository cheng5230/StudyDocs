#ifndef __INC_LIB8TION_RANDOM_H
#define __INC_LIB8TION_RANDOM_H
///@ingroup lib8tion

///@defgroup Random Fast random number generators
/// Fast 8- and 16- bit unsigned random numbers.
///  Significantly faster than Arduino random(), but
///  also somewhat less random.  You can add entropy.
///@{

// X(n+1) = (2053 * X(n)) + 13849)
#define FASTLED_RAND16_2053  ((unsigned short)(2053))
#define FASTLED_RAND16_13849 ((unsigned short)(13849))

/// random number seed
extern unsigned short rand16seed;// = RAND16_SEED;

/// Generate an 8-bit random number
static inline unsigned char random8()
{
  rand16seed = (rand16seed * FASTLED_RAND16_2053) + FASTLED_RAND16_13849;
  // return the sum of the high and low bytes, for better
  //  mixing and non-sequential correlation
  return (unsigned char) ( ( (unsigned char) (rand16seed & 0xFF) ) +
                           ( (unsigned char) (rand16seed >> 8) ) );
}

/// Generate a 16 bit random number
static inline unsigned short random16()
{
  rand16seed = (rand16seed * FASTLED_RAND16_2053) + FASTLED_RAND16_13849;
  return rand16seed;
}

/// Generate an 8-bit random number between 0 and lim
/// @param lim the upper bound for the result
static inline unsigned char random8_lim (unsigned char lim)
{
  unsigned char r = random8();
  r = (r*lim) >> 8;
  return r;
}

/// Generate an 8-bit random number in the given range
/// @param min the lower bound for the random number
/// @param lim the upper bound for the random number
static inline unsigned char random8_min_lim (unsigned char min, unsigned char lim)
{
  unsigned char delta = lim - min;
  unsigned char r = random8_lim (delta) + min;
  return r;
}

/// Generate an 16-bit random number between 0 and lim
/// @param lim the upper bound for the result
static inline unsigned short random16_lim ( unsigned short lim)
{
  unsigned short r = random16();
  unsigned int p = (unsigned int) lim * (unsigned int) r;
  r = p >> 16;
  return r;
}

/// Generate an 16-bit random number in the given range
/// @param min the lower bound for the random number
/// @param lim the upper bound for the random number
static inline unsigned short random16_min_lim ( unsigned short min, unsigned short lim)
{
  unsigned short delta = lim - min;
  unsigned short r = random16_lim ( delta) + min;
  return r;
}

/// Set the 16-bit seed used for the random number generator
static inline void random16_set_seed ( unsigned short seed)
{
  rand16seed = seed;
}

/// Get the current seed value for the random number generator
static inline unsigned short random16_get_seed()
{
  return rand16seed;
}

/// Add entropy into the random number generator
static inline void random16_add_entropy ( unsigned short entropy)
{
  rand16seed += entropy;
}

///@}

#endif
