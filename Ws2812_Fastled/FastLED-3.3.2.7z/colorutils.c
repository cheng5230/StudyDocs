#include <math.h>
#include "fastled_config.h"
#include "pixeltypes.h"
#include "color.h"
#include "colorutils.h"

void fill_solid_rgb ( CRGB* leds, int numToFill,
                  CRGB color)
{
  for ( int i = 0; i < numToFill; i++)
  {
    leds[i] = color;
  }
}

void fill_solid_hsv ( CHSV* targetArray, int numToFill,
                  CHSV hsvColor)
{
  for ( int i = 0; i < numToFill; i++)
  {
    targetArray[i] = hsvColor;
  }
}


// void fill_solid( CRGB* targetArray, int numToFill,
//         CHSV hsvColor)
// {
//  fill_solid<CRGB>( targetArray, numToFill, (CRGB) hsvColor);
// }

void fill_rainbow_rgb ( CRGB* pFirstLED, int numToFill,
                    unsigned char initialhue,
                    unsigned char deltahue )
{
  CHSV hsv;
  hsv.h = initialhue;
  hsv.v = 255;
  hsv.s = 240;

  for ( int i = 0; i < numToFill; i++)
  {
    RGB_initByHSV(pFirstLED + i, hsv);
    hsv.h += deltahue;
  }
}

void fill_rainbow_hsv ( CHSV* targetArray, int numToFill,
                    unsigned char initialhue,
                    unsigned char deltahue )
{
  CHSV hsv;
  hsv.h = initialhue;
  hsv.v = 255;
  hsv.s = 240;

  for ( int i = 0; i < numToFill; i++)
  {
    targetArray[i] = hsv;
    hsv.h += deltahue;
  }
}

#define saccum87 short

/// fill_gradient_rgb_hsv - fill an array of colors with a smooth HSV gradient
/// between two specified HSV colors.
/// Since 'hue' is a value around a color wheel,
/// there are always two ways to sweep from one hue
/// to another.
/// This function lets you specify which way you want
/// the hue gradient to sweep around the color wheel:
///
///     FORWARD_HUES: hue always goes clockwise
///     BACKWARD_HUES: hue always goes counter-clockwise
///     SHORTEST_HUES: hue goes whichever way is shortest
///     LONGEST_HUES: hue goes whichever way is longest
///
/// The default is SHORTEST_HUES, as this is nearly
/// always what is wanted.
///
/// fill_gradient_rgb_hsv can write the gradient colors EITHER
///     (1) into an array of CRGBs (e.g., into leds[] array, or an RGB Palette)
///   OR
///     (2) into an array of CHSVs (e.g. an HSV Palette).
///
///   In the case of writing into a CRGB array, the gradient is
///   computed in HSV space, and then HSV values are converted to RGB
///   as they're written into the RGB array.
//default directionCode  = SHORTEST_HUES, ********default value************
void fill_gradient_rgb_hsv ( void* targetArray,
                             unsigned short startpos, CHSV startcolor,
                             unsigned short endpos,   CHSV endcolor,
                             TGradientDirectionCode directionCode, char is_rgb_array )
{
  // if the points are in the wrong order, straighten them
  if ( endpos < startpos )
  {
    unsigned short t = endpos;
    CHSV tc = endcolor;
    endcolor = startcolor;
    endpos = startpos;
    startpos = t;
    startcolor = tc;
  }

  // If we're fading toward black (val=0) or white (sat=0),
  // then set the endhue to the starthue.
  // This lets us ramp smoothly to black or white, regardless
  // of what 'hue' was set in the endcolor (since it doesn't matter)
  if ( endcolor.v == 0 || endcolor.s == 0)
  {
    endcolor.h = startcolor.h;
  }

  // Similarly, if we're fading in from black (val=0) or white (sat=0)
  // then set the starthue to the endhue.
  // This lets us ramp smoothly up from black or white, regardless
  // of what 'hue' was set in the startcolor (since it doesn't matter)
  if ( startcolor.v == 0 || startcolor.s == 0)
  {
    startcolor.h = endcolor.h;
  }

  saccum87 huedistance87;
  saccum87 satdistance87;
  saccum87 valdistance87;
  satdistance87 = (endcolor.s - startcolor.s) << 7;
  valdistance87 = (endcolor.v - startcolor.v) << 7;
  unsigned char huedelta8 = endcolor.h - startcolor.h;

  if ( directionCode == SHORTEST_HUES )
  {
    directionCode = FORWARD_HUES;

    if ( huedelta8 > 127)
    {
      directionCode = BACKWARD_HUES;
    }
  }

  if ( directionCode == LONGEST_HUES )
  {
    directionCode = FORWARD_HUES;

    if ( huedelta8 < 128)
    {
      directionCode = BACKWARD_HUES;
    }
  }

  if ( directionCode == FORWARD_HUES)
  {
    huedistance87 = huedelta8 << 7;
  }
  else /* directionCode == BACKWARD_HUES */
  {
    huedistance87 = (unsigned char) (256 - huedelta8) << 7;
    huedistance87 = -huedistance87;
  }

  unsigned short pixeldistance = endpos - startpos;
  short divisor = pixeldistance ? pixeldistance : 1;
  saccum87 huedelta87 = huedistance87 / divisor;
  saccum87 satdelta87 = satdistance87 / divisor;
  saccum87 valdelta87 = valdistance87 / divisor;
  huedelta87 *= 2;
  satdelta87 *= 2;
  valdelta87 *= 2;
  accum88 hue88 = startcolor.h << 8;
  accum88 sat88 = startcolor.s << 8;
  accum88 val88 = startcolor.v << 8;

  for ( unsigned short i = startpos; i <= endpos; i++)
  {
    if (is_rgb_array == 1)
    {
      RGB_initBy_H_S_V( &(((CRGB*)targetArray)[i]), hue88 >> 8, sat88 >> 8, val88 >> 8);
    }
    else
    {
      ((CHSV*)targetArray)[i] = struct_HSV_by_h_s_v( hue88 >> 8, sat88 >> 8, val88 >> 8);
    }

    hue88 += huedelta87;
    sat88 += satdelta87;
    val88 += valdelta87;
  }
}


// Convenience functions to fill an array of colors with a
// two-color, three-color, or four-color gradient
//default directionCode = SHORTEST_HUES, *******default value***************                             
void fill_gradient_rgb_hsv_c1c2 ( void* targetArray, unsigned short numLeds, CHSV c1, CHSV c2,
                                  TGradientDirectionCode directionCode, char is_rgb_array)
{
  unsigned short last = numLeds - 1;
  fill_gradient_rgb_hsv ( targetArray, 0, c1, last, c2, directionCode, is_rgb_array);
}

//default directionCode = SHORTEST_HUES, *******default value*************** 
void fill_gradient_rgb_hsv_c1c2c3 ( void* targetArray, unsigned short numLeds,
                                    CHSV c1, CHSV c2, CHSV c3,
                                    TGradientDirectionCode directionCode, char is_rgb_array)
{
  unsigned short half = (numLeds / 2);
  unsigned short last = numLeds - 1;
  fill_gradient_rgb_hsv ( targetArray,    0, c1, half, c2, directionCode, is_rgb_array);
  fill_gradient_rgb_hsv ( targetArray, half, c2, last, c3, directionCode, is_rgb_array);
}

//default directionCode = SHORTEST_HUES, *******default value*************** 
void fill_gradient_rgb_hsv_c1c2c3c4 ( void* targetArray, unsigned short numLeds,
                                      CHSV c1, CHSV c2, CHSV c3, CHSV c4,
                                      TGradientDirectionCode directionCode, char is_rgb_array)
{
  unsigned short onethird = (numLeds / 3);
  unsigned short twothirds = ( (numLeds * 2) / 3);
  unsigned short last = numLeds - 1;
  fill_gradient_rgb_hsv ( targetArray,         0, c1,  onethird, c2, directionCode, is_rgb_array);
  fill_gradient_rgb_hsv ( targetArray,  onethird, c2, twothirds, c3, directionCode, is_rgb_array);
  fill_gradient_rgb_hsv ( targetArray, twothirds, c3,      last, c4, directionCode, is_rgb_array);
}


void fill_gradient_RGB ( CRGB* leds,
                         unsigned short startpos, CRGB startcolor,
                         unsigned short endpos,   CRGB endcolor )
{
  // if the points are in the wrong order, straighten them
  if ( endpos < startpos )
  {
    unsigned short t = endpos;
    CRGB tc = endcolor;
    endcolor = startcolor;
    endpos = startpos;
    startpos = t;
    startcolor = tc;
  }

  saccum87 rdistance87;
  saccum87 gdistance87;
  saccum87 bdistance87;
  rdistance87 = (endcolor.r - startcolor.r) << 7;
  gdistance87 = (endcolor.g - startcolor.g) << 7;
  bdistance87 = (endcolor.b - startcolor.b) << 7;
  unsigned short pixeldistance = endpos - startpos;
  short divisor = pixeldistance ? pixeldistance : 1;
  saccum87 rdelta87 = rdistance87 / divisor;
  saccum87 gdelta87 = gdistance87 / divisor;
  saccum87 bdelta87 = bdistance87 / divisor;
  rdelta87 *= 2;
  gdelta87 *= 2;
  bdelta87 *= 2;
  accum88 r88 = startcolor.r << 8;
  accum88 g88 = startcolor.g << 8;
  accum88 b88 = startcolor.b << 8;

  for ( unsigned short i = startpos; i <= endpos; i++)
  {
    leds[i].r = r88 >> 8;
    leds[i].g = g88 >> 8;
    leds[i].b = b88 >> 8;
    r88 += rdelta87;
    g88 += gdelta87;
    b88 += bdelta87;
  }
}

void fill_gradient_RGB_c1c2 ( CRGB* leds, unsigned short numLeds, CRGB c1, CRGB c2)
{
  unsigned short last = numLeds - 1;
  fill_gradient_RGB ( leds, 0, c1, last, c2);
}


void fill_gradient_RGB_c1c2c3 ( CRGB* leds, unsigned short numLeds, CRGB c1, CRGB c2, CRGB c3)
{
  unsigned short half = (numLeds / 2);
  unsigned short last = numLeds - 1;
  fill_gradient_RGB ( leds,    0, c1, half, c2);
  fill_gradient_RGB ( leds, half, c2, last, c3);
}

void fill_gradient_RGB_c1c2c3c4 ( CRGB* leds, unsigned short numLeds, CRGB c1, CRGB c2, CRGB c3,
                         CRGB c4)
{
  unsigned short onethird = (numLeds / 3);
  unsigned short twothirds = ( (numLeds * 2) / 3);
  unsigned short last = numLeds - 1;
  fill_gradient_RGB ( leds,         0, c1,  onethird, c2);
  fill_gradient_RGB ( leds,  onethird, c2, twothirds, c3);
  fill_gradient_RGB ( leds, twothirds, c3,      last, c4);
}

void nscale8_video ( CRGB* leds, unsigned short num_leds, unsigned char scale)
{
  for ( unsigned short i = 0; i < num_leds; i++)
  {  
    RGB_nscale8_video(&(leds[i]), scale);
  }
}

void fade_video (CRGB* leds, unsigned short num_leds, unsigned char fadeBy)
{
  nscale8_video ( leds, num_leds, 255 - fadeBy);
}

void fadeLightBy (CRGB* leds, unsigned short num_leds, unsigned char fadeBy)
{
  nscale8_video ( leds, num_leds, 255 - fadeBy);
}


void fadeToBlackBy ( CRGB* leds, unsigned short num_leds, unsigned char fadeBy)
{
  nscale8 ( leds, num_leds, 255 - fadeBy);
}

void fade_raw ( CRGB* leds, unsigned short num_leds, unsigned char fadeBy)
{
  nscale8 ( leds, num_leds, 255 - fadeBy);
}

void nscale8_raw ( CRGB* leds, unsigned short num_leds, unsigned char scale)
{
  nscale8 ( leds, num_leds, scale);
}

void nscale8 ( CRGB* leds, unsigned short num_leds, unsigned char scale)
{
  for ( unsigned short i = 0; i < num_leds; i++)
  {
    RGB_nscale8(&leds[i], scale);
  }
}

void fadeUsingColor ( CRGB* leds, unsigned short numLeds, CRGB colormask)
{
  unsigned char fr, fg, fb;
  fr = colormask.r;
  fg = colormask.g;
  fb = colormask.b;

  for ( unsigned short i = 0; i < numLeds; i++)
  {
    leds[i].r = scale8 ( leds[i].r, fr);
    leds[i].g = scale8 ( leds[i].g, fg);
    leds[i].b = scale8                 ( leds[i].b, fb);
  }
}

CRGB nblend ( CRGB existing, CRGB overlay, fract8 amountOfOverlay )
{
  if ( amountOfOverlay == 0)
  {
    return existing;
  }

  if ( amountOfOverlay == 255)
  {
    existing = overlay;
    return existing;
  }

  // Corrected blend method, with no loss-of-precision rounding errors
  existing.r   = blend8 ( existing.r,   overlay.r,   amountOfOverlay);
  existing.g = blend8 ( existing.g, overlay.g, amountOfOverlay);
  existing.b  = blend8 ( existing.b,  overlay.b,  amountOfOverlay);
  return existing;
}

void nblend_count ( CRGB* existing, CRGB* overlay, unsigned short count, fract8 amountOfOverlay)
{
  for ( unsigned short i = count; i; i--)
  {
    nblend ( *existing, *overlay, amountOfOverlay);
    existing++;
    overlay++;
  }
}

CRGB blend ( CRGB p1, CRGB p2, fract8 amountOfP2 )
{
  CRGB nu;
  RGB_initByRGB(&nu, p1);
  nblend ( nu, p2, amountOfP2);
  return nu;
}

CRGB* blend_count ( const CRGB* src1, const CRGB* src2, CRGB* dest, unsigned short count, fract8 amountOfsrc2 )
{
  for ( unsigned short i = 0; i < count; i++)
  {
    dest[i] = blend (src1[i], src2[i], amountOfsrc2);
  }

  return dest;
}

CHSV nblend_dir ( CHSV existing, CHSV overlay, fract8 amountOfOverlay, TGradientDirectionCode directionCode)
{
  if ( amountOfOverlay == 0)
  {
    return existing;
  }

  if ( amountOfOverlay == 255)
  {
    existing = overlay;
    return existing;
  }

  fract8 amountOfKeep = 255 - amountOfOverlay;
  unsigned char huedelta8 = overlay.h - existing.h;

  if ( directionCode == SHORTEST_HUES )
  {
    directionCode = FORWARD_HUES;

    if ( huedelta8 > 127)
    {
      directionCode = BACKWARD_HUES;
    }
  }

  if ( directionCode == LONGEST_HUES )
  {
    directionCode = FORWARD_HUES;

    if ( huedelta8 < 128)
    {
      directionCode = BACKWARD_HUES;
    }
  }

  if ( directionCode == FORWARD_HUES)
  {
    existing.h = existing.h + scale8 ( huedelta8, amountOfOverlay);
  }
  else /* directionCode == BACKWARD_HUES */
  {
    huedelta8 = -huedelta8;
    existing.h = existing.h - scale8 ( huedelta8, amountOfOverlay);
  }

  existing.s   = scale8 ( existing.s,   amountOfKeep)
                   + scale8 ( overlay.s,    amountOfOverlay);
  existing.v = scale8 ( existing.v, amountOfKeep)
                 + scale8 ( overlay.v,  amountOfOverlay);
  return existing;
}

void nblend_count_dir ( CHSV* existing, CHSV* overlay, unsigned short count, fract8 amountOfOverlay,
              TGradientDirectionCode directionCode )
{
  if (existing == overlay)
  {
    return;
  }

  for ( unsigned short i = count; i; i--)
  {
    nblend_dir ( *existing, *overlay, amountOfOverlay, directionCode);
    existing++;
    overlay++;
  }
}

CHSV blend_dir ( CHSV p1, CHSV p2, fract8 amountOfP2, TGradientDirectionCode directionCode )
{
  CHSV nu;
  HSV_init_by_hsv(&nu, p1);
  nblend_dir ( nu, p2, amountOfP2, directionCode);
  return nu;
}

CHSV* blend_count_dir ( const CHSV* src1, const CHSV* src2, CHSV* dest, unsigned short count, fract8 amountOfsrc2,
              TGradientDirectionCode directionCode )
{
  for ( unsigned short i = 0; i < count; i++)
  {
    dest[i] = blend_dir (src1[i], src2[i], amountOfsrc2, directionCode);
  }

  return dest;
}

// Forward declaration of the function "XY" which must be provided by
// the application for use in two-dimensional filter functions.
// Helper functions for an two-dimensional XY matrix of pixels.
// Simple 2-D demo code is included as well.
//
//     XY(x,y) takes x and y coordinates and returns an LED index number,
//             for use like this:  leds[ XY(x,y) ] == CRGB::Red;
//             No error checking is performed on the ranges of x and y.
//
//     XYsafe(x,y) takes x and y coordinates and returns an LED index number,
//             for use like this:  leds[ XY(x,y) ] == CRGB::Red;
//             Error checking IS performed on the ranges of x and y, and an
//             index of "-1" is returned.  Special instructions below
//             explain how to use this without having to do your own error
//             checking every time you use this function.  
//             This is a slightly more advanced technique, and 
//             it REQUIRES SPECIAL ADDITIONAL setup, described below.
const int    kMatrixSerpentineLayout = 1;
// Set 'kMatrixSerpentineLayout' to false if your pixels are 
// laid out all running the same way, like this:
//
//     0 >  1 >  2 >  3 >  4
//                         |
//     .----<----<----<----'
//     |
//     5 >  6 >  7 >  8 >  9
//                         |
//     .----<----<----<----'
//     |
//    10 > 11 > 12 > 13 > 14
//                         |
//     .----<----<----<----'
//     |
//    15 > 16 > 17 > 18 > 19
//
// Set 'kMatrixSerpentineLayout' to true if your pixels are 
// laid out back-and-forth, like this:
//
//     0 >  1 >  2 >  3 >  4
//                         |
//                         |
//     9 <  8 <  7 <  6 <  5
//     |
//     |
//    10 > 11 > 12 > 13 > 14
//                        |
//                        |
//    19 < 18 < 17 < 16 < 15
//
// Bonus vocabulary word: anything that goes one way 
// in one row, and then backwards in the next row, and so on
// is call "boustrophedon", meaning "as the ox plows."


// This function will return the right 'led index number' for 
// a given set of X and Y coordinates on your matrix.  
// IT DOES NOT CHECK THE COORDINATE BOUNDARIES.  
// That's up to you.  Don't pass it bogus values.
//
// Use the "XY" function like this:
//
//    for( uint8_t x = 0; x < kMatrixWidth; x++) {
//      for( uint8_t y = 0; y < kMatrixHeight; y++) {
//      
//        // Here's the x, y to 'led index' in action: 
//        leds[ XY( x, y) ] = CHSV( random8(), 255, 255);
//      
//      }
//    }
//
//              
unsigned short XY(unsigned char matrix_width, unsigned char x, unsigned char y)
{
  unsigned short i;

  if( kMatrixSerpentineLayout == 0) 
  {
    i = (y * matrix_width) + x;
  }

  if( kMatrixSerpentineLayout == 1) 
  {
    if( y & 0x01) 
    {
      // Odd rows run backwards
      unsigned char reverseX = (matrix_width - 1) - x;
      i = (y * matrix_width) + reverseX;
    }
    else 
    {
      // Even rows run forwards
      i = (y * matrix_width) + x;
    }
  }

  return i;
}


// blur1d: one-dimensional blur filter. Spreads light to 2 line neighbors.
// blur2d: two-dimensional blur filter. Spreads light to 8 XY neighbors.
//
//           0 = no spread at all
//          64 = moderate spreading
//         172 = maximum smooth, even spreading
//
//         173..255 = wider spreading, but increasing flicker
//
//         Total light is NOT entirely conserved, so many repeated
//         calls to 'blur' will also result in the light fading,
//         eventually all the way to black; this is by design so that
//         it can be used to (slowly) clear the LEDs to black.
void blur1d ( CRGB* leds, unsigned short numLeds, fract8 blur_amount)
{
  unsigned char keep = 255 - blur_amount;
  unsigned char seep = blur_amount >> 1;
  CRGB carryover;
  RGB_initByColor(&carryover, Black);

  for ( unsigned short i = 0; i < numLeds; i++)
  {
    CRGB cur = leds[i];
    CRGB part = cur;
    RGB_nscale8(&part, seep);
    RGB_nscale8(&cur, keep);
    RGB_addRGB(&cur, carryover);

    if ( i)
    {
      RGB_addRGB(&(leds[i - 1]), part);
    }

    leds[i] = cur;
    carryover = part;
  }
}

void blur2d ( CRGB* leds, unsigned char width, unsigned char height, fract8 blur_amount)
{
  blurRows (leds, width, height, blur_amount);
  blurColumns (leds, width, height, blur_amount);
}

// blurRows: perform a blur1d on every row of a rectangular matrix
void blurRows ( CRGB* leds, unsigned char width, unsigned char height, fract8 blur_amount)
{
  for ( unsigned char row = 0; row < height; row++)
  {
    CRGB* rowbase = leds + (row * width);
    blur1d ( rowbase, width, blur_amount);
  }
}

// blurColumns: perform a blur1d on each column of a rectangular matrix
void blurColumns (CRGB* leds, unsigned char width, unsigned char height, fract8 blur_amount)
{
  // blur columns
  unsigned char keep = 255 - blur_amount;
  unsigned char seep = blur_amount >> 1;

  for ( unsigned char col = 0; col < width; col++)
  {
    CRGB carryover;
    RGB_initByColor(&carryover, Black);

    for ( unsigned char i = 0; i < height; i++)
    {
      CRGB cur = leds[XY(width, col, i)];
      CRGB part = cur;
      RGB_nscale8(&part, seep);
      RGB_nscale8(&cur, keep);
      RGB_addRGB(&cur, carryover);

      if ( i)
      {
        RGB_addRGB(&(leds[XY(width, col, i - 1)]), part);
      }

      leds[XY(width, col, i)] = cur;
      carryover = part;
    }
  }
}



// CRGB HeatColor( unsigned char temperature)
//
// Approximates a 'black body radiation' spectrum for
// a given 'heat' level.  This is useful for animations of 'fire'.
// Heat is specified as an arbitrary scale from 0 (cool) to 255 (hot).
// This is NOT a chromatically correct 'black body radiation'
// spectrum, but it's surprisingly close, and it's fast and small.
//
// On AVR/Arduino, this typically takes around 70 bytes of program memory,
// versus 768 bytes for a full 256-entry RGB lookup table.

CRGB HeatColor(unsigned char temperature)
{
  CRGB heatcolor;
  // Scale 'heat' down from 0-255 to 0-191,
  // which can then be easily divided into three
  // equal 'thirds' of 64 units each.
  unsigned char t192 = scale8_video ( temperature, 191);
  // calculate a value that ramps up from
  // zero to 255 in each 'third' of the scale.
  unsigned char heatramp = t192 & 0x3F; // 0..63
  heatramp <<= 2; // scale up to 0..252

  // now figure out which third of the spectrum we're in:
  if ( t192 & 0x80)
  {
    // we're in the hottest third
    heatcolor.r = 255; // full red
    heatcolor.g = 255; // full green
    heatcolor.b = heatramp; // ramp up blue
  }
  else if ( t192 & 0x40 )
  {
    // we're in the middle third
    heatcolor.r = 255; // full red
    heatcolor.g = heatramp; // ramp up green
    heatcolor.b = 0; // no blue
  }
  else
  {
    // we're in the coolest third
    heatcolor.r = heatramp; // ramp up red
    heatcolor.g = 0; // no green
    heatcolor.b = 0; // no blue
  }

  return heatcolor;
}


// lsrX4: helper function to divide a number by 16, aka four LSR's.
// On avr-gcc, "u8 >> 4" generates a loop, which is big, and slow.
// merely forcing it to be four /=2's causes avr-gcc to emit
// a SWAP instruction followed by an AND 0x0F, which is faster, and smaller.
inline unsigned char lsrX4 ( unsigned char dividend)
{
  dividend >>= 4;
  return dividend;
}


CRGB RGBColorFromRGBPalette16(CRGBPalette16 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  //      hi4 = index >> 4;
  unsigned char hi4 = lsrX4 (index);
  unsigned char lo4 = index & 0x0F;
  // const CRGB* entry = &(pal[0]) + hi4;
  // since hi4 is always 0..15, hi4 * sizeof(CRGB) can be a single-byte value,
  // instead of the two byte 'int' that avr-gcc defaults to.
  // So, we multiply hi4 X sizeof(CRGB), giving hi4XsizeofCRGB;
  unsigned char hi4XsizeofCRGB = hi4 * sizeof (CRGB);
  // We then add that to a base array pointer.
  const CRGB* entry = (CRGB*) ( (unsigned char*) (& (pal.entries[0]) ) + hi4XsizeofCRGB);
  unsigned char blend = lo4 && (blendType != NOBLEND);
  unsigned char red1   = entry->r;
  unsigned char green1 = entry->g;
  unsigned char blue1  = entry->b;

  if ( blend )
  {
    if ( hi4 == 15 )
    {
      entry = & (pal.entries[0]);
    }
    else
    {
      entry++;
    }

    unsigned char f2 = lo4 << 4;
    unsigned char f1 = 255 - f2;
    //    rgb1.nscale8(f1);
    unsigned char red2   = entry->r;
    red1   = scale8 ( red1,   f1);
    red2   = scale8 ( red2,   f2);
    red1   += red2;
    unsigned char green2 = entry->g;
    green1 = scale8 ( green1, f1);
    green2 = scale8 ( green2, f2);
    green1 += green2;
    unsigned char blue2  = entry->b;
    blue1  = scale8 ( blue1,  f1);
    blue2  = scale8 ( blue2,  f2);
    blue1  += blue2;
  }

  if ( brightness != 255)
  {
    if ( brightness )
    {
      brightness++; // adjust for rounding

      // Now, since brightness is nonzero, we don't need the full scale8_video logic;
      // we can just to scale8 and then add one (unless scale8 fixed) to all nonzero inputs.
      if ( red1 )
      {
        red1 = scale8 ( red1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        red1++;
#endif
      }

      if ( green1 )
      {
        green1 = scale8 ( green1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        green1++;
#endif
      }

      if ( blue1 )
      {
        blue1 = scale8 ( blue1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        blue1++;
#endif
      }

    }
    else
    {
      red1 = 0;
      green1 = 0;
      blue1 = 0;
    }
  }
  CRGB rgb;
  rgb.r = red1;
  rgb.g = green1;
  rgb.b = blue1;
  return rgb;
}
#define FL_PGM_READ_DWORD_NEAR(x) (*((const unsigned int*)(x)))

CRGB RGBColorFromProgmemRGBPalette16(TProgmemRGBPalette16 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  //      hi4 = index >> 4;
  unsigned char hi4 = lsrX4 (index);
  unsigned char lo4 = index & 0x0F;
  CRGB entry;
  RGB_initByColor(&entry, FL_PGM_READ_DWORD_NEAR(&(pal[0]) + hi4));
  unsigned char red1   = entry.r;
  unsigned char green1 = entry.g;
  unsigned char blue1  = entry.b;
  unsigned char blend = lo4 && (blendType != NOBLEND);

  if ( blend )
  {
    if ( hi4 == 15 )
    {
      RGB_initByColor(&entry, FL_PGM_READ_DWORD_NEAR(&(pal[0])));
    }
    else
    {
      RGB_initByColor(&entry, FL_PGM_READ_DWORD_NEAR(&(pal[1]) + hi4));
    }

    unsigned char f2 = lo4 << 4;
    unsigned char f1 = 255 - f2;
    unsigned char red2   = entry.r;
    red1   = scale8 ( red1,   f1);
    red2   = scale8 ( red2,   f2);
    red1   += red2;
    unsigned char green2 = entry.g;
    green1 = scale8 ( green1, f1);
    green2 = scale8 ( green2, f2);
    green1 += green2;
    unsigned char blue2  = entry.b;
    blue1  = scale8 ( blue1,  f1);
    blue2  = scale8 ( blue2,  f2);
    blue1  += blue2;
  }

  if ( brightness != 255)
  {
    if ( brightness )
    {
      brightness++; // adjust for rounding

      // Now, since brightness is nonzero, we don't need the full scale8_video logic;
      // we can just to scale8 and then add one (unless scale8 fixed) to all nonzero inputs.
      if ( red1 )
      {
        red1 = scale8 ( red1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        red1++;
#endif
      }

      if ( green1 )
      {
        green1 = scale8 ( green1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        green1++;
#endif
      }

      if ( blue1 )
      {
        blue1 = scale8 ( blue1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        blue1++;
#endif
      }

    }
    else
    {
      red1 = 0;
      green1 = 0;
      blue1 = 0;
    }
  }

  return struct_RGB_by_r_g_b( red1, green1, blue1);
}


CRGB RGBColorFromRGBPalette32(CRGBPalette32 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  unsigned char hi5 = index;
  hi5 >>= 3;
  unsigned char lo3 = index & 0x07;
  // const CRGB* entry = &(pal[0]) + hi5;
  // since hi5 is always 0..31, hi4 * sizeof(CRGB) can be a single-byte value,
  // instead of the two byte 'int' that avr-gcc defaults to.
  // So, we multiply hi5 X sizeof(CRGB), giving hi5XsizeofCRGB;
  unsigned char hi5XsizeofCRGB = hi5 * sizeof (CRGB);
  // We then add that to a base array pointer.
  const CRGB* entry = (CRGB*) ( (unsigned char*) (& (pal.entries[0]) ) + hi5XsizeofCRGB);
  unsigned char red1   = entry->r;
  unsigned char green1 = entry->g;
  unsigned char blue1  = entry->b;
  unsigned char blend = lo3 && (blendType != NOBLEND);

  if ( blend )
  {
    if ( hi5 == 31 )
    {
      entry = & (pal.entries[0]);
    }
    else
    {
      entry++;
    }

    unsigned char f2 = lo3 << 5;
    unsigned char f1 = 255 - f2;
    unsigned char red2   = entry->r;
    red1   = scale8 ( red1,   f1);
    red2   = scale8 ( red2,   f2);
    red1   += red2;
    unsigned char green2 = entry->g;
    green1 = scale8 ( green1, f1);
    green2 = scale8 ( green2, f2);
    green1 += green2;
    unsigned char blue2  = entry->b;
    blue1  = scale8 ( blue1,  f1);
    blue2  = scale8 ( blue2,  f2);
    blue1  += blue2;
  }

  if ( brightness != 255)
  {
    if ( brightness )
    {
      brightness++; // adjust for rounding

      // Now, since brightness is nonzero, we don't need the full scale8_video logic;
      // we can just to scale8 and then add one (unless scale8 fixed) to all nonzero inputs.
      if ( red1 )
      {
        red1 = scale8 ( red1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        red1++;
#endif
      }

      if ( green1 )
      {
        green1 = scale8 ( green1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        green1++;
#endif
      }

      if ( blue1 )
      {
        blue1 = scale8 ( blue1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        blue1++;
#endif
      }

    }
    else
    {
      red1 = 0;
      green1 = 0;
      blue1 = 0;
    }
  }

  return struct_RGB_by_r_g_b( red1, green1, blue1);
}

CRGB RGBColorFromProgramRGBPalette32(TProgmemRGBPalette32 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  unsigned char hi5 = index;
  hi5 >>= 3;
  unsigned char lo3 = index & 0x07;
  CRGB entry;
  RGB_initByColor(&entry, FL_PGM_READ_DWORD_NEAR(&(pal[0]) + hi5));
  unsigned char red1   = entry.r;
  unsigned char green1 = entry.g;
  unsigned char blue1  = entry.b;
  unsigned char blend = lo3 && (blendType != NOBLEND);

  if ( blend )
  {
    if ( hi5 == 31 )
    {
      RGB_initByColor(&entry, FL_PGM_READ_DWORD_NEAR(&(pal[0])) );
    }
    else
    {
      RGB_initByColor(&entry, FL_PGM_READ_DWORD_NEAR(&(pal[1]) + hi5));
    }

    unsigned char f2 = lo3 << 5;
    unsigned char f1 = 255 - f2;
    unsigned char red2   = entry.r;
    red1   = scale8 ( red1,   f1);
    red2   = scale8 ( red2,   f2);
    red1   += red2;
    unsigned char green2 = entry.g;
    green1 = scale8 ( green1, f1);
    green2 = scale8 ( green2, f2);
    green1 += green2;
    unsigned char blue2  = entry.b;
    blue1  = scale8 ( blue1,  f1);
    blue2  = scale8 ( blue2,  f2);
    blue1  += blue2;
  }

  if ( brightness != 255)
  {
    if ( brightness )
    {
      brightness++; // adjust for rounding

      // Now, since brightness is nonzero, we don't need the full scale8_video logic;
      // we can just to scale8 and then add one (unless scale8 fixed) to all nonzero inputs.
      if ( red1 )
      {
        red1 = scale8 ( red1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        red1++;
#endif
      }

      if ( green1 )
      {
        green1 = scale8 ( green1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        green1++;
#endif
      }

      if ( blue1 )
      {
        blue1 = scale8 ( blue1, brightness);
#if !(FASTLED_SCALE8_FIXED==1)
        blue1++;
#endif
      }

    }
    else
    {
      red1 = 0;
      green1 = 0;
      blue1 = 0;
    }
  }

  return struct_RGB_by_r_g_b( red1, green1, blue1);
}


CRGB RGBColorFromRGBPalette256(CRGBPalette256 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  CRGB* entry = & (pal.entries[0]) + index;
  unsigned char red   = entry->r;
  unsigned char green = entry->g;
  unsigned char blue  = entry->b;

  if ( brightness != 255)
  {
    brightness++; // adjust for rounding
    red   = scale8_video ( red,   brightness);
    green = scale8_video ( green, brightness);
    blue  = scale8_video ( blue,  brightness);
  }

  return struct_RGB_by_r_g_b( red, green, blue);
}

CHSV HSVColorFromHSVPalette16 (CHSVPalette16 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  //      hi4 = index >> 4;
  unsigned char hi4 = lsrX4 (index);
  unsigned char lo4 = index & 0x0F;
  //  CRGB rgb1 = pal[ hi4];
  const CHSV* entry = & (pal.entries[0]) + hi4;
  unsigned char hue1   = entry->h;
  unsigned char sat1   = entry->s;
  unsigned char val1   = entry->v;
  unsigned char blend = lo4 && (blendType != NOBLEND);

  if ( blend )
  {
    if ( hi4 == 15 )
    {
      entry = & (pal.entries[0]);
    }
    else
    {
      entry++;
    }

    unsigned char f2 = lo4 << 4;
    unsigned char f1 = 255 - f2;
    unsigned char hue2  = entry->h;
    unsigned char sat2  = entry->s;
    unsigned char val2  = entry->v;

    // Now some special casing for blending to or from
    // either black or white.  Black and white don't have
    // proper 'hue' of their own, so when ramping from
    // something else to/from black/white, we set the 'hue'
    // of the black/white color to be the same as the hue
    // of the other color, so that you get the expected
    // brightness or saturation ramp, with hue staying
    // constant:

    // If we are starting from white (sat=0)
    // or black (val=0), adopt the target hue.
    if ( sat1 == 0 || val1 == 0)
    {
      hue1 = hue2;
    }

    // If we are ending at white (sat=0)
    // or black (val=0), adopt the starting hue.
    if ( sat2 == 0 || val2 == 0)
    {
      hue2 = hue1;
    }

    sat1  = scale8 ( sat1, f1);
    val1  = scale8 ( val1, f1);
    sat2  = scale8 ( sat2, f2);
    val2  = scale8 ( val2, f2);
    // These sums can't overflow, so no qadd8 needed.
    sat1  += sat2;
    val1  += val2;
    unsigned char deltaHue = (unsigned char) (hue2 - hue1);

    if ( deltaHue & 0x80 )
    {
      // go backwards
      hue1 -= scale8 ( 256 - deltaHue, f2);
    }
    else
    {
      // go forwards
      hue1 += scale8 ( deltaHue, f2);
    }

  }

  if ( brightness != 255)
  {
    val1 = scale8_video ( val1, brightness);
  }

  return struct_HSV_by_h_s_v( hue1, sat1, val1);
}


CHSV HSVColorFromHSVPalette32(CHSVPalette32 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  unsigned char hi5 = index;
  hi5 >>= 3;
  unsigned char lo3 = index & 0x07;
  unsigned char hi5XsizeofCHSV = hi5 * sizeof (CHSV);
  const CHSV* entry = (CHSV*) ( (unsigned char*)(&(pal.entries[0]) ) + hi5XsizeofCHSV);
  unsigned char hue1   = entry->h;
  unsigned char sat1   = entry->s;
  unsigned char val1   = entry->v;
  unsigned char blend = lo3 && (blendType != NOBLEND);

  if ( blend )
  {
    if ( hi5 == 31 )
    {
      entry = &(pal.entries[0]);
    }
    else
    {
      entry++;
    }

    unsigned char f2 = lo3 << 5;
    unsigned char f1 = 255 - f2;
    unsigned char hue2  = entry->h;
    unsigned char sat2  = entry->s;
    unsigned char val2  = entry->v;

    // Now some special casing for blending to or from
    // either black or white.  Black and white don't have
    // proper 'hue' of their own, so when ramping from
    // something else to/from black/white, we set the 'hue'
    // of the black/white color to be the same as the hue
    // of the other color, so that you get the expected
    // brightness or saturation ramp, with hue staying
    // constant:

    // If we are starting from white (sat=0)
    // or black (val=0), adopt the target hue.
    if ( sat1 == 0 || val1 == 0)
    {
      hue1 = hue2;
    }

    // If we are ending at white (sat=0)
    // or black (val=0), adopt the starting hue.
    if ( sat2 == 0 || val2 == 0)
    {
      hue2 = hue1;
    }

    sat1  = scale8 ( sat1, f1);
    val1  = scale8 ( val1, f1);
    sat2  = scale8 ( sat2, f2);
    val2  = scale8 ( val2, f2);
    // These sums can't overflow, so no qadd8 needed.
    sat1  += sat2;
    val1  += val2;
    unsigned char deltaHue = (unsigned char) (hue2 - hue1);

    if ( deltaHue & 0x80 )
    {
      // go backwards
      hue1 -= scale8 ( 256 - deltaHue, f2);
    }
    else
    {
      // go forwards
      hue1 += scale8 ( deltaHue, f2);
    }

  }

  if ( brightness != 255)
  {
    val1 = scale8_video ( val1, brightness);
  }

  return struct_HSV_by_h_s_v( hue1, sat1, val1);
}

CHSV HSVColorFromHSVPalette256(CHSVPalette256 pal, unsigned char index, unsigned char brightness, TBlendType blendType)
{
  CHSV hsv = * ( & (pal.entries[0]) + index );

  if ( brightness != 255)
  {
    hsv.v = scale8_video ( hsv.v, brightness);
  }

  return hsv;
}


void UpscalePalette_16to256_rgb(CRGBPalette16 srcpal16, CRGBPalette256* destpal256)
{
  CRGB* entries = destpal256->entries;
  for ( int i = 0; i < 256; i++)
  {
    entries[ (unsigned char) (i)] = RGBColorFromRGBPalette16 ( srcpal16, i, 255, LINEARBLEND);
  }
}

void UpscalePalette_16to256_hsv(CHSVPalette16 srcpal16, CHSVPalette256* destpal256)
{
  CHSV* entries = destpal256->entries;
  for ( int i = 0; i < 256; i++)
  {
    entries[ (unsigned char) (i)] = HSVColorFromHSVPalette16 ( srcpal16, i, 255, LINEARBLEND);
  }
}

void UpscalePalette_16to32_rgb(CRGBPalette16 srcpal16, CRGBPalette32* destpal32)
{
  CRGB* entries = destpal32->entries;
  CRGB* src_entries = srcpal16.entries;
  for ( unsigned char i = 0; i < 16; i++)
  {
    unsigned char j = i * 2;
    entries[j+0] = src_entries[i];
    entries[j+1] = src_entries[i];
  }
}

void UpscalePalette_16to32_hsv(CHSVPalette16 srcpal16, CHSVPalette32* destpal32)
{
  CHSV* entries = destpal32->entries;
  CHSV* src_entries = srcpal16.entries;
  for ( unsigned char i = 0; i < 16; i++)
  {
    unsigned char j = i * 2;
    entries[j+0] = src_entries[i];
    entries[j+1] = src_entries[i];
  }
}

void UpscalePalette_32to256_rgb(CRGBPalette32 srcpal32, CRGBPalette256* destpal256)
{
  CRGB* entries = destpal256->entries;
  for ( int i = 0; i < 256; i++)
  {
    entries[ (unsigned char) (i)] = RGBColorFromRGBPalette32( srcpal32, i, 255, LINEARBLEND);
  }
}

void UpscalePalette_32to256_hsv(CHSVPalette32 srcpal32, CHSVPalette256* destpal256)
{
  CHSV* entries = destpal256->entries;
  for ( int i = 0; i < 256; i++)
  {
    entries[ (unsigned char) (i)] = HSVColorFromHSVPalette32 ( srcpal32, i, 255, LINEARBLEND);
  }
}

void CHSVPalette16_init_by_c16 ( CHSVPalette16* c_this, CHSV c00, CHSV c01, CHSV c02, CHSV c03,
                                 CHSV c04, CHSV c05, CHSV c06, CHSV c07,
                                 CHSV c08, CHSV c09, CHSV c10, CHSV c11,
                                 CHSV c12, CHSV c13, CHSV c14, CHSV c15 )
{
  c_this->entries[0]=c00;  c_this->entries[1]=c01;  c_this->entries[2]=c02;  c_this->entries[3]=c03;
  c_this->entries[4]=c04;  c_this->entries[5]=c05;  c_this->entries[6]=c06;  c_this->entries[7]=c07;
  c_this->entries[8]=c08;  c_this->entries[9]=c09;  c_this->entries[10]=c10; c_this->entries[11]=c11;
  c_this->entries[12]=c12; c_this->entries[13]=c13; c_this->entries[14]=c14; c_this->entries[15]=c15;
};

void CHSVPalette16_init_by_self_type (CHSVPalette16* c_this, CHSVPalette16 rhs)
{
  memmove8 ( & (c_this->entries[0]), & (rhs.entries[0]), sizeof ( c_this->entries) );
}

void CHSVPalette16_init_by_programedHSVPalette16 (CHSVPalette16* c_this, TProgmemHSVPalette16 rhs)
{
  CRGB xyz;

  for ( unsigned char i = 0; i < 16; i++)
  {
    RGB_initByColor (&xyz, FL_PGM_READ_DWORD_NEAR ( rhs + i) );
    c_this->entries[i].h = xyz.r;
    c_this->entries[i].s = xyz.g;
    c_this->entries[i].v = xyz.b;
  }
}

void CHSVPalette16_init_by_c1 (CHSVPalette16* c_this, CHSV c1)
{
  fill_solid_hsv ( & (c_this->entries[0]), 16, c1);
}
void CHSVPalette16_init_by_c1c2 (CHSVPalette16* c_this, CHSV c1, CHSV c2)
{
  fill_gradient_rgb_hsv_c1c2 (& (c_this->entries[0]), 16, c1, c2, SHORTEST_HUES, 0);
}
void CHSVPalette16_init_by_c1c2c3 (CHSVPalette16* c_this, CHSV c1, CHSV c2, CHSV c3)
{
  fill_gradient_rgb_hsv_c1c2c3 (& (c_this->entries[0]), 16, c1, c2, c3, SHORTEST_HUES, 0);
}
void CHSVPalette16_init_by_c1c2c3c4 (CHSVPalette16* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4)
{
  fill_gradient_rgb_hsv_c1c2c3c4 (& (c_this->entries[0]), 16, c1, c2, c3, c4, SHORTEST_HUES, 0);
}

int CHSVPalette16_is_equal (CHSVPalette16* c_this, CHSVPalette16 rhs)
{
  const unsigned char* p = (const unsigned char*) (& (c_this->entries[0]) );
  const unsigned char* q = (const unsigned char*) (& (rhs.entries[0]) );

  if (p == q)
  {
    return 1;
  }

  for ( unsigned char i = 0; i < (sizeof ( c_this->entries) ); i++)
  {
    if (*p != *q)
    {
      return 0;
    }

    p++;
    q++;
  }

  return 1;
}

void CHSVPalette256_init_by_hsvPalette16 (CHSVPalette256* c_this,  CHSVPalette16 rhs16)
{
  UpscalePalette_16to256_hsv ( rhs16, c_this);
}


void CHSVPalette256_init_by_c16 (CHSVPalette256* c_this, CHSV c00, CHSV c01, CHSV c02, CHSV c03,
                                 CHSV c04, CHSV c05, CHSV c06, CHSV c07,
                                 CHSV c08, CHSV c09, CHSV c10, CHSV c11,
                                 CHSV c12, CHSV c13, CHSV c14, CHSV c15 )
{
  CHSVPalette16 p16;
  CHSVPalette16_init_by_c16 (&p16, c00, c01, c02, c03, c04, c05, c06, c07,
                             c08, c09, c10, c11, c12, c13, c14, c15);
  CHSVPalette256_init_by_hsvPalette16 (c_this, p16);
};

void CHSVPalette256_init_by_self_type (CHSVPalette256* c_this, CHSVPalette256 rhs)
{
  memmove8 ( & (c_this->entries[0]), & (rhs.entries[0]), sizeof (c_this->entries) );
}

void CHSVPalette256_init_by_programHSVPalette16 (CHSVPalette256* c_this, TProgmemHSVPalette16 rhs)
{
  CHSVPalette16 p16;
  CHSVPalette16_init_by_programedHSVPalette16(&p16, rhs);
  CHSVPalette256_init_by_hsvPalette16 (c_this, p16);
}

void CHSVPalette256_init_by_c1 (CHSVPalette256* c_this, CHSV c1)
{
  fill_solid_hsv (& (c_this->entries[0]), 256, c1);
}
void CHSVPalette256_init_by_c1c2 (CHSVPalette256* c_this, CHSV c1, CHSV c2)
{
  fill_gradient_rgb_hsv_c1c2 (& (c_this->entries[0]), 256, c1, c2, SHORTEST_HUES, 0);
}
void CHSVPalette256_init_by_c1c2c3 (CHSVPalette256* c_this, CHSV c1, CHSV c2, CHSV c3)
{
  fill_gradient_rgb_hsv_c1c2c3 ( & (c_this->entries[0]), 256, c1, c2, c3, SHORTEST_HUES, 0);
}
void CHSVPalette256_init_by_c1c2c3c4 (CHSVPalette256* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4)
{
  fill_gradient_rgb_hsv_c1c2c3c4 (& (c_this->entries[0]), 256, c1, c2, c3, c4, SHORTEST_HUES, 0);
}

int CHSVPalette256_is_equal (CHSVPalette256* c_this, CHSVPalette256 rhs)
{
  const unsigned char* p = (const unsigned char*) (& (c_this->entries[0]) );
  const unsigned char* q = (const unsigned char*) (& (rhs.entries[0]) );

  if ( p == q)
  {
    return 1;
  }

  for ( unsigned short i = 0; i < (sizeof ( c_this->entries) ); i++)
  {
    if ( *p != *q)
    {
      return 0;
    }

    p++;
    q++;
  }

  return 1;
}

void CRGBPalette16_init_by_c16 ( CRGBPalette16* c_this, CRGB c00, CRGB c01, CRGB c02, CRGB c03,
                                 CRGB c04, CRGB c05, CRGB c06, CRGB c07,
                                 CRGB c08, CRGB c09, CRGB c10, CRGB c11,
                                 CRGB c12, CRGB c13, CRGB c14, CRGB c15 )
{
  c_this->entries[0]=c00;  c_this->entries[1]=c01;  c_this->entries[2]=c02;  c_this->entries[3]=c03;
  c_this->entries[4]=c04;  c_this->entries[5]=c05;  c_this->entries[6]=c06;  c_this->entries[7]=c07;
  c_this->entries[8]=c08;  c_this->entries[9]=c09;  c_this->entries[10]=c10; c_this->entries[11]=c11;
  c_this->entries[12]=c12; c_this->entries[13]=c13; c_this->entries[14]=c14; c_this->entries[15]=c15;
};

void CRGBPalette16_init_by_self_type ( CRGBPalette16* c_this, const CRGBPalette16 rhs)
{
  memmove8 (& (c_this->entries[0]), & (rhs.entries[0]), sizeof (c_this->entries) );
}

void CRGBPalette16_init_by_rgb ( CRGBPalette16* c_this, CRGB rhs[16])
{
  memmove8 (& (c_this->entries[0]), & (rhs[0]), sizeof (c_this->entries) );
}

void CRGBPalette16_init_by_hsvPalette16 (CRGBPalette16* c_this, CHSVPalette16 rhs)
{
  for ( unsigned char i = 0; i < 16; i++)
  {
    //this->entries[i] = rhs.entries[i]; // implicit HSV-to-RGB conversion
    RGB_initByHSV (&(c_this->entries[i]), rhs.entries[i]);
  }
}

void CRGBPalette16_init_by_hsv (CRGBPalette16* c_this, CHSV rhs[16])
{
  for ( unsigned char i = 0; i < 16; i++)
  {
    //this->entries[i] = rhs[i]; // implicit HSV-to-RGB conversion
    RGB_initByHSV (&(c_this->entries[i]), rhs[i]);
  }
}

void CRGBPalette16_init_by_programRGBPalette16 (CRGBPalette16* c_this, TProgmemRGBPalette16 rhs)
{
  CRGB rgb;

  for ( unsigned char i = 0; i < 16; i++)
  {
    RGB_initByColor (&rgb, FL_PGM_READ_DWORD_NEAR ( rhs + i) );
    c_this->entries[i] = rgb;
  }
}

void CRGBPalette16_init_by_hsv_c1 (CRGBPalette16* c_this, CHSV c1)
{
  CRGB rgb;
  RGB_initByHSV (&rgb, c1);
  fill_solid_rgb (& (c_this->entries[0]), 16, rgb);
}

void CRGBPalette16_init_by_hsv_c1c2 (CRGBPalette16* c_this, CHSV c1, CHSV c2)
{
  fill_gradient_rgb_hsv_c1c2 (& (c_this->entries[0]), 16, c1, c2, SHORTEST_HUES, 1);
}

void CRGBPalette16_init_by_hsv_c1c2c3 (CRGBPalette16* c_this, CHSV c1, CHSV c2, CHSV c3)
{
  fill_gradient_rgb_hsv_c1c2c3 (& (c_this->entries[0]), 16, c1, c2, c3, SHORTEST_HUES, 1);
}

void CRGBPalette16_init_by_hsv_c1c2c3c4 (CRGBPalette16* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4)
{
  fill_gradient_rgb_hsv_c1c2c3c4 (& (c_this->entries[0]), 16, c1, c2, c3, c4, SHORTEST_HUES, 1);
}

void CRGBPalette16_init_by_rgb_c1 (CRGBPalette16* c_this, CRGB c1)
{
  fill_solid_rgb (& (c_this->entries[0]), 16, c1);
}

void CRGBPalette16_init_by_rgb_c1c2 (CRGBPalette16* c_this, CRGB c1, CRGB c2)
{
  fill_gradient_RGB_c1c2 (& (c_this->entries[0]), 16, c1, c2);
}

void CRGBPalette16_init_by_rgb_c1c2c3 (CRGBPalette16* c_this, CRGB c1, CRGB c2, CRGB c3)
{
  fill_gradient_RGB_c1c2c3 (& (c_this->entries[0]), 16, c1, c2, c3);
}

void CRGBPalette16_init_by_rgb_c1c2c3c4 (CRGBPalette16* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4)
{
  fill_gradient_RGB_c1c2c3c4 ( & (c_this->entries[0]), 16, c1, c2, c3, c4);
}

// Gradient palettes are loaded into CRGB16Palettes in such a way
// that, if possible, every color represented in the gradient palette
// is also represented in the CRGBPalette16.
// For example, consider a gradient palette that is all black except
// for a single, one-element-wide (1/256th!) spike of red in the middle:
//     0,   0,0,0
//   124,   0,0,0
//   125, 255,0,0  // one 1/256th-palette-wide red stripe
//   126,   0,0,0
//   255,   0,0,0
// A naive conversion of this 256-element palette to a 16-element palette
// might accidentally completely eliminate the red spike, rendering the
// palette completely black.
// However, the conversions provided here would attempt to include a
// the red stripe in the output, more-or-less as faithfully as possible.
// So in this case, the resulting CRGBPalette16 palette would have a red
// stripe in the middle which was 1/16th of a palette wide -- the
// narrowest possible in a CRGBPalette16.
// This means that the relative width of stripes in a CRGBPalette16
// will be, by definition, different from the widths in the gradient
// palette.  This code attempts to preserve "all the colors", rather than
// the exact stripe widths at the expense of dropping some colors.
void CRGBPalette16_init_by_RGB_Gradient_bytes (CRGBPalette16* c_this, TProgmemRGBGradientPalette_bytes progpal )
{
  TRGBGradientPaletteEntryUnion* progent = (TRGBGradientPaletteEntryUnion*) (progpal);
  TRGBGradientPaletteEntryUnion u;
  // Count entries
  unsigned short count = 0;

  do
  {
    u.dword = FL_PGM_READ_DWORD_NEAR (progent + count);
    count++;;
  } while ( u.index != 255);

  char lastSlotUsed = -1;
  u.dword = FL_PGM_READ_DWORD_NEAR ( progent);
  CRGB rgbstart = struct_RGB_by_r_g_b( u.r, u.g, u.b);
  int indexstart = 0;
  unsigned char istart8 = 0;
  unsigned char iend8 = 0;

  while ( indexstart < 255)
  {
    progent++;
    u.dword = FL_PGM_READ_DWORD_NEAR ( progent);
    int indexend  = u.index;
    CRGB rgbend = struct_RGB_by_r_g_b(u.r, u.g, u.b);
    istart8 = indexstart / 16;
    iend8   = indexend   / 16;

    if ( count < 16)
    {
      if ( (istart8 <= lastSlotUsed) && (lastSlotUsed < 15) )
      {
        istart8 = lastSlotUsed + 1;

        if ( iend8 < istart8)
        {
          iend8 = istart8;
        }
      }

      lastSlotUsed = iend8;
    }

    fill_gradient_RGB (& (c_this->entries[0]), istart8, rgbstart, iend8, rgbend);
    indexstart = indexend;
    rgbstart = rgbend;
  }
}

int CRGBPalette16_is_equal (CRGBPalette16* c_this, CRGBPalette16 rhs)
{
  const unsigned char* p = (const unsigned char*) (& (c_this->entries[0]) );
  const unsigned char* q = (const unsigned char*) (& (rhs.entries[0]) );

  if ( p == q)
  {
    return 1;
  }

  for ( unsigned char i = 0; i < (sizeof (c_this->entries) ); i++)
  {
    if ( *p != *q)
    {
      return 0;
    }

    p++;
    q++;
  }

  return 1;
}

void CHSVPalette32_init_by_c16 ( CHSVPalette32* c_this, CHSV c00, CHSV c01, CHSV c02, CHSV c03,
                                 CHSV c04, CHSV c05, CHSV c06, CHSV c07,
                                 CHSV c08, CHSV c09, CHSV c10, CHSV c11,
                                 CHSV c12, CHSV c13, CHSV c14, CHSV c15 )
{
  for ( unsigned char i = 0; i < 2; i++)
  {
    c_this->entries[0+i]=c00;  c_this->entries[2+i]=c01;  c_this->entries[4+i]=c02;  c_this->entries[6+i]=c03;
    c_this->entries[8+i]=c04;  c_this->entries[10+i]=c05; c_this->entries[12+i]=c06; c_this->entries[14+i]=c07;
    c_this->entries[16+i]=c08; c_this->entries[18+i]=c09; c_this->entries[20+i]=c10; c_this->entries[22+i]=c11;
    c_this->entries[24+i]=c12; c_this->entries[26+i]=c13; c_this->entries[28+i]=c14; c_this->entries[30+i]=c15;
  }
}

void CHSVPalette32_init_by_self_type ( CHSVPalette32* c_this, CHSVPalette32 rhs)
{
  memmove8 (& (c_this->entries[0]), & (rhs.entries[0]), sizeof (c_this->entries) );
}

void CHSVPalette32_init_by_programHSVPalette32 (CHSVPalette32* c_this, TProgmemHSVPalette32 rhs)
{
  CRGB xyz;

  for ( unsigned char i = 0; i < 32; i++)
  {
    RGB_initByColor (&xyz, FL_PGM_READ_DWORD_NEAR ( rhs + i) );
    c_this->entries[i].h = xyz.r;
    c_this->entries[i].s = xyz.g;
    c_this->entries[i].v = xyz.b;
  }
}

int CHSVPalette32_is_equal (CHSVPalette32* c_this, CHSVPalette32 rhs)
{
  const unsigned char* p = (const unsigned char*) (& (c_this->entries[0]) );
  const unsigned char* q = (const unsigned char*) (& (rhs.entries[0]) );

  if ( p == q)
  {
    return 1;
  }

  for ( unsigned char i = 0; i < (sizeof (c_this->entries) ); i++)
  {
    if ( *p != *q)
    {
      return 0;
    }

    p++;
    q++;
  }

  return 1;
}

void CHSVPalette32_init_by_c1 (CHSVPalette32* c_this, CHSV c1)
{
  fill_solid_hsv (& (c_this->entries[0]), 32, c1);
}

void CHSVPalette32_init_by_c1c2 (CHSVPalette32* c_this, CHSV c1, CHSV c2)
{
  fill_gradient_rgb_hsv_c1c2 (& (c_this->entries[0]), 32, c1, c2, SHORTEST_HUES, 0);
}

void CHSVPalette32_init_by_c1c2c3 (CHSVPalette32* c_this, CHSV c1, CHSV c2, CHSV c3)
{
  fill_gradient_rgb_hsv_c1c2c3 (& (c_this->entries[0]), 32, c1, c2, c3, SHORTEST_HUES, 0);
}

void CHSVPalette32_init_by_c1c2c3c4 (CHSVPalette32* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4)
{
  fill_gradient_rgb_hsv_c1c2c3c4 (& (c_this->entries[0]), 32, c1, c2, c3, c4, SHORTEST_HUES, 0);
}

void CRGBPalette32_init_by_c16 (CRGBPalette32* c_this, CRGB c00, CRGB c01, CRGB c02, CRGB c03,
                                CRGB c04, CRGB c05, CRGB c06, CRGB c07,
                                CRGB c08, CRGB c09, CRGB c10, CRGB c11,
                                CRGB c12, CRGB c13, CRGB c14, CRGB c15 )
{
  for ( unsigned char i = 0; i < 2; i++)
  {
    c_this->entries[0+i]=c00;  c_this->entries[2+i]=c01;  c_this->entries[4+i]=c02;  c_this->entries[6+i]=c03;
    c_this->entries[8+i]=c04;  c_this->entries[10+i]=c05; c_this->entries[12+i]=c06; c_this->entries[14+i]=c07;
    c_this->entries[16+i]=c08; c_this->entries[18+i]=c09; c_this->entries[20+i]=c10; c_this->entries[22+i]=c11;
    c_this->entries[24+i]=c12; c_this->entries[26+i]=c13; c_this->entries[28+i]=c14; c_this->entries[30+i]=c15;
  }
}

void CRGBPalette32_init_by_self_type (CRGBPalette32* c_this, CRGBPalette32 rhs)
{
  memmove8 (& (c_this->entries[0]), & (rhs.entries[0]), sizeof (c_this->entries) );
}

void CRGBPalette32_init_by_rgb (CRGBPalette32* c_this, CRGB rhs[32])
{
  memmove8 (& (c_this->entries[0]), & (rhs[0]), sizeof (c_this->entries) );
}

void CRGBPalette32_init_by_hsvPalette (CRGBPalette32* c_this, CHSVPalette32 rhs)
{
  for ( unsigned char i = 0; i < 32; i++)
  {
    //c_this->entries[i] = rhs.entries[i]; // implicit HSV-to-RGB conversion
    RGB_initByHSV(&(c_this->entries[i]), rhs.entries[i]);
  }
}

void CRGBPalette32_init_by_hsv (CRGBPalette32* c_this, CHSV rhs[32])
{
  for ( unsigned char i = 0; i < 32; i++)
  {
    //c_this->entries[i] = rhs[i]; // implicit HSV-to-RGB conversion
    RGB_initByHSV(&(c_this->entries[i]), rhs[i]);
  }
}

void CRGBPalette32_init_by_programRGBPalette32 (CRGBPalette32* c_this, TProgmemRGBPalette32 rhs)
{
  for ( unsigned char i = 0; i < 32; i++)
  {
    RGB_initByColor(&(c_this->entries[i]), FL_PGM_READ_DWORD_NEAR(rhs + i));
  }
}

void CRGBPalette32_init_by_hsv_c1 (CRGBPalette32* c_this, CHSV c1)
{
  CRGB rgb;
  RGB_initByHSV (&rgb, c1);
  fill_solid_rgb (& (c_this->entries[0]), 32, rgb);
}

void CRGBPalette32_init_by_hsv_c1c2 (CRGBPalette32* c_this, CHSV c1, CHSV c2)
{
  fill_gradient_rgb_hsv_c1c2 (& (c_this->entries[0]), 32, c1, c2, SHORTEST_HUES, 1);
}
void CRGBPalette32_init_by_hsv_c1c2c3 (CRGBPalette32* c_this, CHSV c1, CHSV c2, CHSV c3)
{
  fill_gradient_rgb_hsv_c1c2c3 (& (c_this->entries[0]), 32, c1, c2, c3, SHORTEST_HUES, 1);
}
void CRGBPalette32_init_by_hsv_c1c2c3c4 (CRGBPalette32* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4)
{
  fill_gradient_rgb_hsv_c1c2c3c4 (& (c_this->entries[0]), 32, c1, c2, c3, c4, SHORTEST_HUES, 1);
}

void CRGBPalette32_init_by_rgb_c1 (CRGBPalette32* c_this, CRGB c1)
{
  fill_solid_rgb (& (c_this->entries[0]), 32, c1);
}
void CRGBPalette32_init_by_rgb_c1c2 (CRGBPalette32* c_this, CRGB c1, CRGB c2)
{
  fill_gradient_RGB_c1c2 (& (c_this->entries[0]), 32, c1, c2);
}
void CRGBPalette32_init_by_rgb_c1c2c3 (CRGBPalette32* c_this, CRGB c1, CRGB c2, CRGB c3)
{
  fill_gradient_RGB_c1c2c3 (& (c_this->entries[0]), 32, c1, c2, c3);
}
void CRGBPalette32_init_by_rgb_c1c2c3c4 (CRGBPalette32* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4)
{
  fill_gradient_RGB_c1c2c3c4 (& (c_this->entries[0]), 32, c1, c2, c3, c4);
}
void CRGBPalette32_init_by_rgbPalette (CRGBPalette32* c_this, CRGBPalette16 rhs16)
{
  UpscalePalette_16to32_rgb ( rhs16, c_this);
}
void CRGBPalette32_init_by_programRGBPalette16 (CRGBPalette32* c_this, TProgmemRGBPalette16 rhs)
{
  CRGBPalette16 p16;
  CRGBPalette16_init_by_programRGBPalette16 (&p16, rhs);
  CRGBPalette32_init_by_rgbPalette (c_this, p16);
}

int CRGBPalette32_is_equal (CRGBPalette32* c_this, CRGBPalette32 rhs)
{
  const unsigned char* p = (const unsigned char*) (& (c_this->entries[0]) );
  const unsigned char* q = (const unsigned char*) (& (rhs.entries[0]) );

  if ( p == q)
  {
    return 1;
  }

  for ( unsigned char i = 0; i < (sizeof (c_this->entries) ); i++)
  {
    if ( *p != *q)
    {
      return 0;
    }

    p++;
    q++;
  }

  return 1;
}

// Gradient palettes are loaded into CRGB16Palettes in such a way
// that, if possible, every color represented in the gradient palette
// is also represented in the CRGBPalette32.
// For example, consider a gradient palette that is all black except
// for a single, one-element-wide (1/256th!) spike of red in the middle:
//     0,   0,0,0
//   124,   0,0,0
//   125, 255,0,0  // one 1/256th-palette-wide red stripe
//   126,   0,0,0
//   255,   0,0,0
// A naive conversion of this 256-element palette to a 16-element palette
// might accidentally completely eliminate the red spike, rendering the
// palette completely black.
// However, the conversions provided here would attempt to include a
// the red stripe in the output, more-or-less as faithfully as possible.
// So in this case, the resulting CRGBPalette32 palette would have a red
// stripe in the middle which was 1/16th of a palette wide -- the
// narrowest possible in a CRGBPalette32.
// This means that the relative width of stripes in a CRGBPalette32
// will be, by definition, different from the widths in the gradient
// palette.  This code attempts to preserve "all the colors", rather than
// the exact stripe widths at the expense of dropping some colors.
void CRGBPalette32_init_by_programRGBGradientPalette (CRGBPalette32* c_this, TProgmemRGBGradientPalette_bytes progpal)
{
  TRGBGradientPaletteEntryUnion* progent = (TRGBGradientPaletteEntryUnion*) (progpal);
  TRGBGradientPaletteEntryUnion u;
  // Count entries
  unsigned short count = 0;

  do
  {
    u.dword = FL_PGM_READ_DWORD_NEAR (progent + count);
    count++;;
  } while ( u.index != 255);

  char lastSlotUsed = -1;
  u.dword = FL_PGM_READ_DWORD_NEAR ( progent);
  CRGB rgbstart = struct_RGB_by_r_g_b( u.r, u.g, u.b);
  int indexstart = 0;
  unsigned char istart8 = 0;
  unsigned char iend8 = 0;

  while ( indexstart < 255)
  {
    progent++;
    u.dword = FL_PGM_READ_DWORD_NEAR ( progent);
    int indexend  = u.index;
    CRGB rgbend = struct_RGB_by_r_g_b( u.r, u.g, u.b);
    istart8 = indexstart / 8;
    iend8   = indexend   / 8;

    if ( count < 16)
    {
      if ( (istart8 <= lastSlotUsed) && (lastSlotUsed < 31) )
      {
        istart8 = lastSlotUsed + 1;

        if ( iend8 < istart8)
        {
          iend8 = istart8;
        }
      }

      lastSlotUsed = iend8;
    }

    fill_gradient_RGB (& (c_this->entries[0]), istart8, rgbstart, iend8, rgbend);
    indexstart = indexend;
    rgbstart = rgbend;
  }
}

void CRGBPalette256_init_by_c16 (CRGBPalette256* c_this, CRGB c00, CRGB c01, CRGB c02, CRGB c03,
                                 CRGB c04, CRGB c05, CRGB c06, CRGB c07,
                                 CRGB c08, CRGB c09, CRGB c10, CRGB c11,
                                 CRGB c12, CRGB c13, CRGB c14, CRGB c15 )
{
  CRGBPalette16 p16;
  CRGBPalette16_init_by_c16 (&p16, c00, c01, c02, c03, c04, c05, c06, c07, c08, c09, c10, c11, c12, c13, c14, c15);
};

void CRGBPalette256_init_by_self_type (CRGBPalette256* c_this, CRGBPalette256 rhs)
{
  memmove8 (& (c_this->entries[0]), & (rhs.entries[0]), sizeof (c_this->entries) );
}

void CRGBPalette256_init_by_rgb (CRGBPalette256* c_this, CRGB rhs[256])
{
  memmove8 (& (c_this->entries[0]), & (rhs[0]), sizeof (c_this->entries) );
}

void CRGBPalette256_init_by_HSVPalette256 (CRGBPalette256* c_this,                   CHSVPalette256 rhs)
{
  for ( int i = 0; i < 256; i++)
  {
    //c_this->entries[i] = rhs.entries[i]; // implicit HSV-to-RGB conversion
    RGB_initByHSV(&(c_this->entries[i]), rhs.entries[i]);
  }
}

void CRGBPalette256_init_by_hsv (CRGBPalette256* c_this, CHSV rhs[256])
{
  for ( int i = 0; i < 256; i++)
  {
    //c_this->entries[i] = rhs[i]; // implicit HSV-to-RGB conversion
    RGB_initByHSV(&(c_this->entries[i]), rhs[i]);
  }
}

void CRGBPalette256_init_by_RGBPalette16 (CRGBPalette256* c_this, CRGBPalette16 rhs16)
{
  UpscalePalette_16to256_rgb ( rhs16, c_this);
}

void CRGBPalette256_init_by_ProgramRGBPalette16 (CRGBPalette256* c_this, TProgmemRGBPalette16 rhs)
{
  CRGBPalette16 p16;
  CRGBPalette16_init_by_programRGBPalette16 (&p16, rhs);
  CRGBPalette256_init_by_RGBPalette16 (c_this, p16);
}

int CRGBPalette256_is_equal (CRGBPalette256* c_this, CRGBPalette256 rhs)
{
  const unsigned char* p = (const unsigned char*) (& (c_this->entries[0]) );
  const unsigned char* q = (const unsigned char*) (& (rhs.entries[0]) );

  if ( p == q)
  {
    return 1;
  }

  for ( unsigned short i = 0; i < (sizeof (c_this->entries) ); i++)
  {
    if ( *p != *q)
    {
      return 0;
    }

    p++;
    q++;
  }

  return 1;
}

void CRGBPalette256_init_by_hsv_c1 (CRGBPalette256* c_this, CHSV c1)
{
  CRGB rgb;
  RGB_initByHSV (&rgb, c1);
  fill_solid_rgb (& (c_this->entries[0]), 256, rgb);
}

void CRGBPalette256_init_by_hsv_c1c2 (CRGBPalette256* c_this, CHSV c1, CHSV c2)
{
  fill_gradient_rgb_hsv_c1c2 (& (c_this->entries[0]), 256, c1, c2, SHORTEST_HUES, 1);
}

void CRGBPalette256_init_by_hsv_c1c2c3 (CRGBPalette256* c_this, CHSV c1, CHSV c2, CHSV c3)
{
  fill_gradient_rgb_hsv_c1c2c3 (& (c_this->entries[0]), 256, c1, c2, c3, SHORTEST_HUES, 1);
}

void CRGBPalette256_init_by_hsv_c1c2c3c4 (CRGBPalette256* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4)
{
  fill_gradient_rgb_hsv_c1c2c3c4 (& (c_this->entries[0]), 256, c1, c2, c3, c4, SHORTEST_HUES, 1);
}

void CRGBPalette256_init_by_rgb_c1 (CRGBPalette256* c_this, CRGB c1)
{
  fill_solid_rgb (& (c_this->entries[0]), 256, c1);
}

void CRGBPalette256_init_by_rgb_c1c2 (CRGBPalette256* c_this, CRGB c1, CRGB c2)
{
  fill_gradient_RGB_c1c2 (& (c_this->entries[0]), 256, c1, c2);
}

void CRGBPalette256_init_by_rgb_c1c2c3 (CRGBPalette256* c_this, CRGB c1, CRGB c2, CRGB c3)
{
  fill_gradient_RGB_c1c2c3 (& (c_this->entries[0]), 256, c1, c2, c3);
}

void CRGBPalette256_init_by_rgb_c1c2c3c4 (CRGBPalette256* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4)
{
  fill_gradient_RGB_c1c2c3c4 (& (c_this->entries[0]), 256, c1, c2, c3, c4);
}

void CRGBPalette256_init_by_programRGBGradientPalette (CRGBPalette256* c_this, TProgmemRGBGradientPalette_bytes progpal )
{
  TRGBGradientPaletteEntryUnion* progent = (TRGBGradientPaletteEntryUnion*) (progpal);
  TRGBGradientPaletteEntryUnion u;
  u.dword = FL_PGM_READ_DWORD_NEAR ( progent);
  CRGB rgbstart = struct_RGB_by_r_g_b( u.r, u.g, u.b);
  int indexstart = 0;

  while ( indexstart < 255)
  {
    progent++;
    u.dword = FL_PGM_READ_DWORD_NEAR ( progent);
    int indexend  = u.index;
    CRGB rgbend = struct_RGB_by_r_g_b( u.r, u.g, u.b);
    fill_gradient_RGB (& (c_this->entries[0]), indexstart, rgbstart, indexend, rgbend);
    indexstart = indexend;
    rgbstart = rgbend;
  }
}

// Fill a range of LEDs with a sequece of entryies from a palette
                                    
void fill_palette_CRGBPalette16(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                      CRGBPalette16 pal, unsigned char brightness, TBlendType blendType)
{
  //FILL_PALETTE_FUNC(RGBColorFromRGBPalette16)
  unsigned char colorIndex = startIndex;
  for( unsigned short i = 0; i < N; i++) 
  { 
    L[i] = RGBColorFromRGBPalette16( pal, colorIndex, brightness, blendType); 
    colorIndex += incIndex; 
  }
}

void fill_palette_ProgmemRGBPalette16(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                          TProgmemRGBPalette16 pal, unsigned char brightness, TBlendType blendType)
{
  //FILL_PALETTE_FUNC(RGBColorFromProgmemRGBPalette16)
  unsigned char colorIndex = startIndex;
  for( unsigned short i = 0; i < N; i++) 
  { 
    L[i] = RGBColorFromProgmemRGBPalette16( pal, colorIndex, brightness, blendType); 
    colorIndex += incIndex; 
  }
}
                                    
void fill_palette_CRGBPalette256(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                      CRGBPalette256 pal, unsigned char brightness, TBlendType blendType)
{
  //FILL_PALETTE_FUNC(RGBColorFromRGBPalette256)
  unsigned char colorIndex = startIndex;
  for( unsigned short i = 0; i < N; i++) 
  { 
    L[i] = RGBColorFromRGBPalette256( pal, colorIndex, brightness, blendType); 
    colorIndex += incIndex; 
  }
}
                                                                                          
void fill_palette_CRGBPalette32(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                        CRGBPalette32 pal, unsigned char brightness, TBlendType blendType)
{
  //FILL_PALETTE_FUNC(RGBColorFromRGBPalette32)
  unsigned char colorIndex = startIndex;
  for( unsigned short i = 0; i < N; i++) 
  { 
    L[i] = RGBColorFromRGBPalette32( pal, colorIndex, brightness, blendType); 
    colorIndex += incIndex; 
  }
}

void fill_palette_ProgmemRGBPalette32(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                          TProgmemRGBPalette32 pal, unsigned char brightness, TBlendType blendType)
{
  //FILL_PALETTE_FUNC(RGBColorFromProgramRGBPalette32)
  unsigned char colorIndex = startIndex;
  for( unsigned short i = 0; i < N; i++) 
  { 
    L[i] = RGBColorFromProgramRGBPalette32( pal, colorIndex, brightness, blendType); 
    colorIndex += incIndex; 
  }
}

#define MAP_DATA_INTO_COLORS_THROUGH_PALETTE_FUNC(color_palette) \
  for ( unsigned short i = 0; i < dataCount; i++) \
  { \
    unsigned char d = dataArray[i]; \
    CRGB rgb = color_palette( pal, d, brightness, blendType); \
    if ( opacity == 255 ) \
    { \
      targetColorArray[i] = rgb; \
    } \
    else \
    { \
      RGB_nscale8(&targetColorArray[i], 256 - opacity); \
      RGB_nscale8_video(&rgb, opacity); \
      targetColorArray[i] += rgb; \
    } \
  }


//default  brightness=255, unsigned char opacity=255, blendType = LINEARBLEND, ******default value*********
void map_data_into_colors_through_CRGBPalette16 (unsigned char* dataArray, unsigned short dataCount,
                                                              CRGB* targetColorArray, CRGBPalette16 pal,
                                                              unsigned char brightness, unsigned char opacity,
                                                              TBlendType blendType)
{
  //MAP_DATA_INTO_COLORS_THROUGH_PALETTE_FUNC(RGBColorFromRGBPalette16)
  for ( unsigned short i = 0; i < dataCount; i++) 
  { 
    unsigned char d = dataArray[i]; 
    CRGB rgb = RGBColorFromRGBPalette16( pal, d, brightness, blendType); 
    if ( opacity == 255 ) 
    { 
      RGB_initByRGB(&(targetColorArray[i]), rgb);
    } 
    else 
    { 
      RGB_nscale8(&targetColorArray[i], 256 - opacity); 
      RGB_nscale8_video(&rgb, opacity); 
      RGB_addRGB(&(targetColorArray[i]), rgb);
    } 
  }
}

//default  brightness=255, unsigned char opacity=255, blendType = LINEARBLEND, ******default value*********
void map_data_into_colors_through_ProgmemRGBPalette16 (unsigned char* dataArray, unsigned short dataCount,
                                                                  CRGB* targetColorArray, TProgmemRGBPalette16 pal,
                                                                  unsigned char brightness, unsigned char opacity,
                                                                  TBlendType blendType)
{
  //MAP_DATA_INTO_COLORS_THROUGH_PALETTE_FUNC(RGBColorFromProgmemRGBPalette16)
  for (unsigned short i = 0; i < dataCount; i++)
  {
    unsigned char d = dataArray[i];
    CRGB rgb = RGBColorFromProgmemRGBPalette16(pal, d, brightness, blendType);
    if (opacity == 255)
    {
      RGB_initByRGB(&(targetColorArray[i]), rgb);
    }
    else
    {
      RGB_nscale8(&targetColorArray[i], 256 - opacity);
      RGB_nscale8_video(&rgb, opacity);
      RGB_addRGB(&(targetColorArray[i]), rgb);
    }
  }
}
//default  brightness=255, unsigned char opacity=255, blendType = LINEARBLEND, ******default value*********

void map_data_into_colors_through_CRGBPalette256(unsigned char* dataArray, unsigned short dataCount,
                                                                CRGB* targetColorArray, CRGBPalette256 pal,
                                                                unsigned char brightness, unsigned char opacity,
                                                                TBlendType blendType)
{
  //MAP_DATA_INTO_COLORS_THROUGH_PALETTE_FUNC(RGBColorFromRGBPalette256)
  for (unsigned short i = 0; i < dataCount; i++)
  {
    unsigned char d = dataArray[i];
    CRGB rgb = RGBColorFromRGBPalette256(pal, d, brightness, blendType);
    if (opacity == 255)
    {
      RGB_initByRGB(&(targetColorArray[i]), rgb);
    }
    else
    {
      RGB_nscale8(&targetColorArray[i], 256 - opacity);
      RGB_nscale8_video(&rgb, opacity);
      RGB_addRGB(&(targetColorArray[i]), rgb);
    }
  }
}
//default  brightness=255, unsigned char opacity=255, blendType = LINEARBLEND, ******default value*********
void map_data_into_colors_through_CRGBPalette32(unsigned char* dataArray, unsigned short dataCount,
                                                                CRGB* targetColorArray, CRGBPalette32 pal,
                                                                unsigned char brightness, unsigned char opacity,
                                                                TBlendType blendType)
{
  //MAP_DATA_INTO_COLORS_THROUGH_PALETTE_FUNC(RGBColorFromRGBPalette32)
  for (unsigned short i = 0; i < dataCount; i++)
  {
    unsigned char d = dataArray[i];
    CRGB rgb = RGBColorFromRGBPalette32(pal, d, brightness, blendType);
    if (opacity == 255)
    {
      RGB_initByRGB(&(targetColorArray[i]), rgb);
    }
    else
    {
      RGB_nscale8(&targetColorArray[i], 256 - opacity);
      RGB_nscale8_video(&rgb, opacity);
      RGB_addRGB(&(targetColorArray[i]), rgb);
    }
  }
}
//default  brightness=255, unsigned char opacity=255, blendType = LINEARBLEND, ******default value*********
void map_data_into_colors_through_ProgmemRGBPalette32(unsigned char* dataArray, unsigned short dataCount,
                                                                CRGB* targetColorArray, TProgmemRGBPalette32 pal,
                                                                unsigned char brightness, unsigned char opacity,
                                                                TBlendType blendType)
{
  //MAP_DATA_INTO_COLORS_THROUGH_PALETTE_FUNC(RGBColorFromProgramRGBPalette32)
  for (unsigned short i = 0; i < dataCount; i++)
  {
    unsigned char d = dataArray[i];
    CRGB rgb = RGBColorFromProgramRGBPalette32(pal, d, brightness, blendType);
    if (opacity == 255)
    {
      RGB_initByRGB(&(targetColorArray[i]), rgb);
    }
    else
    {
      RGB_nscale8(&targetColorArray[i], 256 - opacity);
      RGB_nscale8_video(&rgb, opacity);
      RGB_addRGB(&(targetColorArray[i]), rgb);
    }
  }
}

void nblendPaletteTowardPalette ( CRGBPalette16 current, CRGBPalette16 target, unsigned char maxChanges)
{
  unsigned char* p1;
  unsigned char* p2;
  unsigned char  changes = 0;
  p1 = (unsigned char*) current.entries;
  p2 = (unsigned char*) target.entries;
  const unsigned char totalChannels = sizeof (CRGBPalette16);

  for ( unsigned char i = 0; i < totalChannels; i++)
  {
    // if the values are equal, no changes are needed
    if ( p1[i] == p2[i] )
    {
      continue;
    }

    // if the current value is less than the target, increase it by one
    if ( p1[i] < p2[i] )
    {
      p1[i]++;
      changes++;
    }

    // if the current value is greater than the target,
    // increase it by one (or two if it's still greater).
    if ( p1[i] > p2[i] )
    {
      p1[i]--; changes++;

      if ( p1[i] > p2[i] )
      {
        p1[i]--;
      }
    }

    // if we've hit the maximum number of changes, exit
    if ( changes >= maxChanges)
    {
      break;
    }
  }
}


unsigned char applyGamma_video_bright_gamma ( unsigned char brightness, float gamma)
{
  float orig;
  float adj;
  orig = (float)((float) (brightness) / (255.0));
  adj = (float)(pow ( orig, gamma)   * (255.0));
  unsigned char result = (unsigned char) (adj);

  if ( (brightness > 0) && (result == 0) )
  {
    result = 1; // never gamma-adjust a positive number down to zero
  }

  return result;
}

CRGB applyGamma_video_gamm ( CRGB orig, float gamma)
{
  CRGB adj;
  adj.r = applyGamma_video_bright_gamma ( orig.r, gamma);
  adj.g = applyGamma_video_bright_gamma ( orig.g, gamma);
  adj.b = applyGamma_video_bright_gamma ( orig.b, gamma);
  return adj;
}

CRGB applyGamma_video_gammaRGB ( CRGB orig, float gammaR, float gammaG, float gammaB)
{
  CRGB adj;
  adj.r = applyGamma_video_bright_gamma ( orig.r, gammaR);
  adj.g = applyGamma_video_bright_gamma ( orig.g, gammaG);
  adj.b = applyGamma_video_bright_gamma ( orig.b, gammaB);
  return adj;
}

CRGB napplyGamma_video_gamma ( CRGB rgb, float gamma)
{
  rgb = applyGamma_video_gamm ( rgb, gamma);
  return rgb;
}

CRGB napplyGamma_video_rammaRGB ( CRGB rgb, float gammaR, float gammaG, float gammaB)
{
  rgb = applyGamma_video_gammaRGB ( rgb, gammaR, gammaG, gammaB);
  return rgb;
}

void napplyGamma_video_count_gamma ( CRGB* rgbarray, unsigned short count, float gamma)
{
  for ( unsigned short i = 0; i < count; i++)
  {
    rgbarray[i] = applyGamma_video_gamm ( rgbarray[i], gamma);
  }
}

void napplyGamma_video_count_gammaRGB ( CRGB* rgbarray, unsigned short count, float gammaR, float gammaG, float gammaB)
{
  for ( unsigned short i = 0; i < count; i++)
  {
    rgbarray[i] = applyGamma_video_gammaRGB ( rgbarray[i], gammaR, gammaG, gammaB);
  }
}


