#ifndef __LED_DRIVER_H
#define __LED_DRIVER_H
  
#include "tuya_adapter_platform.h"


#ifdef __cplusplus
  extern "C" {
#endif

#define FASTLED_DRIVER        1
#define WS2812FX_DRIVER       0

#define RGB_4BITS             1

#define BYTES_1_PIXEL_BK_BUF  3
#define BYTES_1_PIXEL_FT_BUF  (BYTES_1_PIXEL_BK_BUF * 4)
#define DATA_BUF_PIEXL        12
#define COLORDIMMER           200


#if LIGHT_SK2812_config        // 5V灯带
#define DISPLAY_BUF_MAX_PIXEL 52*3
#define DATA_BUF_SIZE         DISPLAY_BUF_MAX_PIXEL*DATA_BUF_PIEXL
#define MARQUEE_MAXNUM        DISPLAY_BUF_MAX_PIXEL/3
#define DISPLAY_FIRINGNUMS    60
#define H_BIT_1 0xc0  
#define L_BIT_1 0x0c  
#define H_BIT_0 0x80  
#define L_BIT_0 0x08  
#else
  #if LIGHT_DEFALT_RGB_or_GRB    // 12V 灯带宏定义
  #define  DISPLAY_BUF_MAX_PIXEL 52
  #define  DATA_BUF_SIZE         DISPLAY_BUF_MAX_PIXEL*DATA_BUF_PIEXL
  #define  MARQUEE_MAXNUM        DISPLAY_BUF_MAX_PIXEL
  #define DISPLAY_FIRINGNUMS     20
  #else
    #if LIGHT_WS2812_RGBC_BALL   // 12V 球泡灯带
    #define  DISPLAY_BUF_MAX_PIXEL 32
    #define  DATA_BUF_SIZE         DISPLAY_BUF_MAX_PIXEL*(DATA_BUF_PIEXL+DATA_BUF_PIEXL)
    #define  MARQUEE_MAXNUM        DISPLAY_BUF_MAX_PIXEL
    #define  DISPLAY_FIRINGNUMS    60
    #else                         // 5V灯带
    #define  DISPLAY_BUF_MAX_PIXEL 12 //52*3
    #define  DATA_BUF_SIZE        DISPLAY_BUF_MAX_PIXEL*DATA_BUF_PIEXL
    #define  MARQUEE_MAXNUM       DISPLAY_BUF_MAX_PIXEL/3
    #define DISPLAY_FIRINGNUMS    60
    #endif
  #endif
#define H_BIT_1 0xe0  
#define L_BIT_1 0x0e  
#define H_BIT_0 0x80  
#define L_BIT_0 0x08   
#endif

  // SPI1
#define SPI1_MOSI  PA_23
#define SPI1_MISO  PA_22
#define SPI1_SCLK  PA_18
#define SPI1_CS    PA_19

#define WS2812_RGB           3
  
  
#define SCLK_FREQ_TEST      3600000
#define SPI_DMA_DEMO        0
#define TEST_LOOP           100
#define GPIO_SYNC_PIN       PA_5
#define BASESCENE_TIMES     500

extern  unsigned int  _myfront_len;

void Fastled_ReadData(uint8_t *buf , uint16_t offset);
void Ws2812_DriverInit(void);
int is_led_busy(void);
void set_driver_busy(void);
void get_driver_len(int len);
void spi_DmaInit(void);
OPERATE_RET spi_IoInit(void);
void SetAllColor(uint32_t colors,uint16_t len);
int spi_threadInit(void);
void FastLedShow(void);

#ifdef __cplusplus
}
#endif

#endif


