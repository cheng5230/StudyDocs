#ifndef __INC_LIB8TION_MATH_H
#define __INC_LIB8TION_MATH_H

#include "fastled_config.h"
#include "scale8.h"

///@ingroup lib8tion

///@defgroup Math Basic math operations
/// Fast, efficient 8-bit math functions specifically
/// designed for high-performance LED programming.
///
/// Because of the AVR(Arduino) and ARM assembly language
/// implementations provided, using these functions often
/// results in smaller and faster code than the equivalent
/// program using plain "C" arithmetic and logic.
///@{


/// add one byte to another, saturating at 0xFF
/// @param i - first byte to add
/// @param j - second byte to add
/// @returns the sum of i & j, capped at 0xFF
static inline unsigned char qadd8 ( unsigned char i, unsigned char j)
{
  unsigned int t = i + j;
  if ( t > 255)
  {
    t = 255;
  }
  return t;
}

/// Add one byte to another, saturating at 0x7F
/// @param i - first byte to add
/// @param j - second byte to add
/// @returns the sum of i & j, capped at 0xFF
static inline char qadd7 ( char i, char j)
{
  short t = i + j;
  if ( t > 127)
  {
    t = 127;
  }
  return (char)t;
}

/// subtract one byte from another, saturating at 0x00
/// @returns i - j with a floor of 0
static inline unsigned char qsub8 ( unsigned char i, unsigned char j)
{
  int t = i - j;
  if ( t < 0)
  {
    t = 0;
  }
  return t;
}

/// add one byte to another, with one byte result
static inline unsigned char add8 ( unsigned char i, unsigned char j)
{
  int t = i + j;
  return t;
}

/// add one byte to another, with one byte result
static inline unsigned short add8to16 ( unsigned char i, unsigned short j)
{
  unsigned short t = i + j;
  return t;
}


/// subtract one byte from another, 8-bit result
static inline unsigned char sub8 ( unsigned char i, unsigned char j)
{
  int t = i - j;
  return t;
}

/// Calculate an integer average of two unsigned
///       8-bit integer values (unsigned char).
///       Fractional results are rounded down, e.g. avg8(20,41) = 30
static inline unsigned char avg8 ( unsigned char i, unsigned char j)
{
  return (i + j) >> 1;
}

/// Calculate an integer average of two unsigned
///       16-bit integer values (unsigned short).
///       Fractional results are rounded down, e.g. avg16(20,41) = 30
static inline unsigned short avg16 ( unsigned short i, unsigned short j)
{
  return (unsigned int) ( (unsigned int) (i) + (unsigned int) (j) ) >> 1;
}


/// Calculate an integer average of two signed 7-bit
///       integers (char)
///       If the first argument is even, result is rounded down.
///       If the first argument is odd, result is result up.
static inline char avg7 ( char i, char j)
{
  return ( (i + j) >> 1) + (i & 0x1);
}

/// Calculate an integer average of two signed 15-bit
///       integers (short)
///       If the first argument is even, result is rounded down.
///       If the first argument is odd, result is result up.
static inline short avg15 ( short i, short j)
{
  return ( (int) ( (int) (i) + (int) (j) ) >> 1) + (i & 0x1);
}


///       Calculate the remainder of one unsigned 8-bit
///       value divided by anoter, aka A % M.
///       Implemented by repeated subtraction, which is
///       very compact, and very fast if A is 'probably'
///       less than M.  If A is a large multiple of M,
///       the loop has to execute multiple times.  However,
///       even in that case, the loop is only two
///       instructions long on AVR, i.e., quick.
static inline unsigned char mod8 ( unsigned char a, unsigned char m)
{
  while ( a >= m)
  {
    a -= m;
  }

  return a;
}

///          Add two numbers, and calculate the modulo
///          of the sum and a third number, M.
///          In other words, it returns (A+B) % M.
///          It is designed as a compact mechanism for
///          incrementing a 'mode' switch and wrapping
///          around back to 'mode 0' when the switch
///          goes past the end of the available range.
///          e.g. if you have seven modes, this switches
///          to the next one and wraps around if needed:
///            mode = addmod8( mode, 1, 7);
///static inlineSee 'mod8' for notes on performance.
static inline unsigned char addmod8 ( unsigned char a, unsigned char b, unsigned char m)
{
  a += b;

  while ( a >= m)
  {
    a -= m;
  }

  return a;
}

///          Subtract two numbers, and calculate the modulo
///          of the difference and a third number, M.
///          In other words, it returns (A-B) % M.
///          It is designed as a compact mechanism for
///          incrementing a 'mode' switch and wrapping
///          around back to 'mode 0' when the switch
///          goes past the end of the available range.
///          e.g. if you have seven modes, this switches
///          to the next one and wraps around if needed:
///            mode = addmod8( mode, 1, 7);
///static inlineSee 'mod8' for notes on performance.
static inline unsigned char submod8 ( unsigned char a, unsigned char b, unsigned char m)
{
  a -= b;

  while ( a >= m)
  {
    a -= m;
  }

  return a;
}

/// 8x8 bit multiplication, with 8 bit result
static inline unsigned char mul8 ( unsigned char i, unsigned char j)
{
  return ( (int) i * (int) (j) ) & 0xFF;
}


/// saturating 8x8 bit multiplication, with 8 bit result
/// @returns the product of i * j, capping at 0xFF
static inline unsigned char qmul8 ( unsigned char i, unsigned char j)
{
  int p = ( (int) i * (int) (j) );

  if ( p > 255)
  {
    p = 255;
  }

  return p;
}


/// take abs() of a signed 8-bit unsigned char
static inline char abs8 ( char i)
{
  if ( i < 0)
  {
    i = -i;
  }

  return i;
}

///         square root for 16-bit integers
///         About three times faster and five times smaller
///         than Arduino's general sqrt on AVR.
static inline unsigned char sqrt16 (unsigned short x)
{
  if ( x <= 1)
  {
    return (unsigned char)x;
  }

  unsigned char low = 1; // lower bound
  unsigned char hi, mid;

  if ( x > 7904)
  {
    hi = 255;
  }
  else
  {
    hi = (x >> 5) + 8; // initial estimate for upper bound
  }

  do
  {
    mid = (low + hi) >> 1;

    if ( (unsigned short) (mid * mid) > x)
    {
      hi = mid - 1;
    }
    else
    {
      if ( mid == 255)
      {
        return 255;
      }

      low = mid + 1;
    }
  } while (hi >= low);

  return low - 1;
}

/// blend a variable proproportion(0-255) of one byte to another
/// @param a - the starting byte value
/// @param b - the byte value to blend toward
/// @param amountOfB - the proportion (0-255) of b to blend
/// @returns a byte value between a and b, inclusive
static inline unsigned char blend8 ( unsigned char a, unsigned char b, unsigned char amountOfB)
{
  unsigned short partial;
  unsigned char result;
  unsigned char amountOfA = 255 - amountOfB;
  partial = (a * amountOfA);
#if (FASTLED_SCALE8_FIXED == 1)
  partial += a;
  //partial = add8to16( a, partial);
#endif
  partial += (b * amountOfB);
#if (FASTLED_SCALE8_FIXED == 1)
  partial += b;
  //partial = add8to16( b, partial);
#endif
  result = partial >> 8;
  return result;
}

///@}
#endif
