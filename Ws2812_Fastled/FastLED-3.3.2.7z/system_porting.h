#ifndef __SYSTEM_PORTING_H_
#define __SYSTEM_PORTING_H_

#include "tuya_adapter_platform.h"

#ifndef NULL
#define NULL (void*)(0)
#endif

#define __DEBUG_MSG__
#ifdef __DEBUG_MSG__
#define LED_DEBUG(fmt, ...)
#define LED_ERR(fmt, ...)
#else
#define LED_DEBUG(fmt, ...)
#define LED_ERR(fmt, ...)
#endif

#define __DEBUG_MEM__
#ifdef __DEBUG_MEM__
void* led_user_malloc(char* func, unsigned int size);
void led_user_free(char* func, void* addr);

#define LED_MALLOC(x) led_user_malloc((char*)__FUNCTION__, x)
#define LED_FREE(x) led_user_free((char*)__FUNCTION__, x)
#else
#include <stdlib.h>
#define LED_MALLOC malloc
#define LED_FREE free
#endif

int LED_CreateMutexAndInit(MUTEX_HANDLE mutex);
void LED_MutexLock(MUTEX_HANDLE mutex);
void LED_MutexUnLock(MUTEX_HANDLE mutex);
void system_sleep_ms(unsigned long ms);
unsigned int get_system_millisecond();
int Thread_Fastled_Init(void);

extern SEM_HANDLE __ledShow;

#endif

