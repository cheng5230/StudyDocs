/****************************************************************************************************//**
 * @file     trace_task_schedule.h
 *
 * @brief
 *
 * @version  v0.1
 * @date     2018-11-05
 *
 * @note
 *******************************************************************************************************/
#ifndef _TRACE_TASK_SCHEDULE_H_
#define _TRACE_TASK_SCHEDULE_H_

#include "trace_common.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_TRACE_TASK_SCHEDULE_H_*/

/******************* (C) COPYRIGHT 2015 Realtek Semiconductor Corporation *****END OF FILE****/
