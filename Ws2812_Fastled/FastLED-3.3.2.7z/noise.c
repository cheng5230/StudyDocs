#include <string.h>
#include <stdlib.h>
#include "pixeltypes.h"
#define P(x) (*((const  unsigned char*)(p + x)))

static unsigned char const p[] = { 151, 160, 137, 91,  90,  15,  131, 13,  201, 95,  96,  53,  194, 233, 7,   225, 
                                   140, 36,  103, 30,  69,  142, 8,   99,  37,  240, 21,  10,  23,  190, 6,   148, 
                                   247, 120, 234, 75,  0,   26,  197, 62,  94,  252, 219, 203, 117, 35,  11,  32, 
                                   57,  177, 33,  88,  237, 149, 56,  87,  174, 20,  125, 136, 171, 168, 68,  175, 
                                   74,  165, 71,  134, 139, 48,  27,  166, 77,  146, 158, 231, 83,  111, 229, 122, 
                                   60,  211, 133, 230, 220, 105, 92,  41,  55,  46,  245, 40,  244, 102, 143, 54, 
                                   65,  25,  63,  161, 1,   216, 80,  73,  209, 76,  132, 187, 208, 89,  18,  169, 
                                   200, 196, 135, 130, 116, 188, 159, 86,  164, 100, 109, 198, 173, 186, 3,   64, 
                                   52,  217, 226, 250, 124, 123, 5,   202, 38,  147, 118, 126, 255, 82,  85,  212, 
                                   207, 206, 59,  227, 47,  16,  58,  17,  182, 189, 28,  42,  223, 183, 170, 213, 
                                   119, 248, 152, 2,   44,  154, 163, 70,  221, 153, 101, 155, 167, 43,  172, 9,
                                   129, 22,  39,  253, 19,  98,  108, 110, 79,  113, 224, 232, 178, 185, 112, 104, 
                                   218, 246, 97,  228, 251, 34,  242, 193, 238, 210, 144, 12,  191, 179, 162, 241, 
                                   81,  51,  145, 235, 249, 14,  239, 107, 49,  192, 214, 31,  181, 199, 106, 157, 
                                   184, 84,  204, 176, 115, 121, 50,  45,  127, 4,   150, 254, 138, 236, 205, 93, 
                                   222, 114, 67,  29,  24,  72,  243, 141, 128, 195, 78,  66,  215, 61,  156, 180, 151
                                 };

#if FASTLED_NOISE_ALLOW_AVERAGE_TO_OVERFLOW == 1
  #define AVG15(U,V) (((U)+(V)) >> 1)
#else
  #define AVG15(U,V) (avg15((U),(V)))
#endif

// See fastled_config.h for notes on this;
// "#define FASTLED_NOISE_FIXED 1" is the correct value
#if FASTLED_NOISE_FIXED == 0
  #define EASE8(x)  (FADE(x) )
  #define EASE16(x) (FADE(x) )
#else
  #define EASE8(x)  (ease8InOutQuad(x) )
  #define EASE16(x) (ease16InOutQuad(x))
#endif
//

#define FADE(x) scale16(x,x)
#define LERP(a,b,u) lerp15by16(a,b,u)
static short inline  grad16_xyz (unsigned char hash, short x, short y, short z)
{
  hash = hash&15;
  short u = hash<8?x:y;
  short v = hash<4?y:hash==12||hash==14?x:z;

  if (hash&1)
  {
    u = -u;
  }

  if (hash&2)
  {
    v = -v;
  }

  return AVG15 (u, v);
}

static short inline grad16_xy (unsigned char hash, short x, short y)
{
  hash = hash & 7;
  short u, v;

  if (hash < 4)
  {
    u = x;
    v = y;
  }
  else
  {
    u = y;
    v = x;
  }

  if (hash&1)
  {
    u = -u;
  }

  if (hash&2)
  {
    v = -v;
  }

  return AVG15 (u, v);
}

static short inline grad16_x (unsigned char hash, short x)
{
  hash = hash & 15;
  short u, v;

  if (hash > 8)
  {
    u=x;
    v=x;
  }
  else if (hash < 4)
  {
    u=x;
    v=1;
  }
  else
  {
    u=1;
    v=x;
  }

  if (hash&1)
  {
    u = -u;
  }

  if (hash&2)
  {
    v = -v;
  }

  return AVG15 (u, v);
}

// selectBasedOnHashBit performs this:
//   result = (hash & (1<<bitnumber)) ? a : b
// but with an AVR asm version that's smaller and quicker than C
// (and probably not worth including in lib8tion)
static char inline selectBasedOnHashBit (unsigned char hash, unsigned char bitnumber, char a, char b)
{
  char result;
  result = (hash & (1<<bitnumber) ) ? a : b;
  return result;
}

static char  inline grad8_xyz (unsigned char hash, char x, char y, char z)
{
  hash &= 0xF;
  char u, v;
  //u = (hash&8)?y:x;
  u = selectBasedOnHashBit ( hash, 3, y, x);
  v = hash<4?y:hash==12||hash==14?x:z;

  if (hash&1)
  {
    u = -u;
  }

  if (hash&2)
  {
    v = -v;
  }

  return avg7 (u, v);
}

static char inline grad8_xy (unsigned char hash, char x, char y)
{
  // since the tests below can be done bit-wise on the bottom
  // three bits, there's no need to mask off the higher bits
  //  hash = hash & 7;
  char u, v;

  if ( hash & 4)
  {
    u = y; v = x;
  }
  else
  {
    u = x; v = y;
  }

  if (hash&1)
  {
    u = -u;
  }

  if (hash&2)
  {
    v = -v;
  }

  return avg7 (u, v);
}

static char inline grad8_x (unsigned char hash, char x)
{
  // since the tests below can be done bit-wise on the bottom
  // four bits, there's no need to mask off the higher bits
  //  hash = hash & 15;
  char u, v;

  if (hash & 8)
  {
    u=x; v=x;
  }
  else
  {
    if (hash & 4)
    {
      u=1; v=x;
    }
    else
    {
      u=x; v=1;
    }
  }

  if (hash&1)
  {
    u = -u;
  }

  if (hash&2)
  {
    v = -v;
  }

  return avg7 (u, v);
}

static char inline lerp7by8 ( char a, char b, fract8 frac)
{
  // char delta = b - a;
  // short prod = (unsigned short)delta * (unsigned short)frac;
  // char scaled = prod >> 8;
  // char result = a + scaled;
  // return result;
  char result;

  if ( b > a)
  {
    unsigned char delta = b - a;
    unsigned char scaled = scale8 ( delta, frac);
    result = a + scaled;
  }
  else
  {
    unsigned char delta = a - b;
    unsigned char scaled = scale8 ( delta, frac);
    result = a - scaled;
  }

  return result;
}

short inoise16_raw_xyz (unsigned int x, unsigned int y, unsigned int z)
{
  // Find the unit cube containing the point
  unsigned char X = (x>>16) &0xFF;
  unsigned char Y = (y>>16) &0xFF;
  unsigned char Z = (z>>16) &0xFF;
  // Hash cube corner coordinates
  unsigned char A = P (X)+Y;
  unsigned char AA = P (A)+Z;
  unsigned char AB = P (A+1)+Z;
  unsigned char B = P (X+1)+Y;
  unsigned char BA = P (B) + Z;
  unsigned char BB = P (B+1)+Z;
  // Get the relative position of the point in the cube
  unsigned short u = x & 0xFFFF;
  unsigned short v = y & 0xFFFF;
  unsigned short w = z & 0xFFFF;
  // Get a signed version of the above for the grad function
  short xx = (u >> 1) & 0x7FFF;
  short yy = (v >> 1) & 0x7FFF;
  short zz = (w >> 1) & 0x7FFF;
  unsigned short N = 0x8000L;
  u = EASE16 (u); v = EASE16 (v); w = EASE16 (w);
  // skip the log fade adjustment for the moment, otherwise here we would
  // adjust fade values for u,v,w
  short X1 = LERP (grad16_xyz (P (AA), xx, yy, zz), grad16_xyz (P (BA), xx - N, yy, zz), u);
  short X2 = LERP (grad16_xyz (P (AB), xx, yy-N, zz), grad16_xyz (P (BB), xx - N, yy - N, zz), u);
  short X3 = LERP (grad16_xyz (P (AA+1), xx, yy, zz-N), grad16_xyz (P (BA+1), xx - N, yy, zz-N), u);
  short X4 = LERP (grad16_xyz (P (AB+1), xx, yy-N, zz-N), grad16_xyz (P (BB+1), xx - N, yy - N, zz - N), u);
  short Y1 = LERP (X1, X2, v);
  short Y2 = LERP (X3, X4, v);
  short ans = LERP (Y1, Y2, w);
  return ans;
}

unsigned short inoise16_xyz(unsigned int x, unsigned int y, unsigned int z)
{
  int ans = inoise16_raw_xyz (x, y, z);
  ans = ans + 19052L;
  unsigned int pan = ans;
  // pan = (ans * 220L) >> 7.  That's the same as:
  // pan = (ans * 440L) >> 8.  And this way avoids a 7X four-byte shift-loop on AVR.
  // Identical math, except for the highest bit, which we don't care about anyway,
  // since we're returning the 'middle' 16 out of a 32-bit value anyway.
  pan *= 440L;
  return (pan>>8);
  // // return scale16by8(pan,220)<<1;
  // return ((inoise16_raw_xyz(x,y,z)+19052)*220)>>7;
  // return scale16by8(inoise16_raw_xyz(x,y,z)+19052,220)<<1;
}

short inoise16_raw_xy (unsigned int x, unsigned int y)
{
  // Find the unit cube containing the point
  unsigned char X = x>>16;
  unsigned char Y = y>>16;
  // Hash cube corner coordinates
  unsigned char A = P (X)+Y;
  unsigned char AA = P (A);
  unsigned char AB = P (A+1);
  unsigned char B = P (X+1)+Y;
  unsigned char BA = P (B);
  unsigned char BB = P (B+1);
  // Get the relative position of the point in the cube
  unsigned short u = x & 0xFFFF;
  unsigned short v = y & 0xFFFF;
  // Get a signed version of the above for the grad function
  short xx = (u >> 1) & 0x7FFF;
  short yy = (v >> 1) & 0x7FFF;
  unsigned short N = 0x8000L;
  u = EASE16 (u); v = EASE16 (v);
  short X1 = LERP (grad16_xy (P (AA), xx, yy), grad16_xy (P (BA), xx - N, yy), u);
  short X2 = LERP (grad16_xy (P (AB), xx, yy-N), grad16_xy (P (BB), xx - N, yy - N), u);
  short ans = LERP (X1, X2, v);
  return ans;
}

unsigned short inoise16_xy(unsigned int x, unsigned int y)
{
  int ans = inoise16_raw_xy (x, y);
  ans = ans + 17308L;
  unsigned int pan = ans;
  // pan = (ans * 242L) >> 7.  That's the same as:
  // pan = (ans * 484L) >> 8.  And this way avoids a 7X four-byte shift-loop on AVR.
  // Identical math, except for the highest bit, which we don't care about anyway,
  // since we're returning the 'middle' 16 out of a 32-bit value anyway.
  pan *= 484L;
  return (pan>>8);
  // return (unsigned int)(((int)inoise16_raw_xyz(x,y)+(unsigned int)17308)*242)>>7;
  // return scale16by8(inoise16_raw_xyz(x,y)+17308,242)<<1;
}

short inoise16_raw_x (unsigned int x)
{
  // Find the unit cube containing the point
  unsigned char X = x>>16;
  // Hash cube corner coordinates
  unsigned char A = P (X);
  unsigned char AA = P (A);
  unsigned char B = P (X+1);
  unsigned char BA = P (B);
  // Get the relative position of the point in the cube
  unsigned short u = x & 0xFFFF;
  // Get a signed version of the above for the grad function
  short xx = (u >> 1) & 0x7FFF;
  unsigned short N = 0x8000L;
  u = EASE16 (u);
  short ans = LERP (grad16_x (P (AA), xx), grad16_x (P (BA), xx - N), u);
  return ans;
}

unsigned short inoise16_x (unsigned int x)
{
  return ( (unsigned int) ( (int) inoise16_raw_x (x) + 17308L) ) << 1;
}

char inoise8_raw_xyz (unsigned short x, unsigned short y, unsigned short z)
{
  // Find the unit cube containing the point
  unsigned char X = x>>8;
  unsigned char Y = y>>8;
  unsigned char Z = z>>8;
  // Hash cube corner coordinates
  unsigned char A = P (X)+Y;
  unsigned char AA = P (A)+Z;
  unsigned char AB = P (A+1)+Z;
  unsigned char B = P (X+1)+Y;
  unsigned char BA = P (B) + Z;
  unsigned char BB = P (B+1)+Z;
  // Get the relative position of the point in the cube
  unsigned char u = (unsigned char)x;
  unsigned char v = (unsigned char)y;
  unsigned char w = (unsigned char)z;
  // Get a signed version of the above for the grad function
  char xx = ( (unsigned char) (x) >>1) & 0x7F;
  char yy = ( (unsigned char) (y) >>1) & 0x7F;
  char zz = ( (unsigned char) (z) >>1) & 0x7F;
  unsigned char N = 0x80;
  u = (unsigned char)(EASE8 (u)); 
  v = (unsigned char)(EASE8 (v)); 
  w = (unsigned char)(EASE8 (w));
  char X1 = lerp7by8 (grad8_xyz (P (AA), xx, yy, zz), grad8_xyz (P (BA), xx - N, yy, zz), u);
  char X2 = lerp7by8 (grad8_xyz (P (AB), xx, yy-N, zz), grad8_xyz (P (BB), xx - N, yy - N, zz), u);
  char X3 = lerp7by8 (grad8_xyz (P (AA+1), xx, yy, zz-N), grad8_xyz (P (BA+1), xx - N, yy, zz-N), u);
  char X4 = lerp7by8 (grad8_xyz (P (AB+1), xx, yy-N, zz-N), grad8_xyz (P (BB+1), xx - N, yy - N, zz - N), u);
  char Y1 = lerp7by8 (X1, X2, v);
  char Y2 = lerp7by8 (X3, X4, v);
  char ans = lerp7by8 (Y1, Y2, w);
  return ans;
}

unsigned char inoise8_xyz (unsigned short x, unsigned short y, unsigned short z)
{
  //  return scale8(76+(inoise8_raw_xyz(x,y,z)),215)<<1;
  char n = inoise8_raw_xyz ( x, y, z); // -64..+64
  n+= 64;                            //   0..128
  unsigned char ans = qadd8 ( n, n);       //   0..255
  return ans;
}

char inoise8_raw_xy (unsigned short x, unsigned short y)
{
  // Find the unit cube containing the point
  unsigned char X = x>>8;
  unsigned char Y = y>>8;
  // Hash cube corner coordinates
  unsigned char A = P (X)+Y;
  unsigned char AA = P (A);
  unsigned char AB = P (A+1);
  unsigned char B = P (X+1)+Y;
  unsigned char BA = P (B);
  unsigned char BB = P (B+1);
  // Get the relative position of the point in the cube
  unsigned char u = (unsigned char)x;
  unsigned char v = (unsigned char)y;
  // Get a signed version of the above for the grad function
  char xx = ( (unsigned char) (x) >>1) & 0x7F;
  char yy = ( (unsigned char) (y) >>1) & 0x7F;
  unsigned char N = 0x80;
  u = (unsigned char)(EASE8 (u)); 
  v = (unsigned char)(EASE8 (v));
  char X1 = lerp7by8 (grad8_xy (P (AA), xx, yy), grad8_xy (P (BA), xx - N, yy), u);
  char X2 = lerp7by8 (grad8_xy (P (AB), xx, yy-N), grad8_xy (P (BB), xx - N, yy - N), u);
  char ans = lerp7by8 (X1, X2, v);
  return ans;
  // return scale8((70+(ans)),234)<<1;
}



unsigned char inoise8_xy (unsigned short x, unsigned short y)
{
  //return scale8(69+inoise8_raw_xyz(x,y),237)<<1;
  char n = inoise8_raw_xy ( x, y); // -64..+64
  n+= 64;                         //   0..128
  unsigned char ans = qadd8 ( n, n);    //   0..255
  return ans;
}

// output range = -64 .. +64
char inoise8_raw_x (unsigned short x)
{
  // Find the unit cube containing the point
  unsigned char X = x>>8;
  // Hash cube corner coordinates
  unsigned char A = P (X);
  unsigned char AA = P (A);
  unsigned char B = P (X+1);
  unsigned char BA = P (B);
  // Get the relative position of the point in the cube
  unsigned char u = (unsigned char)x;
  // Get a signed version of the above for the grad function
  char xx = ( (unsigned char) (x) >>1) & 0x7F;
  unsigned char N = 0x80;
  u = (unsigned char)(EASE8 ( u));
  char ans = lerp7by8 (grad8_x (P (AA), xx), grad8_x (P (BA), xx - N), u);
  return ans;
}

unsigned char inoise8_x (unsigned short x)
{
  char n = inoise8_raw_x (x);   //-64..+64
  n += 64;                      // 0..128
  unsigned char ans = qadd8 (n, n);   // 0..255
  return ans;
}

// struct q44 {
//   unsigned char i:4;
//   unsigned char f:4;
//   q44(unsigned char _i, unsigned char _f) {i=_i; f=_f; }
// };

// unsigned int mul44(unsigned int v, q44 mulby44) {
//     return (v *mulby44.i)  + ((v * mulby44.f) >> 4);
// }
//
// unsigned short mul44_16(unsigned short v, q44 mulby44) {
//     return (v *mulby44.i)  + ((v * mulby44.f) >> 4);
// }

void fill_raw_noise8 (unsigned char* pData, unsigned char num_points, unsigned char octaves, unsigned short x,
                      int scale, unsigned short time)
{
  unsigned int _xx = x;
  unsigned int scx = scale;

  for (int o = 0; o < octaves; o++)
  {
    for (int i = 0, xx=_xx; i < num_points; i++, xx+=scx)
    {
      pData[i] = qadd8 (pData[i], inoise8_xy (xx, time) >>o);
    }

    _xx <<= 1;
    scx <<= 1;
  }
}

void fill_raw_noise16into8 (unsigned char* pData, unsigned char num_points, unsigned char octaves, unsigned int x,
                            int scale, unsigned int time)
{
  unsigned int _xx = x;
  unsigned int scx = scale;
  int o = 0;
  int i = 0;
  int xx=_xx;

  for (o = 0; o < octaves; o++)
  {
    for (i = 0, xx=_xx; i < num_points; i++, xx+=scx)
    {
      unsigned int accum = (inoise16_xy (xx, time) ) >>o;
      accum += (pData[i]<<8);

      if (accum > 65535)
      {
        accum = 65535;
      }

      pData[i] = accum>>8;
    }

    _xx <<= 1;
    scx <<= 1;
  }
}

void fill_raw_2dnoise8_q44(unsigned char* pData, int width, int height, unsigned char octaves, q44 freq44,
                        fract8 amplitude, int skip, unsigned short x, int scalex, unsigned short y, int scaley, unsigned short time)
{
  if (octaves > 1)
  {
    fill_raw_2dnoise8_q44(pData, width, height, octaves-1, freq44, amplitude, skip+1, Q44_MUL_V(freq44, x), Q44_MUL_V(freq44, scalex), Q44_MUL_V(freq44, y),
                       Q44_MUL_V(freq44, scaley), time);
  }
  else
  {
    // amplitude is always 255 on the lowest level
    amplitude=255;
  }

  scalex *= skip;
  scaley *= skip;
  fract8 invamp = 255-amplitude;
  unsigned short xx = x;

  for (int i = 0; i < height; i++, y+=scaley)
  {
    unsigned char* pRow = pData + (i*width);
    xx = x;

    for (int j = 0; j < width; j++, xx+=scalex)
    {
      unsigned char noise_base = inoise8_xyz (xx, y, time);
      noise_base = (0x80 & noise_base) ? (noise_base - 127) : (127 - noise_base);
      noise_base = scale8 (noise_base<<1, amplitude);

      if (skip == 1)
      {
        pRow[j] = scale8 (pRow[j], invamp) + noise_base;
      }
      else
      {
        for (int ii = i; ii< (i+skip) && ii<height; ii++)
        {
          unsigned char* pRow = pData + (ii*width);

          for (int jj=j; jj< (j+skip) && jj<width; jj++)
          {
            pRow[jj] = scale8 (pRow[jj], invamp) + noise_base;
          }
        }
      }
    }
  }
}

void fill_raw_2dnoise8 (unsigned char* pData, int width, int height, unsigned char octaves, unsigned short x,
                        int scalex, unsigned short y, int scaley, unsigned short time)
{
  q44 freq44;
  q44_init_2(&freq44, 2, 0);
  fill_raw_2dnoise8_q44(pData, width, height, octaves, freq44, 128, 1, x, scalex, y, scaley, time);
}

void fill_raw_2dnoise16 (unsigned short* pData, int width, int height, unsigned char octaves, q88 freq88,
                         fract16 amplitude, int skip, unsigned int x, int scalex, unsigned int y, int scaley, unsigned int time)
{
  if (octaves > 1)
  {
    fill_raw_2dnoise16 (pData, width, height, octaves-1, freq88, amplitude, skip, Q88_MUL_V(freq88,x), Q88_MUL_V(freq88,scalex), Q88_MUL_V(freq88, y),
                        Q88_MUL_V(freq88, scaley), time);
  }
  else
  {
    // amplitude is always 255 on the lowest level
    amplitude=65535;
  }

  scalex *= skip;
  scaley *= skip;
  fract16 invamp = 65535-amplitude;

  for (int i = 0; i < height; i+=skip, y+=scaley)
  {
    unsigned short* pRow = pData + (i*width);

    for (int j = 0, xx=x; j < width; j+=skip, xx+=scalex)
    {
      unsigned short noise_base = inoise16_xyz (xx, y, time);
      noise_base = (0x8000 & noise_base) ? noise_base - (32767) : 32767 - noise_base;
      noise_base = scale16 (noise_base<<1, amplitude);

      if (skip==1)
      {
        pRow[j] = scale16 (pRow[j], invamp) + noise_base;
      }
      else
      {
        for (int ii = i; ii< (i+skip) && ii<height; ii++)
        {
          unsigned short* pRow = pData + (ii*width);

          for (int jj=j; jj< (j+skip) && jj<width; jj++)
          {
            pRow[jj] = scale16 (pRow[jj], invamp) + noise_base;
          }
        }
      }
    }
  }
}

int nmin=11111110;
int nmax=0;

void fill_raw_2dnoise16into8_q44(unsigned char* pData, int width, int height, unsigned char octaves, q44 freq44,
                              fract8 amplitude, int skip, unsigned int x, int scalex, unsigned int y, int scaley, unsigned int time)
{
  if (octaves > 1)
  {
    fill_raw_2dnoise16into8_q44(pData, width, height, octaves-1, freq44, amplitude, skip+1, Q44_MUL_V(freq44, x), Q44_MUL_V(freq44, scalex), Q44_MUL_V(freq44, y),
                             Q44_MUL_V(freq44, scaley), time);
  }
  else
  {
    // amplitude is always 255 on the lowest level
    amplitude=255;
  }

  scalex *= skip;
  scaley *= skip;
  unsigned int xx;
  fract8 invamp = 255-amplitude;

  for (int i = 0; i < height; i+=skip, y+=scaley)
  {
    unsigned char* pRow = pData + (i*width);
    xx = x;

    for (int j = 0; j < width; j+=skip, xx+=scalex)
    {
      unsigned short noise_base = inoise16_xyz (xx, y, time);
      noise_base = (0x8000 & noise_base) ? noise_base - (32767) : 32767 - noise_base;
      noise_base = scale8 (noise_base>>7, amplitude);

      if (skip==1)
      {
        pRow[j] = qadd8 (scale8 (pRow[j], invamp), (unsigned char)noise_base);
      }
      else
      {
        for (int ii = i; ii< (i+skip) && ii<height; ii++)
        {
          unsigned char* pRow = pData + (ii*width);

          for (int jj=j; jj< (j+skip) && jj<width; jj++)
          {
            pRow[jj] = scale8 (pRow[jj], invamp) + noise_base;
          }
        }
      }
    }
  }
}

void fill_raw_2dnoise16into8 (unsigned char* pData, int width, int height, unsigned char octaves, unsigned int x,
                              int scalex, unsigned int y, int scaley, unsigned int time)
{
  q44 freq44;
  q44_init_2(&freq44, 2, 0);
  fill_raw_2dnoise16into8_q44(pData, width, height, octaves, freq44, 171, 1, x, scalex, y, scaley, time);
}

#ifndef NULL
#define NULL (void*)(0)
#endif

void fill_noise8 (CRGB* leds, int num_leds,
                  unsigned char octaves, unsigned short x, int scale,
                  unsigned char hue_octaves, unsigned short hue_x, int hue_scale,
                  unsigned short time)
{
  unsigned char* V = malloc(num_leds);
  if(V == NULL)
  {
    return;
  }
  unsigned char* H = malloc(num_leds);
  if(H == NULL)
  {
    return;
  }   
  
  memset (V, 0, num_leds);
  memset (H, 0, num_leds);
  fill_raw_noise8 (V, num_leds, octaves, x, scale, time);
  fill_raw_noise8 (H, num_leds, hue_octaves, hue_x, hue_scale, time);

  for (int i = 0; i < num_leds; i++)
  {
    RGB_initBy_H_S_V(leds + i, H[i], 255, V[i]);
  }
  free(V);
  free(H);
}

void fill_noise16 (CRGB* leds, int num_leds,
                   unsigned char octaves, unsigned short x, int scale,
                   unsigned char hue_octaves, unsigned short hue_x, int hue_scale,
                   unsigned short time, unsigned char hue_shift)
{
  unsigned char* V = malloc(num_leds);
  if(V == NULL)
  {
    return;
  }
  unsigned char* H = malloc(num_leds);
  if(H == NULL)
  {
    return;
  }   
  memset (V, 0, num_leds);
  memset (H, 0, num_leds);
  fill_raw_noise16into8 (V, num_leds, octaves, x, scale, time);
  fill_raw_noise8 (H, num_leds, hue_octaves, hue_x, hue_scale, time);

  for (int i = 0; i < num_leds; i++)
  {
    RGB_initBy_H_S_V(leds + i, H[i] + hue_shift, 255, V[i]);
  }
  free(V);
  free(H);
}

void fill_2dnoise8 (CRGB* leds, int width, int height, int serpentine,
                    unsigned char octaves, unsigned short x, int xscale, unsigned short y, int yscale, unsigned short time,
                    unsigned char hue_octaves, unsigned short hue_x, int hue_xscale, unsigned short hue_y, unsigned short hue_yscale,
                    unsigned short hue_time, int blend)
{
  unsigned char* V = malloc(height*width);
  if(V == NULL)
  {
    return;
  }
  unsigned char* H = malloc(height*width);
  if(H == NULL)
  {
    return;
  }   
  memset (V, 0, height*width);
  memset (H, 0, height*width);
  fill_raw_2dnoise8 ( (unsigned char*) V, width, height, octaves, x, xscale, y, yscale, time);
  fill_raw_2dnoise8 ( (unsigned char*) H, width, height, hue_octaves, hue_x, hue_xscale, hue_y, hue_yscale, hue_time);
  int w1 = width-1;
  int h1 = height-1;

  for (int i = 0; i < height; i++)
  {
    int wb = i*width;

    for (int j = 0; j < width; j++)
    {
      CRGB led;
      RGB_initBy_H_S_V(&led, H[(h1 - i)*width+w1 - j], 255, V[i*width+j]);

      int pos = j;

      if (serpentine && (i & 0x1) )
      {
        pos = w1-j;
      }

      if (blend)
      {
        RGB_shiftRight(leds + wb + pos, 1);
        RGB_shiftRight(&led, 1);
        RGB_addRGB(leds + wb + pos, led);
      }
      else
      {
        RGB_initByRGB(leds + wb + pos, led);
      }
    }
  }
  free(V);
  free(H);
}

void fill_2dnoise16 (CRGB* leds, int width, int height, int serpentine,
                     unsigned char octaves, unsigned int x, int xscale, unsigned int y, int yscale, unsigned int time,
                     unsigned char hue_octaves, unsigned short hue_x, int hue_xscale, unsigned short hue_y, unsigned short hue_yscale,
                     unsigned short hue_time, int blend, unsigned short hue_shift)
{
  unsigned char* V = malloc(height*width);
  if(V == NULL)
  {
    return;
  }
  unsigned char* H = malloc(height*width);
  if(H == NULL)
  {
    return;
  }   
  q44 freq44;
  memset (V, 0, height*width);
  memset (H, 0, height*width);
  q44_init_2(&freq44, 2, 0);
  fill_raw_2dnoise16into8_q44( (unsigned char*) V, width, height, octaves, freq44, 171, 1, x, xscale, y, yscale, time);
  // fill_raw_2dnoise16into8((unsigned char*)V,width,height,octaves,x,xscale,y,yscale,time);
  // fill_raw_2dnoise8((unsigned char*)V,width,height,hue_octaves,x,xscale,y,yscale,time);
  fill_raw_2dnoise8 ( (unsigned char*) H, width, height, hue_octaves, hue_x, hue_xscale, hue_y, hue_yscale, hue_time);
  int w1 = width-1;
  int h1 = height-1;
  hue_shift >>= 8;

  for (int i = 0; i < height; i++)
  {
    int wb = i*width;

    for (int j = 0; j < width; j++)
    {
      CRGB led;
      RGB_initBy_H_S_V(&led, hue_shift + (H[(h1 - i)*width + w1 - j]), 196, V[i*width + j]);
      int pos = j;

      if (serpentine && (i & 0x1) )
      {
        pos = w1-j;
      }

      if (blend)
      {
        RGB_shiftRight(leds + wb + pos, 1);
        RGB_shiftRight(&led, 1);
        RGB_addRGB(leds + wb + pos, led);
      }
      else
      {
        RGB_initByRGB(leds + wb + pos, led);
      }
    }
  }
  free(V);
  free(H);
}

