#ifndef __INC_NOISE_H
#define __INC_NOISE_H
#include "lib8tion.h"
#include "pixeltypes.h"
///@file noise.h
/// Noise functions provided by the library.

///@defgroup Noise Noise functions
///Simplex noise function definitions
///@{
/// @name scaled 16 bit noise functions
///@{
/// 16 bit, fixed point implementation of perlin's Simplex Noise.  Coordinates are
/// 16.16 fixed point values, 32 bit integers with integral coordinates in the high 16
/// bits and fractional in the low 16 bits, and the function takes 1d, 2d, and 3d coordinate
/// values.  These functions are scaled to return 0-65535

unsigned short inoise16_xyz(unsigned int x, unsigned int y, unsigned int z);
unsigned short inoise16_xy(unsigned int x, unsigned int y);
unsigned short inoise16_x(unsigned int x);
///@}

/// @name raw 16 bit noise functions
//@{
/// 16 bit raw versions of the noise functions.  These values are not scaled/altered and have
/// output values roughly in the range (-18k,18k)
short inoise16_raw_xyz(unsigned int x, unsigned int y, unsigned int z);
short inoise16_raw_xy(unsigned int x, unsigned int y);
short inoise16_raw_x(unsigned int x);
///@}

/// @name 8 bit scaled noise functions
///@{
/// 8 bit, fixed point implementation of perlin's Simplex Noise.  Coordinates are
/// 8.8 fixed point values, 16 bit integers with integral coordinates in the high 8
/// bits and fractional in the low 8 bits, and the function takes 1d, 2d, and 3d coordinate
/// values.  These functions are scaled to return 0-255
unsigned char inoise8_xyz(unsigned short x, unsigned short y, unsigned short z);
unsigned char inoise8_xy(unsigned short x, unsigned short y);
unsigned char inoise8_x(unsigned short x);
///@}

/// @name 8 bit raw noise functions
///@{
/// 8 bit raw versions of the noise functions.  These values are not scaled/altered and have
/// output values roughly in the range (-70,70)
char inoise8_raw_xyz(unsigned short x, unsigned short y, unsigned short z);
char inoise8_raw_xy(unsigned short x, unsigned short y);
char inoise8_raw_x(unsigned short x);
///@}

///@name raw fill functions
///@{
/// Raw noise fill functions - fill into a 1d or 2d array of 8-bit values using either 8-bit noise or 16-bit noise
/// functions.
///@param pData the array of data to write into
///@param num_points the number of points of noise to compute
///@param octaves the number of octaves to use for noise
///@param x the x position in the noise field
///@param y the y position in the noise field for 2d functions
///@param scalex the scale (distance) between x points when filling in noise
///@param scaley the scale (distance) between y points when filling in noise
///@param time the time position for the noise field
void fill_raw_noise8(unsigned char *pData, unsigned char num_points, unsigned char octaves, unsigned short x, int scalex, unsigned short time);
void fill_raw_noise16into8(unsigned char *pData, unsigned char num_points, unsigned char octaves, unsigned int x, int scalex, unsigned int time);
void fill_raw_2dnoise8(unsigned char *pData, int width, int height, unsigned char octaves, unsigned short x, int scalex, unsigned short y, int scaley, unsigned short time);
void fill_raw_2dnoise16into8(unsigned char *pData, int width, int height, unsigned char octaves, unsigned int x, int scalex, unsigned int y, int scaley, unsigned int time);

void fill_raw_2dnoise16(unsigned short *pData, int width, int height, unsigned char octaves, q88 freq88, fract16 amplitude, int skip, unsigned int x, int scalex, unsigned int y, int scaley, unsigned int time);
void fill_raw_2dnoise16into8_q44(unsigned char *pData, int width, int height, unsigned char octaves, q44 freq44, fract8 amplitude, int skip, unsigned int x, int scalex, unsigned int y, int scaley, unsigned int time);
///@}

///@name fill functions
///@{
/// fill functions to fill leds with values based on noise functions.  These functions use the fill_raw_* functions as appropriate.
void fill_noise8(CRGB *leds, int num_leds,
            unsigned char octaves, unsigned short x, int scale,
            unsigned char hue_octaves, unsigned short hue_x, int hue_scale,
            unsigned short time);
void fill_noise16(CRGB *leds, int num_leds,
            unsigned char octaves, unsigned short x, int scale,
            unsigned char hue_octaves, unsigned short hue_x, int hue_scale,
            unsigned short time, unsigned char hue_shift=0);
void fill_2dnoise8(CRGB *leds, int width, int height, int serpentine,
            unsigned char octaves, unsigned short x, int xscale, unsigned short y, int yscale, unsigned short time,
            unsigned char hue_octaves, unsigned short hue_x, int hue_xscale, unsigned short hue_y, unsigned short hue_yscale,unsigned short hue_time, int blend);
void fill_2dnoise16(CRGB *leds, int width, int height, int serpentine,
            unsigned char octaves, unsigned int x, int xscale, unsigned int y, int yscale, unsigned int time,
            unsigned char hue_octaves, unsigned short hue_x, int hue_xscale, unsigned short hue_y, unsigned short hue_yscale,unsigned short hue_time, int blend, unsigned short hue_shift=0);

///@}

#endif
