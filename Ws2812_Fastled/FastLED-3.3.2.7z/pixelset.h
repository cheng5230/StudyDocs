#ifndef __INC_PIXELSET_H
#define __INC_PIXELSET_H
#include "pixeltypes.h"
#include "colorutils.h"

/// Represents a set of CRGB led objects.  Provides the [] array operator, and works like a normal array in that case.
/// This should be kept in sync with the set of functions provided by CRGB as well as functions in colorutils.  Note
/// that a pixel set is a window into another set of led data, it is not its own set of led data.
typedef struct
{
  char  dir;
  int   len;
  CRGB* leds;
  CRGB* end_pos;
}CPixelView;

#define THIS_FOR_EACH \
  CRGB* pixel = c_this->leds; CRGB* _end = c_this->end_pos; \
  for (; pixel != _end; pixel+=c_this->dir)

#define THIS_RHS_FOR_EACH \
    CRGB* pixel = c_this->leds; CRGB* rhspixel = rhs.leds; CRGB* _end = c_this->end_pos; CRGB* rhs_end = rhs.end_pos; \
    for (; (pixel != _end) &&(rhspixel != rhs_end); pixel+=c_this->dir, rhspixel+=rhs.dir)

/// pixelset constructor for a pixel set starting at the given CRGB* and going for _len leds.  Note that the length
/// can be backwards, creating a PixelSet that walks backwards over the data
/// @param leds point to the raw led data
/// @param len how many leds in this set
inline void CPixelView_init_by_len(CPixelView* c_this, CRGB* leds, int len)
{
  c_this->dir = (len < 0 ? -1 : 1);
  c_this->len = len;
  c_this->leds = leds;
  c_this->end_pos = leds + len;
}

/// PixelSet constructor for the given set of leds, with start and end boundaries.  Note that start can be after
/// end, resulting in a set that will iterate backwards
/// @param leds point to the raw led data
/// @param start the start index of the leds for this array
/// @param end the end index of the leds for this array
inline void CPixelView_init_by_sets (CPixelView* c_this, CRGB* leds, int start, int end)
{
  c_this->dir = ( ( (end - start) <0) ? -1 : 1);
  c_this->len = ( (end - start) + c_this->dir);
  c_this->leds = (leds + start);
  c_this->end_pos = (leds + start + c_this->len);
}

/// Get the size of this set
/// @return the size of the set
inline int CPixelView_size(CPixelView* pixelView)
{
  //return abs (pixelView->len);
  if (pixelView->len >= 0)
  {
    return pixelView->len;
  }
  return (0 - pixelView->len);
}

/// Whether or not this set goes backwards
/// @return whether or not the set is backwards
inline int CPixelView_reversed(CPixelView* c_this)
{
  return c_this->len < 0;
}

/// do these sets point to the same thing (note, this is different from the contents of the set being the same)
inline int CPixelView_isEqual(CPixelView* c_this, CPixelView* rhs)
{
  return c_this->leds == rhs->leds && c_this->len == rhs->len && c_this->dir == rhs->dir;
}

/// do these sets point to the different things (note, this is different from the contents of the set being the same)
inline int CPixelView_isNotEqual(CPixelView* c_this, CPixelView* rhs)
{
  return c_this->leds != rhs->leds && c_this->len != rhs->len && c_this->dir != rhs->dir;
}

/// access a single element in this set, just like an array operator
inline CRGB CPixelView_getPixel(CPixelView* c_this, int x)
{
  if (c_this->dir & 0x80)
  {
    return c_this->leds[-x];
  }
  else
  {
    return c_this->leds[x];
  }
}

/// Access an inclusive subset of the leds in this set.  Note that start can be greater than end, which will
/// result in a reverse ordering for many functions (useful for mirroring)
/// @param start the first element from this set for the new subset
/// @param end the last element for the new subset
inline CPixelView CPixelView_getSubset(CPixelView* c_this, int start, int end)
{
  CPixelView subset;
  CPixelView_init_by_sets(&subset, c_this->leds, start, end);
  return subset;
}

/// Access an inclusive subset of the leds in this set, starting from the first.
/// @param end the last element for the new subset
/// Not sure i want this? inline CPixelView operator()(int end) { return CPixelView(leds, 0, end); }

/// Return the reverse ordering of this set
inline CPixelView CPixelView_getReverseSet(CPixelView* c_this)
{
  CPixelView reverseSet;
  CPixelView_init_by_sets(&reverseSet, c_this->leds + c_this->len - c_this->dir, c_this->len - c_this->dir, 0);
  return reverseSet;
}

/// Return a pointer to the first element in this set
inline CRGB* CPixelView_getFirstPiexel(CPixelView* c_this)
{
  return c_this->leds;
}

/// Assign the passed in color to all elements in this set
/// @param color the new color for the elements in the set
inline void CPixelView_memsetRGB(CPixelView* c_this, CRGB color)
{
  THIS_FOR_EACH
  {
    RGB_initByRGB(pixel, color);
  }
}


void CPixelView_dump(CPixelView* c_this);

/// Copy the contents of the passed in set to our set.  Note if one set is smaller than the other, only the
/// smallest number of items will be copied over.
inline void CPixelView_copyRGB(CPixelView* c_this, CPixelView rhs)
{
  THIS_RHS_FOR_EACH
  {   
    RGB_initByRGB(pixel, (*rhspixel));
  }
}

/// @name modification/scaling operators
//@{
/// Add the passed in value to r,g, b for all the pixels in this set
inline void CPixelView_addCons (CPixelView* c_this, unsigned char inc)
{
  THIS_FOR_EACH
  {
    RGB_addCons(pixel, inc);
  }
}
/// Add every pixel in the other set to this set
inline void CPixelView_addRGB (CPixelView* c_this, CPixelView rhs)
{
  THIS_RHS_FOR_EACH
  {
    RGB_addRGB(pixel, (*rhspixel));
  }
}

/// Subtract the passed in value from r,g,b for all pixels in this set
inline void CPixelView_subCons (CPixelView* c_this, unsigned char inc)
{
  THIS_FOR_EACH
  {
    RGB_subCons(pixel, inc);
  }
}
/// Subtract every pixel in the other set from this set
inline void CPixelView_subRGB (CPixelView* c_this, CPixelView rhs)
{
  THIS_RHS_FOR_EACH
  {
    RGB_subRGB(pixel, (*rhspixel));
  }
}

/// Divide every led by the given value
inline void CPixelView_divCons (CPixelView* c_this, unsigned char d)
{
  THIS_FOR_EACH
  {
    RGB_divCons(pixel, d);
  }
}
/// Shift every led in this set right by the given number of bits
inline void CPixelView_shiftRight (CPixelView* c_this, unsigned char d)
{
  THIS_FOR_EACH
  {
    RGB_shiftRight(pixel, d);
  }
}
/// Multiply every led in this set by the given value
inline void CPixelView_mulCons(CPixelView* c_this, unsigned char d)
{
  THIS_FOR_EACH
  {
    RGB_mulCons(pixel, d);
  }
}

/// Scale every led by the given scale
inline void CPixelView_nscale8_video (CPixelView* c_this, unsigned char scaledown)
{
  THIS_FOR_EACH
  {
    RGB_nscale8_video(pixel, scaledown);
  }
}
/// Scale down every led by the given scale
inline void CPixelView_modCons(CPixelView* c_this, unsigned char scaledown)
{
  THIS_FOR_EACH
  {
    RGB_modCons(pixel, scaledown);
  }
}
/// Fade every led down by the given scale
inline void CPixelView_fadeLightBy (CPixelView* c_this, unsigned char fadefactor)
{
  CPixelView_nscale8_video (c_this, 255 - fadefactor);
}

/// Scale every led by the given scale
inline void CPixelView_nscale8 (CPixelView* c_this, unsigned char scaledown)
{
  THIS_FOR_EACH
  {
    RGB_nscale8(pixel, scaledown);
  }
}
/// Scale every led by the given scale
inline void CPixelView_nscale8RGB (CPixelView* c_this, CRGB scaledown)
{
  THIS_FOR_EACH
  {
    RGB_nscale8RGB(pixel, scaledown);
  }
}
/// Scale every led in this set by every led in the other set
inline void CPixelView_nscale8View(CPixelView* c_this, CPixelView rhs)
{
  THIS_RHS_FOR_EACH
  {
    RGB_nscale8RGB(pixel, (*rhspixel));
  }
}

/// Fade every led down by the given scale
inline void CPixelView_fadeToBlackBy(CPixelView* c_this, unsigned char fade)
{
  CPixelView_nscale8 (c_this, 255 - fade);
}

/// Apply the CRGB |= operator to every pixel in this set with the given CRGB value (bringing each channel to the higher of the two values)
inline void CPixelView_orRGB (CPixelView* c_this, CRGB rhs)
{
  THIS_FOR_EACH
  {
    RGB_orRGB(pixel, rhs);
  }
}
/// Apply the CRGB |= operator to every pixel in this set with every pixel in the passed in set
inline void CPixelView_orView(CPixelView* c_this, CPixelView rhs)
{
  THIS_RHS_FOR_EACH
  {
    RGB_orRGB(pixel, (*rhspixel));
  }
}
/// Apply the CRGB |= operator to every pixel in this set
inline void CPixelView_orCons(CPixelView* c_this, unsigned char d)
{
  THIS_FOR_EACH
  {
    RGB_orCons(pixel, d);
  }
}

/// Apply the CRGB &= operator to every pixel in this set with the given CRGB value (bringing each channel down to the lower of the two values)
inline void CPixelView_andRGB(CPixelView* c_this, CRGB rhs)
{
  THIS_FOR_EACH
  {
    RGB_andRGB(pixel, rhs);
  }
}
/// Apply the CRGB &= operator to every pixel in this set with every pixel in the passed in set
inline void CPixelView_andView(CPixelView* c_this, CPixelView rhs)
{
  THIS_RHS_FOR_EACH
  {
    RGB_andRGB(pixel, (*rhspixel));
  }
}
/// APply the CRGB &= operator to every pixel in this set with the passed in value
inline void CPixelView_andCons(CPixelView* c_this, unsigned char d)
{
  THIS_FOR_EACH
  {
    RGB_andCons(pixel, d);
  }
}
//@}

/// Returns whether or not any leds in this set are non-zero
inline int CPixelView_isNotZero(CPixelView* c_this)
{
  THIS_FOR_EACH
  {
    if ( RGB_isNotZero(*pixel) )
    {
      return 1;
    }
  } 
  return 0;
}

// Color util functions
inline void CPixelView_fill_solid (CPixelView* c_this, CRGB color)
{
  CPixelView_memsetRGB(c_this, color);
}
inline void CPixelView_fill_solid_by_dir(CPixelView* c_this, CHSV color)
{
  if (c_this->dir <= 0)
  {
    return;
  }
  CPixelView_memsetRGB(c_this, hsv2rgb_rainbow(color));
}

//default deltahue=5, *************default value**************************
inline void CPixelView_fill_rainbow(CPixelView* c_this, unsigned char initialhue, unsigned char deltahue)
{
  if (c_this->dir >= 0)
  {
    fill_rainbow_rgb (c_this->leds, c_this->len, initialhue, deltahue);
  }
  else
  {
    fill_rainbow_rgb (c_this->leds+c_this->len+1, -c_this->len, initialhue, deltahue);
  }
}
//default directionCode  = SHORTEST_HUES, *************default value**************************
inline void CPixelView_fill_gradient_hsv(CPixelView* c_this, CHSV startcolor, CHSV endcolor, TGradientDirectionCode directionCode)
{
  if (c_this->dir >= 0)
  {
    fill_gradient_rgb_hsv_c1c2(c_this->leds, c_this->len, startcolor, endcolor, directionCode, 1);
  }
  else
  {
    fill_gradient_rgb_hsv_c1c2(c_this->leds + c_this->len + 1, (-c_this->len), endcolor, startcolor, directionCode, 1);
  }
}
//default directionCode  = SHORTEST_HUES, *************default value**************************
inline void CPixelView_fill_gradient_hsv_c1c2c3(CPixelView* c_this, CHSV c1, CHSV c2, CHSV  c3, TGradientDirectionCode directionCode)
{
  if (c_this->dir >= 0)
  {
    fill_gradient_rgb_hsv_c1c2c3(c_this->leds, c_this->len, c1, c2, c3, directionCode, 1);
  }
  else
  {
    fill_gradient_rgb_hsv_c1c2c3(c_this->leds + c_this->len + 1, -c_this->len, c3, c2, c1, directionCode, 1);
  }
}
//default directionCode  = SHORTEST_HUES, *************default value**************************
inline void CPixelView_fill_gradient_hsv_c1c2c3c4(CPixelView* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4, TGradientDirectionCode directionCode)
{
  if (c_this->dir >= 0)
  {
    fill_gradient_rgb_hsv_c1c2c3c4(c_this->leds, c_this->len, c1, c2, c3, c4, directionCode, 1);
  }
  else
  {
    fill_gradient_rgb_hsv_c1c2c3c4(c_this->leds + c_this->len + 1, -c_this->len, c4, c3, c2, c1, directionCode, 1);
  }
}
//default directionCode  = SHORTEST_HUES, *************default value**************************
inline void CPixelView_fill_gradient_RGB(CPixelView* c_this, CRGB startcolor, CRGB endcolor, TGradientDirectionCode directionCode)
{
  if (c_this->dir >= 0)
  {
    fill_gradient_RGB_c1c2(c_this->leds, c_this->len, startcolor, endcolor);
  }
  else
  {
    fill_gradient_RGB_c1c2(c_this->leds + c_this->len + 1, (-c_this->len), endcolor, startcolor);
  }
}

inline void CPixelView_fill_gradient_RGB_c1c2c3(CPixelView* c_this, CRGB c1, CRGB c2, CRGB c3)
{
  if (c_this->dir >= 0)
  {
    fill_gradient_RGB_c1c2c3 (c_this->leds, c_this->len, c1, c2, c3);
  }
  else
  {
    fill_gradient_RGB_c1c2c3 (c_this->leds + c_this->len + 1, -c_this->len, c3, c2, c1);
  }
}

inline void CPixelView_fill_gradient_RGB_c1c2c3c4(CPixelView* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4)
{
  if (c_this->dir >= 0)
  {
    fill_gradient_RGB_c1c2c3c4 (c_this->leds, c_this->len, c1, c2, c3, c4);
  }
  else
  {
    fill_gradient_RGB_c1c2c3c4 (c_this->leds + c_this->len + 1, -c_this->len, c4, c3, c2, c1);
  }
}
  
inline void CPixelView_nblend_rgb(CPixelView* c_this, CRGB overlay, fract8 amountOfOverlay)
{
  THIS_FOR_EACH
  {
    nblend ( (*pixel), overlay, amountOfOverlay);
  }
}

inline void CPixelView_nblend_view(CPixelView* c_this, CPixelView rhs, fract8 amountOfOverlay)
{
  THIS_RHS_FOR_EACH
  {
    nblend ( (*pixel), (*rhspixel), amountOfOverlay);
  }
}

// Note: only bringing in a 1d blur, not sure 2d blur makes sense when looking at sub arrays
inline void CPixelView_blur1d (CPixelView* c_this, fract8 blur_amount)
{
  if (c_this->dir >= 0)
  {
    blur1d (c_this->leds, c_this->len, blur_amount);
  }
  else
  {
    blur1d (c_this->leds + c_this->len + 1, -c_this->len, blur_amount);
  }
}

inline void CPixelView_napplyGamma_video_gamma(CPixelView* c_this, float gamma)
{
  if (c_this->dir >= 0)
  {
    napplyGamma_video_count_gamma (c_this->leds, c_this->len, gamma);
  }
  else
  {
    napplyGamma_video_count_gamma (c_this->leds + c_this->len + 1, -c_this->len, gamma);
  }
}

inline void CPixelView_napplyGamma_video_gammaRGB(CPixelView* c_this, float gammaR, float gammaG, float gammaB)
{
  if (c_this->dir >= 0)
  {
    napplyGamma_video_count_gammaRGB (c_this->leds, c_this->len, gammaR, gammaG, gammaB);
  }
  else
  {
    napplyGamma_video_count_gammaRGB (c_this->leds + c_this->len + 1, -c_this->len, gammaR, gammaG, gammaB);
  }
}

inline CRGB* CPixelView_get_offset_pixels(CPixelView* c_this, int offset)
{
  return c_this->leds + offset;
}

#endif
