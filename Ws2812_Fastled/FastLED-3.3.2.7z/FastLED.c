#include "FastLED.h"
#include "system_porting.h"

void* pSmartMatrix = NULL;

#if 0
static unsigned int lastshow = 0;
#endif

// unsigned int CRGB::Squant = ((unsigned int)((__TIME__[4]-'0') * 28))<<16 | ((__TIME__[6]-'0')*50)<<8 | ((__TIME__[7]-'0')*28);

void CFastLED_init (CFastLED* c_this)
{
  // clear out the array of led controllers
  // m_nControllers = 0;
  c_this->m_Scale = 255;
  c_this->m_nFPS = 0;
}

void CFastLED_addLeds (CFastLED* c_this, CLEDController* pLed,          CRGB* data, int nLedsOrOffset, int nLedsIfOffset)
{
  int nOffset = (nLedsIfOffset > 0) ? nLedsOrOffset : 0;
  int nLeds = (nLedsIfOffset > 0) ? nLedsIfOffset : nLedsOrOffset;
 
  CLEDController_setLeds(pLed, data + nOffset, nLeds);
#if 0  
  FastLED.setMaxRefreshRate (pLed->getMaxRefreshRate(), true);
#endif
}

void CFastLED_setBrightness (CFastLED* c_this, unsigned char scale)
{
  c_this->m_Scale = scale;
}

unsigned char CFastLED_getBrightness(CFastLED* c_this)
{
  return c_this->m_Scale;
}

void CFastLED_show_scale(CFastLED* c_this, unsigned char scale)
{
#if 0
  // guard against showing too rapidly
  while (m_nMinMicros && ( (micros()-lastshow) < m_nMinMicros) );

  lastshow = micros();
#endif

  CLEDController* pCur = CLEDController_get_list_head();

  while (pCur)
  {
    unsigned char d = pCur->m_DitherMode;

    if (c_this->m_nFPS < 100)
    {
      pCur->m_DitherMode = DISABLE_DITHER;
    }

    CLEDController_showLeds(pCur, scale);
    pCur->m_DitherMode = d;
    pCur = pCur->m_pNext;
  }
  //call default frame.
  CFastLED_countFPS(c_this, 25);
}

void CFastLED_show(CFastLED* c_this)
{
  CFastLED_show_scale (c_this, c_this->m_Scale);
}

int CFastLED_count(CFastLED* c_this)
{
  int x = 0;
  CLEDController* pCur = CLEDController_get_list_head();

  while ( pCur)
  {
    x++;
    pCur = pCur->m_pNext;
  }

  return x;
}

CLEDController* CFastLED_getController (CFastLED* c_this, int x)
{
  CLEDController* pCur = CLEDController_get_list_head();

  while (x-- && pCur)
  {
    pCur = pCur->m_pNext;
  }

  if (pCur == NULL)
  {
    pCur = CLEDController_get_list_head();
  }
  return pCur;
}

void CFastLED_showColor_scale(CFastLED* c_this, CRGB color, unsigned char scale)
{
#if 0
  while (m_nMinMicros && ( (micros()-lastshow) < m_nMinMicros) );

  lastshow = micros();
#endif

  CLEDController* pCur = CLEDController_get_list_head();

  while (pCur)
  {
    unsigned char d = pCur->m_DitherMode;

    if (c_this->m_nFPS < 100)
    {
      pCur->m_DitherMode = DISABLE_DITHER;
    }

    CLEDController_showColor(pCur, color, scale);
    pCur->m_DitherMode = d;
    pCur = pCur->m_pNext;
  }
  //call default frame.
  CFastLED_countFPS(c_this, 25);
}

void CFastLED_showColor(CFastLED* c_this, CRGB color)
{
  CFastLED_showColor_scale(c_this, color, c_this->m_Scale);
}

void CFastLED_clear (CFastLED* c_this, int writeData)
{
  if (writeData)
  {
    CRGB rgb;
    rgb.r = 0;
    rgb.g = 0;
    rgb.b = 0;
    CFastLED_showColor_scale(c_this, rgb, 0);
  }

  CFastLED_clearData(c_this);
}

void CFastLED_clearData(CFastLED* c_this)
{
  CLEDController* pCur = CLEDController_get_list_head();

  while (pCur)
  {
    CLEDController_clearLedData(pCur);
    pCur = pCur->m_pNext;
  }
}

void CFastLED_delay (unsigned long ms)
{
  system_sleep_ms(ms);
}

void CFastLED_setTemperature (CFastLED* c_this, CRGB temp)
{
  CLEDController* pCur = CLEDController_get_list_head();

  while (pCur)
  {
    CLEDController_setTemperature_By_CRGB(pCur, temp);
    pCur = pCur->m_pNext;
  }
}

void CFastLED_setCorrection (CFastLED* c_this, CRGB correction)
{
  CLEDController* pCur = CLEDController_get_list_head();

  while (pCur)
  {
    CLEDController_setCorrection_rgb(pCur, correction);
    pCur = pCur->m_pNext;
  }
}

void CFastLED_setDither (CFastLED* c_this, unsigned char ditherMode)
{
  CLEDController* pCur = CLEDController_get_list_head();

  while (pCur)
  {
    pCur->m_DitherMode = ditherMode;
    pCur = pCur->m_pNext;
  }
}

//
// template<int m, int n> void transpose8(unsigned char A[8], unsigned char B[8]) {
//  unsigned int x, y, t;
//
//  // Load the array and pack it into x and y.
//    y = *(unsigned int*)(A);
//  x = *(unsigned int*)(A+4);
//
//  // x = (A[0]<<24)   | (A[m]<<16)   | (A[2*m]<<8) | A[3*m];
//  // y = (A[4*m]<<24) | (A[5*m]<<16) | (A[6*m]<<8) | A[7*m];
//
// // pre-transform x
// t = (x ^ (x >> 7)) & 0x00AA00AA;  x = x ^ t ^ (t << 7);
// t = (x ^ (x >>14)) & 0x0000CCCC;  x = x ^ t ^ (t <<14);
//
// // pre-transform y
// t = (y ^ (y >> 7)) & 0x00AA00AA;  y = y ^ t ^ (t << 7);
// t = (y ^ (y >>14)) & 0x0000CCCC;  y = y ^ t ^ (t <<14);
//
// // final transform
// t = (x & 0xF0F0F0F0) | ((y >> 4) & 0x0F0F0F0F);
// y = ((x << 4) & 0xF0F0F0F0) | (y & 0x0F0F0F0F);
// x = t;
//
//  B[7*n] = y; y >>= 8;
//  B[6*n] = y; y >>= 8;
//  B[5*n] = y; y >>= 8;
//  B[4*n] = y;
//
//   B[3*n] = x; x >>= 8;
//  B[2*n] = x; x >>= 8;
//  B[n] = x; x >>= 8;
//  B[0] = x;
//  // B[0]=x>>24;    B[n]=x>>16;    B[2*n]=x>>8;  B[3*n]=x>>0;
//  // B[4*n]=y>>24;  B[5*n]=y>>16;  B[6*n]=y>>8;  B[7*n]=y>>0;
// }
//
// void transposeLines(Lines & out, Lines & in) {
//  transpose8<1,2>(in.bytes, out.bytes);
//  transpose8<1,2>(in.bytes + 8, out.bytes + 1);
// }

extern int noise_min;
extern int noise_max;
//default: nFrames = 25. ********default value*******
void CFastLED_countFPS (CFastLED* c_this, int nFrames)
{
  static int br = 0;
  static unsigned int lastframe = 0; // millis();

  if (br++ >= nFrames)
  {
    unsigned int now = get_system_millisecond();
    now -= lastframe;
    c_this->m_nFPS = (br * 1000) / now;
    br = 0;
    lastframe = get_system_millisecond();
  }
}

int CFastLED_size(CFastLED* c_this)
{
  CFastLED_getController(c_this, 0);
  return CLEDController_size (CFastLED_getController(c_this, 0));
}

CRGB* CFastLED_leds(CFastLED* c_this)
{
  return CLEDController_leds(CFastLED_getController(c_this, 0));
}

void CFastLED_setMaxRefreshRate(CFastLED* c_this, unsigned short refresh, int constrain)
{
#if 0  
  if (constrain)
  {
    // if we're constraining, the new value of m_nMinMicros _must_ be higher than previously (because we're only
    // allowed to slow things down if constraining)
    if (refresh > 0)
    {
      m_nMinMicros = ( (1000000/refresh) >  m_nMinMicros) ? (1000000/refresh) : m_nMinMicros;
    }
  }
  else if (refresh > 0)
  {
    m_nMinMicros = 1000000 / refresh;
  }
  else
  {
    m_nMinMicros = 0;
  }
#endif  
}


