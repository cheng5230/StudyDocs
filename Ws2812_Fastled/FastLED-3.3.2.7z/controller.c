///@file controller.h
/// base definitions used by led controllers for writing out led data
#include <stddef.h>
#include "fastled_config.h"
#include "color.h"
#include "controller.h"
#include "pixeltypes.h"
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// LED Controller interface definition
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Base definition for an LED controller.  Pretty much the methods that every LED controller object will make available.
/// Note that the showARGB method is not impelemented for all controllers yet.   Note also the methods for eventual checking
/// of background writing of data (I'm looking at you, teensy 3.0 DMA controller!).  If you want to pass LED controllers around
/// to methods, make them references to this type, keeps your code saner.  However, most people won't be seeing/using these objects
/// directly at all

static CLEDController* gs_CLEDController_Head;
static CLEDController* gs_CLEDController_Tail; 
CLEDController* CLEDController_get_list_head()
{
  return gs_CLEDController_Head;
}
CLEDController* CLEDController_get_list_tail()
{
  return gs_CLEDController_Tail;
}

void CLEDController_init(CLEDController* c_this, CLEDCONTROLLER_SHOWCOLOR showColorCallback, CLEDCONTROLLER_SHOW showCallback, int rgb_order)
{
  c_this->m_Data = NULL;
  RGB_initByColor(&c_this->m_ColorCorrection, UncorrectedColor);
  RGB_initByColor(&c_this->m_ColorTemperature, UncorrectedTemperature);
  c_this->m_DitherMode = BINARY_DITHER;
  c_this->m_nLeds = 0;
  c_this->m_pNext = NULL;

  if (gs_CLEDController_Head==NULL)
  {
    gs_CLEDController_Head = c_this;
  }

  if (gs_CLEDController_Tail != NULL)
  {
    gs_CLEDController_Tail->m_pNext = c_this;
  }

  gs_CLEDController_Tail = c_this;
  c_this->showColorCallback = showColorCallback;
  c_this->showCallback = showCallback;
  c_this->rgb_order = rgb_order;  
}


//public:
/// create an led controller object, add it to the chain of controllers

///clear out/zero out the given number of leds.
void CLEDController_clearLeds (CLEDController* c_this, int nLeds)
{
  CRGB data;
  RGB_initByColor(&data, Black);
  CRGB scale;
  RGB_initByColor(&scale, Black);
  c_this->showColorCallback(c_this, data, nLeds, scale);
}

/// show function w/integer brightness, will scale for color correction and temperature
void CLEDController_show (CLEDController* c_this, CRGB* data, int nLeds, unsigned char brightness)
{
  c_this->showCallback(c_this, data, nLeds, CLEDController_getAdjustment (c_this, brightness) );
}

/// show function w/integer brightness, will scale for color correction and temperature
void CLEDController_showColor_nled (CLEDController* c_this, CRGB data, int nLeds, unsigned char brightness)
{
  c_this->showColorCallback(c_this, data, nLeds, CLEDController_getAdjustment (c_this, brightness) );
}

/// show function using the "attached to this controller" led data
// default: brightness=255  *************default value****************
void CLEDController_showLeds (CLEDController* c_this, unsigned char brightness)
{
  c_this->showCallback(c_this, c_this->m_Data, c_this->m_nLeds, CLEDController_getAdjustment (c_this, brightness) );
}

/// show the given color on the led strip
void CLEDController_showColor (CLEDController* c_this, CRGB data, unsigned char brightness)
{
  c_this->showColorCallback(c_this, data, c_this->m_nLeds, CLEDController_getAdjustment (c_this, brightness) );
}

/// set the default array of leds to be used by this controller
void CLEDController_setLeds (CLEDController* c_this, CRGB* data, int nLeds)
{
  c_this->m_Data = data;
  c_this->m_nLeds = nLeds;
}

/// zero out the led data managed by this controller
void CLEDController_clearLedData (CLEDController* c_this)
{
  if (c_this->m_Data)
  {
    memset8 ( (void*) c_this->m_Data, 0, sizeof (CRGB) * c_this->m_nLeds);
  }
}

/// How many leds does this controller manage?
int CLEDController_size (CLEDController* c_this)
{
  return c_this->m_nLeds;
}

/// Pointer to the CRGB array for this controller
CRGB* CLEDController_leds(CLEDController* c_this)
{
  return c_this->m_Data;
}

/// Reference to the n'th item in the controller
CRGB CLEDController_get_rgb (CLEDController* c_this, int x)
{
  return c_this->m_Data[x];
}

/// get the dithering option currently set for this controller
unsigned char CLEDController_getDither (CLEDController* c_this)
{
  return c_this->m_DitherMode;
}

/// the the color corrction to use for this controller, expressed as an rgb object
void CLEDController_setCorrection_rgb(CLEDController* c_this, CRGB correction)
{
  c_this->m_ColorCorrection = correction;
}
/// set the color correction to use for this controller
void CLEDController_setCorrection_color(CLEDController* c_this, LEDColorCorrection correction)
{
  RGB_initByColor(&(c_this->m_ColorCorrection), correction);
}
/// get the correction value used by this controller
CRGB CLEDController_getCorrection (CLEDController* c_this)
{
  return c_this->m_ColorCorrection;
}

/// set the color temperature, aka white point, for this controller
void CLEDController_setTemperature_By_CRGB (CLEDController* c_this, CRGB temperature)
{
  c_this->m_ColorTemperature = temperature;
}
/// set the color temperature, aka white point, for this controller
void CLEDController_setTemperature_value (CLEDController* c_this, ColorTemperature temperature)
{
  RGB_initByColor (& (c_this->m_ColorTemperature), temperature);
}
/// get the color temperature, aka whipe point, for this controller
CRGB CLEDController_getTemperature_value (CLEDController* c_this)
{
  return c_this->m_ColorTemperature;
}

/// Get the combined brightness/color adjustment for this controller
CRGB CLEDController_getAdjustment (CLEDController* c_this, unsigned char scale)
{
  return CLEDController_computeAdjustment (scale, c_this->m_ColorCorrection, c_this->m_ColorTemperature);
}

CRGB CLEDController_computeAdjustment (unsigned char scale, CRGB colorCorrection, CRGB colorTemperature)
{
#if defined(NO_CORRECTION) && (NO_CORRECTION==1)
  return CRGB (scale, scale, scale);
#else
  CRGB adj;
  adj.r = 0;
  adj.g = 0;
  adj.b = 0;

  if (scale > 0)
  {
    for (unsigned char i = 0; i < 3; i++)
    {
      unsigned char cc = colorCorrection.raw[i];
      unsigned char ct = colorTemperature.raw[i];

      if (cc > 0 && ct > 0)
      {
        unsigned int work = ( ( (unsigned int) cc)+1) * ( ( (unsigned int) ct)+1) * scale;
        work /= 0x10000L;
        adj.raw[i] = work & 0xFF;
      }
    }
  }

  return adj;
#endif
}
unsigned short CLEDController_getMaxRefreshRate()
{
  return 0;
}


//end


// Pixel controller class.  This is the class that we use to centralize pixel access in a block of data, including
// support for things like RGB reordering, scaling, dithering, skipping (for ARGB data), and eventually, we will
// centralize 8/12/16 conversions here as well.
void PixelController_init_by_self_type (PixelController* c_this, PixelController other)
{
  c_this->d[0] = other.d[0];
  c_this->d[1] = other.d[1];
  c_this->d[2] = other.d[2];
  c_this->e[0] = other.e[0];
  c_this->e[1] = other.e[1];
  c_this->e[2] = other.e[2];
  c_this->mData = other.mData;
  c_this->mScale = other.mScale;
  c_this->mAdvance = other.mAdvance;
  c_this->mLenRemaining = c_this->mLen = other.mLen;
  c_this->rgb_order[0] = other.rgb_order[0];
  c_this->rgb_order[1] = other.rgb_order[1];
  c_this->rgb_order[2] = other.rgb_order[2];

  for (int i = 0; i < PIXEL_CONTROLLER_LANES; i++)
  {
    c_this->mOffsets[i] = other.mOffsets[i];
  }
}

void PixelController_initOffsets (PixelController* c_this, int len)
{
  int nOffset = 0;

  for (int i = 0; i < PIXEL_CONTROLLER_LANES; i++)
  {
    c_this->mOffsets[i] = nOffset;

    if ( (1<<i) & PIXEL_CONTROLLER_MASK)
    {
      nOffset += (len * c_this->mAdvance);
    }
  }
}

//default: dither = BINARY_DITHER *************default value****************
//default: advance = 1  *************default value****************
//default: skip = 0  *************default value****************
void PixelController_init_by_value (PixelController* c_this, unsigned char* d, int len, CRGB s,
                                                           EDitherMode dither, int advance, unsigned char skip, unsigned char rgb_order)
{
  c_this->mData = d;
  c_this->mLen = len;
  c_this->mLenRemaining = len;
  c_this->mScale = s;
  PixelController_enable_dithering (c_this, dither);
  c_this->mData += skip;
  c_this->mAdvance = (advance) ? 3+skip : 0;

  c_this->rgb_order[0] = RGB_BYTE(rgb_order,0);
  c_this->rgb_order[1] = RGB_BYTE(rgb_order,1);
  c_this->rgb_order[2] = RGB_BYTE(rgb_order,2);

  PixelController_initOffsets (c_this, len);
}

//default: dither = BINARY_DITHER *************default value****************
void PixelController_init_by_rgb (PixelController* c_this, CRGB* d, int len, CRGB s, EDitherMode dither, unsigned char rgb_order)
{
  c_this->mData = d->raw;
  c_this->mLen = len;
  c_this->mLenRemaining = len;
  c_this->mScale =s;
  PixelController_enable_dithering (c_this, dither);
  c_this->mAdvance = 3;

  c_this->rgb_order[0] = RGB_BYTE(rgb_order,0);
  c_this->rgb_order[1] = RGB_BYTE(rgb_order,1);
  c_this->rgb_order[2] = RGB_BYTE(rgb_order,2);

  PixelController_initOffsets (c_this, len);
}



void PixelController_init_binary_dithering (PixelController* c_this)
{
#if !defined(NO_DITHERING) || (NO_DITHERING != 1)
  // Set 'virtual bits' of dithering to the highest level
  // that is not likely to cause excessive flickering at
  // low brightness levels + low update rates.
  // These pre-set values are a little ambitious, since
  // a 400Hz update rate for WS2811-family LEDs is only
  // possible with 85 pixels or fewer.
  // Once we have a 'number of milliseconds since last update'
  // value available here, we can quickly calculate the correct
  // number of 'virtual bits' on the fly with a couple of 'if'
  // statements -- no division required.  At this point,
  // the division is done at compile time, so there's no runtime
  // cost, but the values are still hard-coded.
#define MAX_LIKELY_UPDATE_RATE_HZ     400
#define MIN_ACCEPTABLE_DITHER_RATE_HZ  50
#define UPDATES_PER_FULL_DITHER_CYCLE (MAX_LIKELY_UPDATE_RATE_HZ / MIN_ACCEPTABLE_DITHER_RATE_HZ)
#define RECOMMENDED_VIRTUAL_BITS ((UPDATES_PER_FULL_DITHER_CYCLE>1) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>2) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>4) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>8) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>16) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>32) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>64) + \
                                  (UPDATES_PER_FULL_DITHER_CYCLE>128) )
#define VIRTUAL_BITS RECOMMENDED_VIRTUAL_BITS
  // R is the digther signal 'counter'.
  static unsigned char R = 0;
  R++;
  // R is wrapped around at 2^ditherBits,
  // so if ditherBits is 2, R will cycle through (0,1,2,3)
  unsigned char ditherBits = VIRTUAL_BITS;
  R &= (0x01 << ditherBits) - 1;
  // Q is the "unscaled dither signal" itself.
  // It's initialized to the reversed bits of R.
  // If 'ditherBits' is 2, Q here will cycle through (0,128,64,192)
  unsigned char Q = 0;
  // Reverse bits in a byte
  {
    if (R & 0x01)
    {
      Q |= 0x80;
    }

    if (R & 0x02)
    {
      Q |= 0x40;
    }

    if (R & 0x04)
    {
      Q |= 0x20;
    }

    if (R & 0x08)
    {
      Q |= 0x10;
    }

    if (R & 0x10)
    {
      Q |= 0x08;
    }

    if (R & 0x20)
    {
      Q |= 0x04;
    }

    if (R & 0x40)
    {
      Q |= 0x02;
    }

    if (R & 0x80)
    {
      Q |= 0x01;
    }
  }

  // Now we adjust Q to fall in the center of each range,
  // instead of at the start of the range.
  // If ditherBits is 2, Q will be (0, 128, 64, 192) at first,
  // and this adjustment makes it (31, 159, 95, 223).
  if ( ditherBits < 8)
  {
    Q += 0x01 << (7 - ditherBits);
  }

  // D and E form the "scaled dither signal"
  // which is added to pixel values to affect the
  // actual dithering.

  // Setup the initial D and E values
  for (int i = 0; i < 3; i++)
  {
    unsigned char s = c_this->mScale.raw[i];
    c_this->e[i] = s ? (256/s) + 1 : 0;
    c_this->d[i] = scale8 (Q, c_this->e[i]);
#if (FASTLED_SCALE8_FIXED == 1)

    if (c_this->d[i])
    {
      (c_this->d[i]--);
    }

#endif

    if (c_this->e[i])
    {
      c_this->e[i]--;
    }
  }

#endif
}


/// set all the leds on the controller to a given color
///@param data the crgb color to set the leds to
///@param nLeds the numner of leds to set to this color
///@param scale the rgb scaling value for outputting color
void CPixelLEDController_showColor(CLEDController* base, CRGB data, int nLeds, CRGB scale)
{
  PixelController pixels;
  PixelController_init_by_rgb(&pixels, &data, nLeds, scale, CLEDController_getDither(base), base->rgb_order);
  ((CPixelLEDController*)(base))->showPixelsCallback(base, &pixels);
}

/// write the passed in rgb data out to the leds managed by this controller
///@param data the rgb data to write out to the strip
///@param nLeds the number of leds being written out
///@param scale the rgb scaling to apply to each led before writing it out
void CPixelLEDController_show(CLEDController* base, CRGB* data, int nLeds, CRGB scale)
{
  PixelController pixels;
  PixelController_init_by_rgb(&pixels, data, nLeds, scale, CLEDController_getDither(base), base->rgb_order);
  ((CPixelLEDController*)(base))->showPixelsCallback(base, &pixels);
}

//public:
void CPixelLEDController_init(CPixelLEDController* c_this, CPixelLEDController_showPixels showPixelsCallback, unsigned char rgb_order)
{
  c_this->showPixelsCallback = showPixelsCallback;
  CLEDController_init(&(c_this->base), CPixelLEDController_showColor, CPixelLEDController_show, rgb_order);
}
//};


