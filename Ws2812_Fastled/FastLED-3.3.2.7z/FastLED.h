#ifndef __INC_FASTSPI_LED2_H
#define __INC_FASTSPI_LED2_H

///@file FastLED.h
/// central include file for FastLED, defines the CFastLED class/object

#define FASTLED_VERSION 3003002

// Utility functions
#include "pixeltypes.h"
#include "controller.h"

/// High level controller interface for FastLED.  This class manages controllers, global settings and trackings
/// such as brightness, and refresh rates, and provides access functions for driving led data to controllers
/// via the show/showColor/clear methods.
/// @nosubgrouping
typedef struct
{
  // int m_nControllers;
  unsigned char  m_Scale;         ///< The current global brightness scale setting
  unsigned short m_nFPS;          ///< Tracking for current FPS value
#if 0
  unsigned int m_nMinMicros;    ///< minimum µs between frames, used for capping frame rates.
#endif
} CFastLED;

void CFastLED_init (CFastLED* c_this);


/// Add a CLEDController instance to the world.  Exposed to the public to allow people to implement their own
/// CLEDController objects or instances.  There are two ways to call this method (as well as the other addLeds)
/// variations.  The first is with 3 arguments, in which case the arguments are the controller, a pointer to
/// led data, and the number of leds used by this controller.  The second is with 4 arguments, in which case
/// the first two arguments are the same, the third argument is an offset into the CRGB data where this controller's
/// CRGB data begins, and the fourth argument is the number of leds for this controller object.
/// @param pLed - the led controller being added
/// @param data - base point to an array of CRGB data structures
/// @param nLedsOrOffset - number of leds (3 argument version) or offset into the data array
/// @param nLedsIfOffset - number of leds (4 argument version)
/// @returns a reference to the added controller
void CFastLED_addLeds (CFastLED* c_this, CLEDController* pLed, CRGB* data, int nLedsOrOffset, int nLedsIfOffset);

//@}

/// Set the global brightness scaling
/// @param scale a 0-255 value for how much to scale all leds before writing them out
void CFastLED_setBrightness (CFastLED* c_this, unsigned char scale);

/// Get the current global brightness setting
/// @returns the current global brightness value
unsigned char CFastLED_getBrightness(CFastLED* c_this);

/// Update all our controllers with the current led colors, using the passed in brightness
/// @param scale temporarily override the scale
void CFastLED_show_scale(CFastLED* c_this, unsigned char scale);

/// Update all our controllers with the current led colors
void CFastLED_show(CFastLED* c_this);

/// clear the leds, wiping the local array of data, optionally black out the leds as well
/// @param writeData whether or not to write out to the leds as well
void CFastLED_clear (CFastLED* c_this, int writeData);

/// clear out the local data array
void CFastLED_clearData(CFastLED* c_this);

/// Set all leds on all controllers to the given color/scale
/// @param color what color to set the leds to
/// @param scale what brightness scale to show at
void CFastLED_showColor_scale(CFastLED* c_this, CRGB color, unsigned char scale);

/// Set all leds on all controllers to the given color
/// @param color what color to set the leds to
void CFastLED_showColor(CFastLED* c_this, CRGB color);

/// Delay for the given number of milliseconds.  Provided to allow the library to be used on platforms
/// that don't have a delay function (to allow code to be more portable).  Note: this will call show
/// constantly to drive the dithering engine (and will call show at least once).
/// @param ms the number of milliseconds to pause for
void CFastLED_delay (unsigned long ms);

/// Set a global color temperature.  Sets the color temperature for all added led strips, overriding whatever
/// previous color temperature those controllers may have had
/// @param temp A CRGB structure describing the color temperature
void CFastLED_setTemperature (CFastLED* c_this, CRGB temp);

/// Set a global color correction.  Sets the color correction for all added led strips,
/// overriding whatever previous color correction those controllers may have had.
/// @param correction A CRGB structure describin the color correction.
void CFastLED_setCorrection (CFastLED* c_this, CRGB correction);

/// Set the dithering mode.  Sets the dithering mode for all added led strips, overriding
/// whatever previous dithering option those controllers may have had.
/// @param ditherMode - what type of dithering to use, either BINARY_DITHER or DISABLE_DITHER
// default ditherMode = BINARY_DITHER;*************default value****************
void CFastLED_setDither (CFastLED* c_this, unsigned char ditherMode);

/// Set the maximum refresh rate.  This is global for all leds.  Attempts to
/// call show faster than this rate will simply wait.  Note that the refresh rate
/// defaults to the slowest refresh rate of all the leds added through addLeds.  If
/// you wish to set/override this rate, be sure to call setMaxRefreshRate _after_
/// adding all of your leds.
/// @param refresh - maximum refresh rate in hz
/// @param constrain - constrain refresh rate to the slowest speed yet set
// default:  constrain=false *************default value****************
void CFastLED_setMaxRefreshRate (CFastLED* c_this, unsigned short refresh, int constrain);

/// for debugging, will keep track of time between calls to countFPS, and every
/// nFrames calls, it will update an internal counter for the current FPS.
/// @todo make this a rolling counter
/// @param nFrames - how many frames to time for determining FPS
//default nFrames=25. *************default value****************
void CFastLED_countFPS (CFastLED* c_this, int nFrames);

/// Get the number of frames/second being written out
/// @returns the most recently computed FPS value
unsigned short CFastLED_getFPS(CFastLED* c_this);

/// Get how many controllers have been registered
/// @returns the number of controllers (strips) that have been added with addLeds
int CFastLED_count(CFastLED* c_this);

/// Get a reference to a registered controller
/// @returns a reference to the Nth controller
CLEDController* CFastLED_getController (CFastLED* c_this, int x);

/// Get the number of leds in the first controller
/// @returns the number of LEDs in the first controller
int CFastLED_size(CFastLED* c_this);

/// Get a pointer to led data for the first controller
/// @returns pointer to the CRGB buffer for the first controller
CRGB* CFastLED_leds(CFastLED* c_this);

#endif
