#ifndef __INC_CONTROLLER_H
#define __INC_CONTROLLER_H

///@file controller.h
/// base definitions used by led controllers for writing out led data
#include "pixeltypes.h"

#define RGB_BYTE(V,X) (((V)>>(3*(2-(X)))) & 0x3)
#define RO(X) RGB_BYTE(RGB, X)

#define RGB_BYTE0(V) ((V>>6) & 0x3)
#define RGB_BYTE1(V) ((V>>3) & 0x3)
#define RGB_BYTE2(V) ((V) & 0x3)

// operator byte *(CRGB[] arr) { return (byte*)arr; }

#define DISABLE_DITHER 0x00
#define BINARY_DITHER 0x01
typedef unsigned char EDitherMode;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// LED Controller interface definition
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// set all the leds on the controller to a given color
///@param data the crgb color to set the leds to
///@param nLeds the numner of leds to set to this color
///@param scale the rgb scaling value for outputting color
typedef void(*CLEDCONTROLLER_SHOWCOLOR)(void* c_this, CRGB data, int nLeds, CRGB scale);

/// write the passed in rgb data out to the leds managed by this controller
///@param data the rgb data to write out to the strip
///@param nLeds the number of leds being written out
///@param scale the rgb scaling to apply to each led before writing it out
typedef void(*CLEDCONTROLLER_SHOW)(void* c_this, CRGB* data, int nLeds, CRGB scale);

typedef struct
{
  CRGB* m_Data;
  void* m_pNext;
  CRGB m_ColorCorrection;
  CRGB m_ColorTemperature;
  EDitherMode m_DitherMode;
  unsigned char rgb_order;
  int m_nLeds;
  CLEDCONTROLLER_SHOWCOLOR showColorCallback;  
  CLEDCONTROLLER_SHOW showCallback;
} CLEDController;


/// Base definition for an LED controller.  Pretty much the methods that every LED controller object will make available.
/// Note that the showARGB method is not impelemented for all controllers yet.   Note also the methods for eventual checking
/// of background writing of data (I'm looking at you, teensy 3.0 DMA controller!).  If you want to pass LED controllers around
/// to methods, make them references to this type, keeps your code saner.  However, most people won't be seeing/using these objects
/// directly at all

CLEDController* CLEDController_get_list_head();
CLEDController* CLEDController_get_list_tail();
void CLEDController_init(CLEDController* c_this, CLEDCONTROLLER_SHOWCOLOR showColorCallback, CLEDCONTROLLER_SHOW showCallback, int rgb_order);

//public:
/// create an led controller object, add it to the chain of controllers

///clear out/zero out the given number of leds.
void CLEDController_clearLeds (CLEDController* c_this, int nLeds);

/// show function w/integer brightness, will scale for color correction and temperature
void CLEDController_show (CLEDController* c_this, CRGB* data, int nLeds, unsigned char brightness);

/// show function w/integer brightness, will scale for color correction and temperature
void CLEDController_showColor_nled (CLEDController* c_this, CRGB data, int nLeds, unsigned char brightness);

/// show function using the "attached to this controller" led data
void CLEDController_showLeds (CLEDController* c_this, unsigned char brightness);

/// show the given color on the led strip
void CLEDController_showColor (CLEDController* c_this, CRGB data, unsigned char brightness);

/// set the default array of leds to be used by this controller
void CLEDController_setLeds (CLEDController* c_this, CRGB* data, int nLeds);

/// zero out the led data managed by this controller
void CLEDController_clearLedData (CLEDController* c_this);

/// How many leds does this controller manage?
int CLEDController_size (CLEDController* c_this);

/// Pointer to the CRGB array for this controller
CRGB* CLEDController_leds(CLEDController* c_this);

/// Reference to the n'th item in the controller
CRGB CLEDController_get_rgb (CLEDController* c_this, int x);

/// get the dithering option currently set for this controller
unsigned char CLEDController_getDither (CLEDController* c_this);

/// the the color corrction to use for this controller, expressed as an rgb object
void CLEDController_setCorrection_rgb(CLEDController* c_this, CRGB correction);

/// set the color correction to use for this controller
void CLEDController_setCorrection_color(CLEDController* c_this, LEDColorCorrection correction);

/// get the correction value used by this controller
CRGB CLEDController_getCorrection (CLEDController* c_this);

/// set the color temperature, aka white point, for this controller
void CLEDController_setTemperature_By_CRGB (CLEDController* c_this, CRGB temperature);

/// set the color temperature, aka white point, for this controller
void CLEDController_setTemperature_value (CLEDController* c_this, ColorTemperature temperature);

/// get the color temperature, aka whipe point, for this controller
CRGB CLEDController_getTemperature_value (CLEDController* c_this);

/// Get the combined brightness/color adjustment for this controller
CRGB CLEDController_getAdjustment (CLEDController* c_this, unsigned char scale);

CRGB CLEDController_computeAdjustment (unsigned char scale, CRGB colorCorrection, CRGB colorTemperature);

unsigned short CLEDController_getMaxRefreshRate();

//end


// Pixel controller class.  This is the class that we use to centralize pixel access in a block of data, including
// support for things like RGB reordering, scaling, dithering, skipping (for ARGB data), and eventually, we will
// centralize 8/12/16 conversions here as well.
#define PIXEL_CONTROLLER_LANES 1
#define PIXEL_CONTROLLER_MASK 0xFFFFFFFF

typedef struct
{
  unsigned char* mData;
  int mLen, mLenRemaining;
  unsigned char d[3];
  unsigned char e[3];
  unsigned char rgb_order[3];
  CRGB mScale;
  char mAdvance;
  int mOffsets[PIXEL_CONTROLLER_LANES];
} PixelController;

void PixelController_init_by_self_type (PixelController* c_this, PixelController other);

void PixelController_initOffsets (PixelController* c_this, int len);

void PixelController_init_by_value (PixelController* c_this, unsigned char* d, int len, CRGB s,
                               EDitherMode dither, int advance, unsigned char skip, unsigned char rgb_order);

void PixelController_init_by_rgb (PixelController* c_this, CRGB* d, int len, CRGB s, EDitherMode dither, unsigned char rgb_order);

void PixelController_init_binary_dithering (PixelController* c_this);


// Do we have n pixels left to process?
inline int PixelController_has (PixelController* c_this, int n)
{
  return c_this->mLenRemaining >= n;
}

// toggle dithering enable
inline void PixelController_enable_dithering (PixelController* c_this, EDitherMode dither)
{
  switch (dither)
  {
    case BINARY_DITHER: PixelController_init_binary_dithering(c_this); break;

    default: c_this->d[0]=c_this->d[1]=c_this->d[2]=c_this->e[0]=c_this->e[1]=c_this->e[2]=0; break;
  }
}

inline int PixelController_size (PixelController* c_this)
{
  return c_this->mLen;
}

// get the amount to advance the pointer by
inline int PixelController_advanceBy (PixelController* c_this)
{
  return c_this->mAdvance;
}

// advance the data pointer forward, adjust position counter
inline void PixelController_advanceData (PixelController* c_this)
{
  c_this->mData += c_this->mAdvance;
  c_this->mLenRemaining--;
}

// step the dithering forward
inline void PixelController_stepDithering (PixelController* c_this)
{
  // IF UPDATING HERE, BE SURE TO UPDATE THE ASM VERSION IN
  // clockless_trinket.h!
  c_this->d[0] = c_this->e[0] - c_this->d[0];
  c_this->d[1] = c_this->e[1] - c_this->d[1];
  c_this->d[2] = c_this->e[2] - c_this->d[2];
}

// Some chipsets pre-cycle the first byte, which means we want to cycle byte 0's dithering separately
inline void PixelController_preStepFirstByteDithering (PixelController* c_this)
{
  c_this->d[c_this->rgb_order[0] ] = c_this->e[c_this->rgb_order[0] ] - c_this->d[c_this->rgb_order[0]];
}

inline unsigned char PixelController_loadByte(PixelController* c_this, int slot)
{
  return c_this->mData[c_this->rgb_order[slot] ];
}
inline unsigned char PixelController_loadByte_lane(PixelController* c_this, int slot, int lane)
{
  return c_this->mData[c_this->mOffsets[lane] + c_this->rgb_order[slot] ];
}

inline unsigned char PixelController_dither_b(PixelController* c_this, int slot, unsigned char b)
{
  return b ? qadd8 (b, c_this->d[c_this->rgb_order[slot] ]) : 0;
}
inline unsigned char PixelController_dither_bd(PixelController* c_this,  int slot,            unsigned char b, unsigned char d)
{
  return b ? qadd8 (b, d) : 0;
}

inline unsigned char PixelController_scale_b(PixelController* c_this, int slot, unsigned char b)
{
  return scale8 (b, c_this->mScale.raw[c_this->rgb_order[slot] ]);
}
inline unsigned char PixelController_scale_bd(PixelController* c_this,  int slot, unsigned char b, unsigned char scale)
{
  return scale8 (b, scale);
}

// composite shortcut functions for loading, dithering, and scaling
inline unsigned char PixelController_loadAndScale(PixelController* c_this, int slot)
{
  return PixelController_scale_b(c_this, slot, PixelController_dither_b(c_this, slot, PixelController_loadByte(c_this, slot) ) );
}
inline unsigned char PixelController_loadAndScale_lane(PixelController* c_this, int slot, int lane)
{
  return PixelController_scale_b(c_this, slot, PixelController_dither_b(c_this, slot, PixelController_loadByte_lane(c_this, slot, lane) ) );
}
inline unsigned char PixelController_loadAndScale_lane_d_scale(PixelController* c_this, int slot, int lane, unsigned char d, unsigned char scale)
{
  return scale8 (PixelController_dither_bd(c_this, slot, PixelController_loadByte_lane(c_this, slot, lane), d), scale);
}
inline unsigned char PixelController_loadAndScale_lane_scale(PixelController* c_this, int slot, int lane, unsigned char scale)
{
  return scale8 (PixelController_loadByte_lane(c_this, slot, lane), scale);
}

inline unsigned char PixelController_advanceAndLoadAndScale(PixelController* c_this, int slot)
{
  PixelController_advanceData(c_this);
  return PixelController_loadAndScale(c_this, slot);
}
inline unsigned char PixelController_advanceAndLoadAndScale_lane(PixelController* c_this, int slot, int lane)
{
  PixelController_advanceData(c_this);
  return PixelController_loadAndScale_lane(c_this, slot, lane);
}
inline unsigned char PixelController_advanceAndLoadAndScale_lane_scale(PixelController* c_this, int slot, int lane, unsigned char scale)
{
  PixelController_advanceData(c_this);
  return PixelController_loadAndScale_lane_scale(c_this, slot, lane, scale);
}

inline unsigned char PixelController_getd (PixelController* c_this, int slot)
{
  return c_this->d[c_this->rgb_order[slot] ];
}
inline unsigned char PixelController_getscale(PixelController* c_this, int slot)
{
  return c_this->mScale.raw[c_this->rgb_order[slot] ];
}

// Helper functions to get around gcc stupidities
inline unsigned char PixelController_loadAndScale0_lane_scale(PixelController* c_this, int lane, unsigned char scale)
{
  return PixelController_loadAndScale_lane_scale(c_this, 0, lane, scale);
}
inline unsigned char PixelController_loadAndScale1_lane_scale(PixelController* c_this, int lane, unsigned char scale)
{
  return PixelController_loadAndScale_lane_scale(c_this, 1, lane, scale);
}
inline unsigned char PixelController_loadAndScale2_lane_scale(PixelController* c_this, int lane, unsigned char scale)
{
  return PixelController_loadAndScale_lane_scale(c_this, 2, lane, scale);
}
inline unsigned char PixelController_advanceAndLoadAndScale0_lane_scale(PixelController* c_this, int lane, unsigned char scale)
{
  return PixelController_advanceAndLoadAndScale_lane_scale(c_this, 0, lane, scale);
}
inline unsigned char PixelController_stepAdvanceAndLoadAndScale0_lane_scale(PixelController* c_this, int lane, unsigned char scale)
{
  PixelController_stepDithering(c_this);
  return PixelController_advanceAndLoadAndScale_lane_scale<0> (c_this, 0, lane, scale);
}

inline unsigned char PixelController_loadAndScale0_lane(PixelController* c_this, int lane)
{
  return PixelController_loadAndScale_lane(c_this, 0, lane);
}
inline unsigned char PixelController_loadAndScale1_lane(PixelController* c_this, int lane)
{
  return PixelController_loadAndScale_lane(c_this, 1, lane);
}
inline unsigned char PixelController_loadAndScale2_lane(PixelController* c_this, int lane)
{
  return PixelController_loadAndScale_lane(c_this, 2, lane);
}
inline unsigned char PixelController_advanceAndLoadAndScale0_lane(PixelController* c_this, int lane)
{
  return PixelController_advanceAndLoadAndScale_lane(c_this, 0, lane);
}
inline unsigned char PixelController_stepAdvanceAndLoadAndScale0_lane(PixelController* c_this, int lane)
{
  PixelController_stepDithering(c_this);
  return PixelController_advanceAndLoadAndScale_lane(c_this, 0, lane);
}

inline unsigned char PixelController_loadAndScale0(PixelController* c_this)
{
  return PixelController_loadAndScale(c_this, 0);
}
inline unsigned char PixelController_loadAndScale1(PixelController* c_this)
{
  return PixelController_loadAndScale(c_this, 1);
}
inline unsigned char PixelController_loadAndScale2(PixelController* c_this)
{
  return PixelController_loadAndScale(c_this, 2);
}
inline unsigned char PixelController_advanceAndLoadAndScale0(PixelController* c_this)
{
  return PixelController_advanceAndLoadAndScale(c_this, 0);
}
inline unsigned char PixelController_stepAdvanceAndLoadAndScale0(PixelController* c_this)
{
  PixelController_stepDithering(c_this);
  return PixelController_advanceAndLoadAndScale(c_this, 0);
}

inline unsigned char PixelController_getScale0(PixelController* c_this)
{
  return PixelController_getscale(c_this, 0);
}
inline unsigned char PixelController_getScale1(PixelController* c_this)
{
  return PixelController_getscale(c_this, 1);
}
inline unsigned char PixelController_getScale2(PixelController* c_this)
{
  return PixelController_getscale(c_this, 2);
}

typedef void(*CPixelLEDController_showPixels)(void* base, PixelController* pixels);

typedef struct
{
  CLEDController base;
  CPixelLEDController_showPixels showPixelsCallback;
}CPixelLEDController;


/// set all the leds on the controller to a given color
///@param data the crgb color to set the leds to
///@param nLeds the numner of leds to set to this color
///@param scale the rgb scaling value for outputting color
void CPixelLEDController_showColor(CLEDController* base, CRGB data, int nLeds, CRGB scale);

/// write the passed in rgb data out to the leds managed by this controller
///@param data the rgb data to write out to the strip
///@param nLeds the number of leds being written out
///@param scale the rgb scaling to apply to each led before writing it out
void CPixelLEDController_show(CLEDController* base, CRGB* data, int nLeds, CRGB scale);

//public:
void CPixelLEDController_init(CPixelLEDController* c_this, CPixelLEDController_showPixels showPixelsCallback, unsigned char rgb_order);
//};


#endif
