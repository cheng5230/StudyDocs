#ifndef __INC_BITSWAP_H
#define __INC_BITSWAP_H

///@file bitswap.h
///Functions for rotating bits/bytes

///@defgroup Bitswap Bit swapping/rotate
///Functions for doing a rotation of bits/bytes used by parallel output
///@{
#if defined(FASTLED_ARM) || defined(FASTLED_ESP8266)
/// structure representing 8 bits of access
typedef union
{
  unsigned char raw;
  struct
  {
    unsigned int a0:1;
    unsigned int a1:1;
    unsigned int a2:1;
    unsigned int a3:1;
    unsigned int a4:1;
    unsigned int a5:1;
    unsigned int a6:1;
    unsigned int a7:1;
  };
} just8bits;

/// structure representing 32 bits of access
typedef struct
{
  unsigned int a0:1;
  unsigned int a1:1;
  unsigned int a2:1;
  unsigned int a3:1;
  unsigned int a4:1;
  unsigned int a5:1;
  unsigned int a6:1;
  unsigned int a7:1;
  unsigned int b0:1;
  unsigned int b1:1;
  unsigned int b2:1;
  unsigned int b3:1;
  unsigned int b4:1;
  unsigned int b5:1;
  unsigned int b6:1;
  unsigned int b7:1;
  unsigned int c0:1;
  unsigned int c1:1;
  unsigned int c2:1;
  unsigned int c3:1;
  unsigned int c4:1;
  unsigned int c5:1;
  unsigned int c6:1;
  unsigned int c7:1;
  unsigned int d0:1;
  unsigned int d1:1;
  unsigned int d2:1;
  unsigned int d3:1;
  unsigned int d4:1;
  unsigned int d5:1;
  unsigned int d6:1;
  unsigned int d7:1;
} sub4;

/// union containing a full 8 bytes to swap the bit orientation on
typedef union
{
  unsigned int word[2];
  unsigned char bytes[8];
  struct
  {
    sub4 a;
    sub4 b;
  };
} bitswap_type;



/// Do an 8byte by 8bit rotation
inline void swapbits8 (bitswap_type in, bitswap_type& out)
{
  for (int i = 0; i < 8; i++)
  {
    just8bits work;
    work.a3 = in.word[0] >> 31;
    work.a2 = in.word[0] >> 23;
    work.a1 = in.word[0] >> 15;
    work.a0 = in.word[0] >> 7;
    in.word[0] <<= 1;
    work.a7 = in.word[1] >> 31;
    work.a6 = in.word[1] >> 23;
    work.a5 = in.word[1] >> 15;
    work.a4 = in.word[1] >> 7;
    in.word[1] <<= 1;
    out.bytes[i] = work.raw;
  }
}

/// Slow version of the 8 byte by 8 bit rotation
inline void slowswap (unsigned char* A, unsigned char* B)
{
  for (int row = 0; row < 7; row++)
  {
    unsigned char x = A[row];
    unsigned char bit = (1<<row);
    unsigned char* p = B;

    for (unsigned int mask = 1<<7 ; mask ; mask >>= 1)
    {
      if (x & mask)
      {
        *p++ |= bit;
      }
      else
      {
        *p++ &= ~bit;
      }
    }
  }
}

void transpose8x1_noinline (unsigned char* A, unsigned char* B);

/// Simplified form of bits rotating function.  Based on code found here - http://www.hackersdelight.org/hdcodetxt/transpose8.c.txt - rotating
/// data into LSB for a faster write (the code using this data can happily walk the array backwards)
inline void transpose8x1 (unsigned char* A, unsigned char* B)
{
  unsigned int x, y, t;
  // Load the array and pack it into x and y.
  y = * (unsigned int*) (A);
  x = * (unsigned int*) (A+4);
  // pre-transform x
  t = (x ^ (x >> 7) ) & 0x00AA00AA;  x = x ^ t ^ (t << 7);
  t = (x ^ (x >>14) ) & 0x0000CCCC;  x = x ^ t ^ (t <<14);
  // pre-transform y
  t = (y ^ (y >> 7) ) & 0x00AA00AA;  y = y ^ t ^ (t << 7);
  t = (y ^ (y >>14) ) & 0x0000CCCC;  y = y ^ t ^ (t <<14);
  // final transform
  t = (x & 0xF0F0F0F0) | ( (y >> 4) & 0x0F0F0F0F);
  y = ( (x << 4) & 0xF0F0F0F0) | (y & 0x0F0F0F0F);
  x = t;
  * ( (unsigned int*) B) = y;
  * ( (unsigned int*) (B+4) ) = x;
}

/// Simplified form of bits rotating function.  Based on code  found here - http://www.hackersdelight.org/hdcodetxt/transpose8.c.txt
inline void transpose8x1_MSB (unsigned char* A, unsigned char* B)
{
  unsigned int x, y, t;
  // Load the array and pack it into x and y.
  y = * (unsigned int*) (A);
  x = * (unsigned int*) (A+4);
  // pre-transform x
  t = (x ^ (x >> 7) ) & 0x00AA00AA;  x = x ^ t ^ (t << 7);
  t = (x ^ (x >>14) ) & 0x0000CCCC;  x = x ^ t ^ (t <<14);
  // pre-transform y
  t = (y ^ (y >> 7) ) & 0x00AA00AA;  y = y ^ t ^ (t << 7);
  t = (y ^ (y >>14) ) & 0x0000CCCC;  y = y ^ t ^ (t <<14);
  // final transform
  t = (x & 0xF0F0F0F0) | ( (y >> 4) & 0x0F0F0F0F);
  y = ( (x << 4) & 0xF0F0F0F0) | (y & 0x0F0F0F0F);
  x = t;
  B[7] = y; y >>= 8;
  B[6] = y; y >>= 8;
  B[5] = y; y >>= 8;
  B[4] = y;
  B[3] = x; x >>= 8;
  B[2] = x; x >>= 8;
  B[1] = x; x >>= 8;
  B[0] = x; /* */
}

/// templated bit-rotating function.   Based on code found here - http://www.hackersdelight.org/hdcodetxt/transpose8.c.txt
template<int m, int n> inline void transpose8 (unsigned char* A, unsigned char* B)
{
  unsigned int x, y, t;

  // Load the array and pack it into x and y.
  if (m == 1)
  {
    y = * (unsigned int*) (A);
    x = * (unsigned int*) (A+4);
  }
  else
  {
    x = (A[0]<<24)   | (A[m]<<16)   | (A[2*m]<<8) | A[3*m];
    y = (A[4*m]<<24) | (A[5*m]<<16) | (A[6*m]<<8) | A[7*m];
  }

  // pre-transform x
  t = (x ^ (x >> 7) ) & 0x00AA00AA;  x = x ^ t ^ (t << 7);
  t = (x ^ (x >>14) ) & 0x0000CCCC;  x = x ^ t ^ (t <<14);
  // pre-transform y
  t = (y ^ (y >> 7) ) & 0x00AA00AA;  y = y ^ t ^ (t << 7);
  t = (y ^ (y >>14) ) & 0x0000CCCC;  y = y ^ t ^ (t <<14);
  // final transform
  t = (x & 0xF0F0F0F0) | ( (y >> 4) & 0x0F0F0F0F);
  y = ( (x << 4) & 0xF0F0F0F0) | (y & 0x0F0F0F0F);
  x = t;
  B[7*n] = y; y >>= 8;
  B[6*n] = y; y >>= 8;
  B[5*n] = y; y >>= 8;
  B[4*n] = y;
  B[3*n] = x; x >>= 8;
  B[2*n] = x; x >>= 8;
  B[n] = x; x >>= 8;
  B[0] = x;
  // B[0]=x>>24;    B[n]=x>>16;    B[2*n]=x>>8;  B[3*n]=x>>0;
  // B[4*n]=y>>24;  B[5*n]=y>>16;  B[6*n]=y>>8;  B[7*n]=y>>0;
}

#endif

///@}
#endif
