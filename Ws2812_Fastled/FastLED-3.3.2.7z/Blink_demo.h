#ifndef __BLINK_DEMO_H
#define __BLINK_DEMO_H

#include "tuya_adapter_platform.h"
#include <FastLED.h>
#include "pixeltypes.h"
#include "chipsets.h"
#include "led_driver.h"
#include "system_porting.h"


#ifdef __cplusplus
  extern "C" {
#endif


// How many leds in your strip?
#define NUM_LEDS  DISPLAY_BUF_MAX_PIXEL

// Define the array of leds
extern CRGB leds[NUM_LEDS]; 
extern CFastLED fast_led;
void FastledSetup(void);
void Blinkloop(void);

#ifdef __cplusplus
}
#endif

#endif

