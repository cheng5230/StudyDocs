#ifndef __INC_PIXELS_H
#define __INC_PIXELS_H

//#include <stdint.h>
#include "fastled_config.h"
#include "lib8tion.h"
#include "color.h"

///@defgroup Pixeltypes CHSV and CRGB type definitions
///@{


/// Representation of an HSV pixel (hue, saturation, value (aka brightness)).
typedef struct
{
  unsigned char h;
  unsigned char s;
  unsigned char v;
} CHSV;

inline CHSV struct_HSV_by_h_s_v(unsigned char h, unsigned char s, unsigned char v)
{
  CHSV hsv;
  hsv.h = h;
  hsv.s = s;
  hsv.v = v;
  return hsv;
}

inline void HSV_init_by_h_s_v(CHSV* c_this, unsigned char h, unsigned char s, unsigned char v)
{
  c_this->h = h;
  c_this->s = s;
  c_this->v = v;
}

inline void HSV_init_by_hsv(CHSV* c_this, CHSV rhs)
{
  c_this->h = rhs.h;
  c_this->s = rhs.s;
  c_this->v = rhs.v;
}


/// Pre-defined hue values for HSV objects
typedef enum
{
  HUE_RED = 0,
  HUE_ORANGE = 39,
  HUE_YELLOW = 60,
  HUE_GREEN = 120,
  HUE_AQUA = 160,
  HUE_BLUE = 240,
  HUE_PURPLE = 277,
  HUE_PINK = 349
} HSVHue;

/// Representation of an RGB pixel (Red, Green, Blue)
typedef struct
{
  union
  {
    struct
    {
      unsigned char r;
      unsigned char g;
      unsigned char b;
    };
    unsigned char raw[3];
  };
} CRGB;

/// Forward declaration of hsv2rgb_rainbow here,
/// to avoid circular dependencies.
CRGB hsv2rgb_rainbow(CHSV hsv);

/// Array access operator to index into the crgb object
inline unsigned char RGB_getRaw(CRGB c_this, unsigned char x)
{
  return c_this.raw[x];
}

inline CRGB struct_RGB_by_r_g_b(unsigned char r, unsigned char g, unsigned char b)
{
  CRGB rgb;
  rgb.r = r;
  rgb.g = g;
  rgb.b = b;
  return rgb;
}

/*************** fastled 显示驱动*******************/
inline void RGB_SetOnePixelColor(CRGB *c_this,uint16_t len,uint32_t colors)
{
  c_this[len].raw[0]= (colors >> 16);
  c_this[len].raw[1]= (colors >> 8);
  c_this[len].raw[2]= (colors);
}

/// allow construction from 32-bit (really 24-bit) bit 0xRRGGBB color code
inline void RGB_initByColor (CRGB* c_this, unsigned int colorcode)
{
  c_this->r = (colorcode >> 16) & 0xFF;
  c_this->g = (colorcode >> 8) & 0xFF;
  c_this->b = (colorcode >> 0) & 0xFF;
}

/// allow copy construction
inline void RGB_initByRGB(CRGB* c_this, CRGB rhs)
{
  c_this->r = rhs.r;
  c_this->g = rhs.g;
  c_this->b = rhs.b;
}

inline void RGB_initByHSV(CRGB* c_this,  CHSV rhs)
{
  *c_this = hsv2rgb_rainbow( rhs);
}

inline void RGB_initBy_H_S_V(CRGB* c_this, unsigned char h, unsigned char s, unsigned char v)
{
  CHSV rhs;
  rhs.h = h;
  rhs.s = s;
  rhs.v = v;
  RGB_initByHSV(c_this, rhs);
}
/// add one RGB to another, saturating at 0xFF for each channel
inline void RGB_addRGB (CRGB* c_this, CRGB rhs)
{
  c_this->r = qadd8 ( c_this->r, rhs.r);
  c_this->g = qadd8 ( c_this->g, rhs.g);
  c_this->b = qadd8 ( c_this->b, rhs.b);
}

/// add a contstant to each channel, saturating at 0xFF
/// this is NOT an operator+= overload because the compiler
/// can't usefully decide when it's being passed a 32-bit
/// constant (e.g. CRGB::Red) and an 8-bit one (CRGB::Blue)
inline void RGB_addCons (CRGB* c_this, unsigned char d )
{
  c_this->r = qadd8 ( c_this->r, d);
  c_this->g = qadd8 ( c_this->g, d);
  c_this->b = qadd8 ( c_this->b, d);
}

/// subtract one RGB from another, saturating at 0x00 for each channel
inline void RGB_subRGB (CRGB* c_this, CRGB sub )
{
  c_this->r = qsub8 ( c_this->r, sub.r);
  c_this->g = qsub8 ( c_this->g, sub.g);
  c_this->b = qsub8 ( c_this->b, sub.b);
}

/// subtract a constant from each channel, saturating at 0x00
/// this is NOT an operator+= overload because the compiler
/// can't usefully decide when it's being passed a 32-bit
/// constant (e.g. CRGB::Red) and an 8-bit one (CRGB::Blue)
inline void RGB_subCons (CRGB* c_this, unsigned char d )
{
  c_this->r = qsub8 ( c_this->r, d);
  c_this->g = qsub8 ( c_this->g, d);
  c_this->b = qsub8 ( c_this->b, d);
}

/// divide each of the channels by a constant
inline void RGB_divCons (CRGB* c_this, unsigned char d )
{
  c_this->r /= d;
  c_this->g /= d;
  c_this->b /= d;
}

/// right shift each of the channels by a constant
inline void RGB_shiftRight (CRGB* c_this, unsigned char d)
{
  c_this->r >>= d;
  c_this->g >>= d;
  c_this->b >>= d;
}

/// multiply each of the channels by a constant,
/// saturating each channel at 0xFF
inline void RGB_mulCons (CRGB* c_this, unsigned char d )
{
  c_this->r = qmul8 ( c_this->r, d);
  c_this->g = qmul8 ( c_this->g, d);
  c_this->b = qmul8 ( c_this->b, d);
}

/// scale down a RGB to N 256ths of it's current brightness, using
/// 'video' dimming rules, which means that unless the scale factor is ZERO
/// each channel is guaranteed NOT to dim down to zero.  If it's already
/// nonzero, it'll stay nonzero, even if that means the hue shifts a little
/// at low brightness levels.
inline void RGB_nscale8_video (CRGB* c_this, unsigned char scaledown )
{
  nscale8x3_video ( & (c_this->r), & (c_this->g), & (c_this->b), scaledown);
}

/// %= is a synonym for nscale8_video.  Think of it is scaling down
/// by "a percentage"
inline void RGB_modCons (CRGB* c_this, unsigned char scaledown )
{
  nscale8x3_video ( & (c_this->r), & (c_this->g), & (c_this->b), scaledown);
}

/// fadeLightBy is a synonym for nscale8_video( ..., 255-fadefactor)
inline void RGB_fadeLightBy (CRGB* c_this, unsigned char fadefactor )
{
  nscale8x3_video ( & (c_this->r), & (c_this->g), & (c_this->b), 255 - fadefactor);
}

/// scale down a RGB to N 256ths of it's current brightness, using
/// 'plain math' dimming rules, which means that if the low light levels
/// may dim all the way to 100% black.
inline void RGB_nscale8 (CRGB* c_this, unsigned char scaledown )
{
  nscale8x3 ( & (c_this->r), & (c_this->g), & (c_this->b), scaledown);
}

/// scale down a RGB to N 256ths of it's current brightness, using
/// 'plain math' dimming rules, which means that if the low light levels
/// may dim all the way to 100% black.
inline void RGB_nscale8RGB (CRGB* c_this, CRGB scaledown )
{
  c_this->r = scale8 (c_this->r, scaledown.r);
  c_this->g = scale8 (c_this->g, scaledown.g);
  c_this->b = scale8 (c_this->b, scaledown.b);
}

/// return a CRGB object that is a scaled down version of this object
inline CRGB RGB_scale8RGB (CRGB rgb, CRGB scaledown )
{
  rgb.r = scale8 (rgb.r, scaledown.r);
  rgb.g = scale8 (rgb.g, scaledown.g);
  rgb.b = scale8 (rgb.b, scaledown.b);
  return rgb;
}

/// fadeToBlackBy is a synonym for nscale8( ..., 255-fadefactor)
inline void RGB_fadeToBlackBy (CRGB* c_this, unsigned char fadefactor )
{
  nscale8x3 ( & (c_this->r), & (c_this->g), & (c_this->b),  255 - fadefactor);
}

/// "or" operator brings each channel up to the higher of the two values
inline void RGB_orRGB (CRGB* c_this, CRGB rhs )
{
  if ( rhs.r > c_this->r)
  {
    c_this->r = rhs.r;
  }

  if ( rhs.g > c_this->g)
  {
    c_this->g = rhs.g;
  }

  if ( rhs.b > c_this->b)
  {
    c_this->b = rhs.b;
  }
}

/// "or" operator brings each channel up to the higher of the two values
inline void RGB_orCons (CRGB* c_this, unsigned char d )
{
  if ( d > c_this->r)
  {
    c_this->r = d;
  }

  if ( d > c_this->g)
  {
    c_this->g = d;
  }

  if ( d > c_this->b)
  {
    c_this->b = d;
  }
}

/// "and" operator brings each channel down to the lower of the two values
inline void RGB_andRGB (CRGB* c_this, CRGB rhs )
{
  if ( rhs.r < c_this->r)
  {
    c_this->r = rhs.r;
  }

  if ( rhs.g < c_this->g)
  {
    c_this->g = rhs.g;
  }

  if ( rhs.b < c_this->b)
  {
    c_this->b = rhs.b;
  }
}

/// "and" operator brings each channel down to the lower of the two values
inline CRGB RGB_andCons (CRGB* c_this, unsigned char d )
{
  if ( d < c_this->r)
  {
    c_this->r = d;
  }

  if ( d < c_this->g)
  {
    c_this->g = d;
  }

  if ( d < c_this->b)
  {
    c_this->b = d;
  }
}

/// this allows testing a CRGB for zero-ness
inline int RGB_isNotZero (CRGB rgb)
{
  return rgb.r || rgb.g || rgb.b;
  if(rgb.r || rgb.g || rgb.b)
  {
    return 1;
  }
  return 0;
}

/// invert each channel
inline CRGB RGB_invert (CRGB rgb)
{
  rgb.r = 255 - rgb.r;
  rgb.g = 255 - rgb.g;
  rgb.b = 255 - rgb.b;
  return rgb;
}

/// Get the 'luma' of a CRGB object - aka roughly how much light the
/// CRGB pixel is putting out (from 0 to 255).
inline unsigned char RGB_getLuma (CRGB rgb )
{
  //Y' = 0.2126 R' + 0.7152 G' + 0.0722 B'
  //     54            183       18 (!)
  unsigned char luma = scale8 ( rgb.r, 54) + \
                       scale8 ( rgb.g, 183) + \
                       scale8 ( rgb.b, 18);
  return luma;
}

/// Get the average of the R, G, and B values
inline unsigned char RGB_getAverageLight (CRGB rgb )
{
#if FASTLED_SCALE8_FIXED == 1
  const unsigned char eightyfive = 85;
#else
  const unsigned char eightyfive = 86;
#endif
  unsigned char avg = scale8 ( rgb.r, eightyfive) + \
                      scale8 ( rgb.g, eightyfive) + \
                      scale8 ( rgb.b, eightyfive);
  return avg;
}

/// maximize the brightness of this CRGB object
//default: limit = 255 **********default value***************
inline void RGB_maximizeBrightness ( CRGB* rgb, unsigned char limit )
{
  unsigned char max = rgb->r;

  if ( rgb->g > max)
  {
    max = rgb->g;
  }

  if ( rgb->b > max)
  {
    max = rgb->b;
  }

  // stop div/0 when color is black
  if (max > 0)
  {
    unsigned short factor = ( (unsigned short) (limit) * 256) / max;
    rgb->r =   (rgb->r   * factor) / 256;
    rgb->g = (rgb->g * factor) / 256;
    rgb->b =  (rgb->b  * factor) / 256;
  }
}

/// return a new CRGB object after performing a linear interpolation between this object and the passed in object
inline CRGB RGB_lerp8 (CRGB c_this, CRGB other, fract8 frac)
{
  c_this.r = lerp8by8 (c_this.r, other.r, frac);
  c_this.g = lerp8by8 (c_this.g, other.g, frac);
  c_this.b = lerp8by8 (c_this.b, other.b, frac);
  return c_this;
}

/// return a new CRGB object after performing a linear interpolation between this object and the passed in object
inline CRGB RGB_lerp16 ( CRGB c_this,  CRGB other, fract16 frac)
{
  c_this.r = lerp16by16 (c_this.r<<8, other.r<<8, frac) >>8;
  c_this.g = lerp16by16 (c_this.g<<8, other.g<<8, frac) >>8;
  c_this.b = lerp16by16 (c_this.b<<8, other.b<<8, frac) >>8;
  return c_this;
}

/// getParity returns 0 or 1, depending on the
/// lowest bit of the sum of the color components.
inline unsigned char RGB_getParity (CRGB rgb)
{
  unsigned char sum = rgb.r + rgb.g + rgb.b;
  return (sum & 0x01);
}

/// setParity adjusts the color in the smallest
/// way possible so that the parity of the color
/// is now the desired value.  This allows you to
/// 'hide' one bit of information in the color.
///
/// Ideally, we find one color channel which already
/// has data in it, and modify just that channel by one.
/// We don't want to light up a channel that's black
/// if we can avoid it, and if the pixel is 'grayscale',
/// (meaning that R==G==B), we modify all three channels
/// at once, to preserve the neutral hue.
///
/// There's no such thing as a free lunch; in many cases
/// this 'hidden bit' may actually be visible, but this
/// code makes reasonable efforts to hide it as much
/// as is reasonably possible.
///
/// Also, an effort is made to have make it such that
/// repeatedly setting the parity to different values
/// will not cause the color to 'drift'.  Toggling
/// the parity twice should generally result in the
/// original color again.
///
inline void RGB_setParity ( CRGB* rgb, unsigned char parity)
{
  unsigned char curparity = RGB_getParity(*rgb);

  if ( parity == curparity)
  {
    return;
  }

  if ( parity )
  {
    // going 'up'
    if ( (rgb->b > 0) && (rgb->b < 255) )
    {
      if ( rgb->r == rgb->g && rgb->g == rgb->b)
      {
        rgb->r++;
        rgb->g++;
      }

      rgb->b++;
    }
    else if ( (rgb->r > 0) && (rgb->r < 255) )
    {
      rgb->r++;
    }
    else if ( (rgb->g > 0) && (rgb->g < 255) )
    {
      rgb->g++;
    }
    else
    {
      if ( rgb->r == rgb->g && rgb->g == rgb->b)
      {
        rgb->r ^= 0x01;
        rgb->g ^= 0x01;
      }

      rgb->b ^= 0x01;
    }
  }
  else
  {
    // going 'down'
    if ( rgb->b > 1)
    {
      if ( rgb->r == rgb->g && rgb->g == rgb->b)
      {
        rgb->r--;
        rgb->g--;
      }

      rgb->b--;
    }
    else if ( rgb->g > 1)
    {
      rgb->g--;
    }
    else if ( rgb->r > 1)
    {
      rgb->r--;
    }
    else
    {
      if ( rgb->r == rgb->g && rgb->g == rgb->b)
      {
        rgb->r ^= 0x01;
        rgb->g ^= 0x01;
      }

      rgb->b ^= 0x01;
    }
  }
}

/// Predefined RGB colors
enum
{
  AliceBlue=0xF0F8FF,
  Amethyst=0x9966CC,
  AntiqueWhite=0xFAEBD7,
  Aqua=0x00FFFF,
  Aquamarine=0x7FFFD4,
  Azure=0xF0FFFF,
  Beige=0xF5F5DC,
  Bisque=0xFFE4C4,
  Black=0x000000,
  BlanchedAlmond=0xFFEBCD,
  Blue=0x0000FF,
  BlueViolet=0x8A2BE2,
  Brown=0xA52A2A,
  BurlyWood=0xDEB887,
  CadetBlue=0x5F9EA0,
  Chartreuse=0x7FFF00,
  Chocolate=0xD2691E,
  Coral=0xFF7F50,
  CornflowerBlue=0x6495ED,
  Cornsilk=0xFFF8DC,
  Crimson=0xDC143C,
  Cyan=0x00FFFF,
  DarkBlue=0x00008B,
  DarkCyan=0x008B8B,
  DarkGoldenrod=0xB8860B,
  DarkGray=0xA9A9A9,
  DarkGrey=0xA9A9A9,
  DarkGreen=0x006400,
  DarkKhaki=0xBDB76B,
  DarkMagenta=0x8B008B,
  DarkOliveGreen=0x556B2F,
  DarkOrange=0xFF8C00,
  DarkOrchid=0x9932CC,
  DarkRed=0x8B0000,
  DarkSalmon=0xE9967A,
  DarkSeaGreen=0x8FBC8F,
  DarkSlateBlue=0x483D8B,
  DarkSlateGray=0x2F4F4F,
  DarkSlateGrey=0x2F4F4F,
  DarkTurquoise=0x00CED1,
  DarkViolet=0x9400D3,
  DeepPink=0xFF1493,
  DeepSkyBlue=0x00BFFF,
  DimGray=0x696969,
  DimGrey=0x696969,
  DodgerBlue=0x1E90FF,
  FireBrick=0xB22222,
  FloralWhite=0xFFFAF0,
  ForestGreen=0x228B22,
  Fuchsia=0xFF00FF,
  Gainsboro=0xDCDCDC,
  GhostWhite=0xF8F8FF,
  Gold=0xFFD700,
  Goldenrod=0xDAA520,
  Gray=0x808080,
  Grey=0x808080,
  Green=0x008000,
  GreenYellow=0xADFF2F,
  Honeydew=0xF0FFF0,
  HotPink=0xFF69B4,
  IndianRed=0xCD5C5C,
  Indigo=0x4B0082,
  Ivory=0xFFFFF0,
  Khaki=0xF0E68C,
  Lavender=0xE6E6FA,
  LavenderBlush=0xFFF0F5,
  LawnGreen=0x7CFC00,
  LemonChiffon=0xFFFACD,
  LightBlue=0xADD8E6,
  LightCoral=0xF08080,
  LightCyan=0xE0FFFF,
  LightGoldenrodYellow=0xFAFAD2,
  LightGreen=0x90EE90,
  LightGrey=0xD3D3D3,
  LightPink=0xFFB6C1,
  LightSalmon=0xFFA07A,
  LightSeaGreen=0x20B2AA,
  LightSkyBlue=0x87CEFA,
  LightSlateGray=0x778899,
  LightSlateGrey=0x778899,
  LightSteelBlue=0xB0C4DE,
  LightYellow=0xFFFFE0,
  Lime=0x00FF00,
  LimeGreen=0x32CD32,
  Linen=0xFAF0E6,
  Magenta=0xFF00FF,
  Maroon=0x800000,
  MediumAquamarine=0x66CDAA,
  MediumBlue=0x0000CD,
  MediumOrchid=0xBA55D3,
  MediumPurple=0x9370DB,
  MediumSeaGreen=0x3CB371,
  MediumSlateBlue=0x7B68EE,
  MediumSpringGreen=0x00FA9A,
  MediumTurquoise=0x48D1CC,
  MediumVioletRed=0xC71585,
  MidnightBlue=0x191970,
  MintCream=0xF5FFFA,
  MistyRose=0xFFE4E1,
  Moccasin=0xFFE4B5,
  NavajoWhite=0xFFDEAD,
  Navy=0x000080,
  OldLace=0xFDF5E6,
  Olive=0x808000,
  OliveDrab=0x6B8E23,
  Orange=0xFFA500,
  OrangeRed=0xFF4500,
  Orchid=0xDA70D6,
  PaleGoldenrod=0xEEE8AA,
  PaleGreen=0x98FB98,
  PaleTurquoise=0xAFEEEE,
  PaleVioletRed=0xDB7093,
  PapayaWhip=0xFFEFD5,
  PeachPuff=0xFFDAB9,
  Peru=0xCD853F,
  Pink=0xFFC0CB,
  Plaid=0xCC5533,
  Plum=0xDDA0DD,
  PowderBlue=0xB0E0E6,
  Purple=0x800080,
  Red=0xFF0000,
  RosyBrown=0xBC8F8F,
  RoyalBlue=0x4169E1,
  SaddleBrown=0x8B4513,
  Salmon=0xFA8072,
  SandyBrown=0xF4A460,
  SeaGreen=0x2E8B57,
  Seashell=0xFFF5EE,
  Sienna=0xA0522D,
  Silver=0xC0C0C0,
  SkyBlue=0x87CEEB,
  SlateBlue=0x6A5ACD,
  SlateGray=0x708090,
  SlateGrey=0x708090,
  Snow=0xFFFAFA,
  SpringGreen=0x00FF7F,
  SteelBlue=0x4682B4,
  Tan=0xD2B48C,
  Teal=0x008080,
  Thistle=0xD8BFD8,
  Tomato=0xFF6347,
  Turquoise=0x40E0D0,
  Violet=0xEE82EE,
  Wheat=0xF5DEB3,
  White=0xFFFFFF,
  WhiteSmoke=0xF5F5F5,
  Yellow=0xFFFF00,
  YellowGreen=0x9ACD32,

  // LED RGB color that roughly approximates
  // the color of incandescent fairy lights,
  // assuming that you're using FastLED
  // color correction on your LEDs (recommended).
  FairyLight=0xFFE42D,
  // If you are using no color correction, use this
  FairyLightNCC=0xFF9D2A

};


inline int RGB_compare(CRGB lhs, CRGB rhs)
{
  if((lhs.r == rhs.r) && (lhs.g == rhs.g) && (lhs.b == rhs.b) )
  {
    return 1;
  }
  return 0;
}

inline int RGB_notEqual(CRGB lhs, CRGB rhs)
{
  int ret = RGB_compare(lhs, rhs);
  return (1 - ret);
}

inline int RGB_less(CRGB lhs, CRGB rhs)
{
  unsigned short sl, sr;
  sl = lhs.r + lhs.g + lhs.b;
  sr = rhs.r + rhs.g + rhs.b;
  if(sl < sr)
  {
    return 1;
  }
  return 0;
}

inline int RGB_large(CRGB lhs, CRGB rhs)
{
  unsigned short sl, sr;
  sl = lhs.r + lhs.g + lhs.b;
  sr = rhs.r + rhs.g + rhs.b;
  if(sl > sr)
  {
    return 1;
  }
  return 0;
}

inline int RGB_large_equal(CRGB lhs, CRGB rhs)
{
  if(RGB_less(lhs, rhs) == 1)
  {
    return 0;
  }
  return 1;
}

inline int RGB_less_equal(CRGB lhs, CRGB rhs)
{
  if(RGB_large(lhs, rhs) == 1)
  {
    return 0;
  }
  return 1;
}


/// RGB orderings, used when instantiating controllers to determine what
/// order the controller should send RGB data out in, RGB being the default
/// ordering.
// octonary 
enum EOrder
{
  RGB=0012,
  RBG=0021,
  GRB=0102,
  GBR=0120,
  BRG=0201,
  BGR=0210
};

///@}

#endif
