#ifndef __INC_LIB8TION_SCALE_H
#define __INC_LIB8TION_SCALE_H
#include "fastled_config.h"

///@ingroup lib8tion

///@defgroup Scaling Scaling functions
/// Fast, efficient 8-bit scaling functions specifically
/// designed for high-performance LED programming.
///
/// Because of the AVR(Arduino) and ARM assembly language
/// implementations provided, using these functions often
/// results in smaller and faster code than the equivalent
/// program using plain "C" arithmetic and logic.
///@{

///  scale one byte by a second one, which is treated as
///  the numerator of a fraction whose denominator is 256
///  In other words, it computes i * (scale / 256)
///  4 clocks AVR with MUL, 2 clocks ARM
static inline unsigned char scale8 ( unsigned char i, fract8 scale)
{
#if (FASTLED_SCALE8_FIXED == 1)
  return ( ( (unsigned short) i) * (1+ (unsigned short) (scale) ) ) >> 8;
#else
  return ( (unsigned short) i * (unsigned short) (scale) ) >> 8;
#endif
}


///  The "video" version of scale8 guarantees that the output will
///  be only be zero if one or both of the inputs are zero.  If both
///  inputs are non-zero, the output is guaranteed to be non-zero.
///  This makes for better 'video'/LED dimming, at the cost of
///  several additional cycles.
static inline unsigned char scale8_video ( unsigned char i, fract8 scale)
{
  unsigned char j = ( ( (int) i * (int) scale) >> 8) + ( (i&&scale) ?1:0);
  // unsigned char nonzeroscale = (scale != 0) ? 1 : 0;
  // unsigned char j = (i == 0) ? 0 : (((int)i * (int)(scale) ) >> 8) + nonzeroscale;
  return j;
}

/// scale three one byte values by a fourth one, which is treated as
///         the numerator of a fraction whose demominator is 256
///         In other words, it computes r,g,b * (scale / 256)
///
///         THIS FUNCTION ALWAYS MODIFIES ITS ARGUMENTS IN PLACE

static inline void nscale8x3 ( unsigned char* r, unsigned char* g, unsigned char* b, fract8 scale)
{
#if (FASTLED_SCALE8_FIXED == 1)
  unsigned short scale_fixed = scale + 1;
  *r = ( ( (unsigned short) (*r)) * scale_fixed) >> 8;
  *g = ( ( (unsigned short) (*g)) * scale_fixed) >> 8;
  *b = ( ( (unsigned short) (*b)) * scale_fixed) >> 8;
#else
  *r = ( (int) (*r) * (int) (scale) ) >> 8;
  *g = ( (int) (*g) * (int) (scale) ) >> 8;
  *b = ( (int) (*b) * (int) (scale) ) >> 8;
#endif
}

/// scale three one byte values by a fourth one, which is treated as
///         the numerator of a fraction whose demominator is 256
///         In other words, it computes r,g,b * (scale / 256), ensuring
/// that non-zero values passed in remain non zero, no matter how low the scale
/// argument.
///
///         THIS FUNCTION ALWAYS MODIFIES ITS ARGUMENTS IN PLACE
static inline void nscale8x3_video ( unsigned char* r, unsigned char* g, unsigned char* b, fract8 scale)
{
  unsigned char nonzeroscale = (scale != 0) ? 1 : 0;
  *r = ((*r) == 0) ? 0 : ( ( (int) (*r) * (int) (scale) ) >> 8) + nonzeroscale;
  *g = ((*g) == 0) ? 0 : ( ( (int) (*g) * (int) (scale) ) >> 8) + nonzeroscale;
  *b = ((*b) == 0) ? 0 : ( ( (int) (*b)* (int) (scale) ) >> 8) + nonzeroscale;
}

///  scale two one byte values by a third one, which is treated as
///         the numerator of a fraction whose demominator is 256
///         In other words, it computes i,j * (scale / 256)
///
///         THIS FUNCTION ALWAYS MODIFIES ITS ARGUMENTS IN PLACE

static inline void nscale8x2 ( unsigned char* i, unsigned char* j, fract8 scale)
{
#if FASTLED_SCALE8_FIXED == 1
  unsigned short scale_fixed = scale + 1;
  *i = ( ( (unsigned short) (*i)) * scale_fixed ) >> 8;
  *j = ( ( (unsigned short) (*j)) * scale_fixed ) >> 8;
#else
  *i = ( (unsigned short) (*i) * (unsigned short) (scale) ) >> 8;
  *j = ( (unsigned short) (*j) * (unsigned short) (scale) ) >> 8;
#endif
}

///  scale two one byte values by a third one, which is treated as
///         the numerator of a fraction whose demominator is 256
///         In other words, it computes i,j * (scale / 256), ensuring
/// that non-zero values passed in remain non zero, no matter how low the scale
/// argument.
///
///         THIS FUNCTION ALWAYS MODIFIES ITS ARGUMENTS IN PLACE


static inline void nscale8x2_video ( unsigned char* i, unsigned char* j, fract8 scale)
{
  unsigned char nonzeroscale = (scale != 0) ? 1 : 0;
  *i = ((*i) == 0) ? 0 : ( ( (int) (*i) * (int) (scale) ) >> 8) + nonzeroscale;
  *j = ((*j) == 0) ? 0 : ( ( (int) (*j) * (int) (scale) ) >> 8) + nonzeroscale;
}


/// scale a 16-bit unsigned value by an 8-bit value,
///         considered as numerator of a fraction whose denominator
///         is 256. In other words, it computes i * (scale / 256)

static inline unsigned short scale16by8 ( unsigned short i, fract8 scale )
{
  unsigned short result;
#if FASTLED_SCALE8_FIXED == 1
  result = (i * (1+ ( (unsigned short) scale) ) ) >> 8;
#else
  result = (i * scale) >> 8;
#endif
  return result;
}

/// scale a 16-bit unsigned value by a 16-bit value,
///         considered as numerator of a fraction whose denominator
///         is 65536. In other words, it computes i * (scale / 65536)

static inline unsigned short scale16 ( unsigned short i, fract16 scale )
{
  unsigned short result;
#if FASTLED_SCALE8_FIXED == 1
  result = ( (unsigned int) (i) * (1+ (unsigned int) (scale) ) ) >> 16;
#else
  result = ( (unsigned int) (i) * (unsigned int) (scale) )  >> 16;
#endif
  return result;
}
///@}

///@defgroup Dimming Dimming and brightening functions
///
/// Dimming and brightening functions
///
/// The eye does not respond in a linear way to light.
/// High speed PWM'd LEDs at 50% duty cycle appear far
/// brighter then the 'half as bright' you might expect.
///
/// If you want your midpoint brightness leve (128) to
/// appear half as bright as 'full' brightness (255), you
/// have to apply a 'dimming function'.
///@{

/// Adjust a scaling value for dimming
static inline unsigned char dim8_raw ( unsigned char x)
{
  return scale8 ( x, x);
}

/// Adjust a scaling value for dimming for video (value will never go below 1)
static inline unsigned char dim8_video ( unsigned char x)
{
  return scale8_video ( x, x);
}

/// Linear version of the dimming function that halves for values < 128
static inline unsigned char dim8_lin ( unsigned char x )
{
  if ( x & 0x80 )
  {
    x = scale8 ( x, x);
  }
  else
  {
    x += 1;
    x /= 2;
  }

  return x;
}

/// inverse of the dimming function, brighten a value
static inline unsigned char brighten8_raw ( unsigned char x)
{
  unsigned char ix = 255 - x;
  return 255 - scale8 ( ix, ix);
}

/// inverse of the dimming function, brighten a value
static inline unsigned char brighten8_video ( unsigned char x)
{
  unsigned char ix = 255 - x;
  return 255 - scale8_video ( ix, ix);
}

/// inverse of the dimming function, brighten a value
static inline unsigned char brighten8_lin ( unsigned char x )
{
  unsigned char ix = 255 - x;

  if ( ix & 0x80 )
  {
    ix = scale8 ( ix, ix);
  }
  else
  {
    ix += 1;
    ix /= 2;
  }

  return 255 - ix;
}

///@}
#endif
