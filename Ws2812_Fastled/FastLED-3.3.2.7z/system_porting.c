#include "system_porting.h"
#include "device.h"
#include "led_driver.h"

//#define WIN_PORINTING

#ifdef WIN_PORINTING
#include <windows.h>

void system_sleep_ms (unsigned long ms)
{
  Sleep (ms);
}
unsigned int get_system_millisecond()
{
  return GetTickCount();
}

static HANDLE __led_mutex_handle;
static int __led_mutex_value = 0;

int LED_CreateMutexAndInit(int* value)
{
  *value = (int)CreateMutex(NULL, FALSE, NULL);
  return 0;
}

int LED_MutexLock(int value)
{
  WaitForSingleObject((HANDLE)(value), INFINITE);
  return 0;
}
int LED_MutexUnLock(int value)
{
  ReleaseMutex((HANDLE)(value));
  return 0;
}

#else

SEM_HANDLE __ledShow;

void system_sleep_ms (unsigned long ms)
{
   SystemSleep (ms);
}

static void fastledthread(PVOID pArg)
{
  FastledSetup();
  while (1)
  {
    Blinkloop();
  }
}


//static HANDLE __led_mutex_handle;
//static int __led_mutex_value = 0;
unsigned int get_system_millisecond()
{
  return GetTickRateMs();
}

int LED_CreateMutexAndInit(MUTEX_HANDLE mutex)
{
  OPERATE_RET op_ret;

  op_ret = CreateMutexAndInit (&mutex);

  if (op_ret != OPRT_OK)
  {
    return op_ret;
  }
}

int Thread_Fastled_Init(void)
{
  OPERATE_RET op_ret;
  TUYA_THREAD thread_fastled;

  op_ret = CreateAndInitSemaphore (&__ledShow, 0, 1);

  if (OPRT_OK != op_ret)
  {
    return ;
  }

  SystemSleep (10);
  
  op_ret = tuya_light_CreateAndStart (&thread_fastled, fastledthread, NULL, 1024, TRD_PRIO_2, "fastled");

  if (op_ret != OPRT_OK)
  {
    return op_ret;
  }
  
  PR_DEBUG("========== Thread_Fastled_Init ============= ");
}

void LED_MutexLock(MUTEX_HANDLE mutex)
{
  //WaitForSingleObject((HANDLE)(value), INFINITE);
  MutexLock (mutex);
}

void LED_MutexUnLock(MUTEX_HANDLE mutex)
{
  //ReleaseMutex((HANDLE)(value));
  MutexUnLock (mutex);
}

#endif


#ifdef __DEBUG_MEM__
#include <stdlib.h>
static int __total_malloc_size = 0;
void* led_user_malloc (char* func, unsigned int size)
{
  void* temp_addr = (void*) malloc (size+4);

  if (temp_addr != NULL)
  {
    __total_malloc_size+=size;
    PR_DEBUG("%s malloc %d addr=%x __total_malloc_size=%d\r\n", func, size,
                 (unsigned int) ( (unsigned char*) temp_addr+4),  __total_malloc_size);
    * ( (unsigned int*) temp_addr) = size;
    return (void*) ( (unsigned char*) temp_addr+4);
  }

  PR_DEBUG("%s malloc %d fail\r\n", func, size);
  return NULL;
}

void led_user_free (char* func, void* addr)
{
  if (addr == NULL)
  {
    PR_DEBUG("free NULL addr fail\n");
    return;
  }

  void* temp_addr = (void*) ( (unsigned char*) addr - 4);
  unsigned int size = * ( (unsigned int*) temp_addr);
  __total_malloc_size-= size;
  PR_DEBUG("%s free %d addr=%x __total_malloc_size=%d\n", func, size, (unsigned int) addr, __total_malloc_size);
  free (temp_addr);
}
#endif

#ifdef __DEBUG_MSG__
#include <stdio.h>
char __led_user_printf_buf[512];
int led_user_printf (const char* func, int line, const char* fmt, ...)
{
  #if 0
  int len;
  
  //func.
  if (func != NULL)
  {
    printf ("%s ", func);
  }

  //line.
  if (line > 0)
  {
    printf ("%d ", line);
  }

  va_list args;
  //va_list arg = (va_list)((char*)(&fmt) + 4);
  va_start (args, fmt);
  len = vsprintf (__led_user_printf_buf, fmt, args);
  va_end (args);
  __led_user_printf_buf[len] = '\0';
  printf ("%s", __led_user_printf_buf);
  printf ("\n");
  #endif
  //PR_DEBUG("Num:%d", scene_total);
  return 0;
}
#endif

