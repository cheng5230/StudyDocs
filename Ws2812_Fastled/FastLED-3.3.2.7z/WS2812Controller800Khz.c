#include "chipsets.h"
#include "system_porting.h"
#include "WS2812Controller800Khz.h"
//#include "led_driver.h"


static inline void write_byte(WS2812Controller800Khz* c_this, unsigned int offset, unsigned char byte)
{
  //PR_DEBUG(" offset:%d, byte:%02x\n",offset, byte);
  //to do, change to spi bytes.
  c_this->front_buf[offset] = byte;
  Fastled_ReadData(c_this->front_buf,offset);
}

static inline void showRGBInternal (WS2812Controller800Khz* c_this, PixelController* pixels)
{
  unsigned int offset = 0;
  // Setup the pixel controller and load/scale the first byte
  PixelController_preStepFirstByteDithering(pixels);
  register unsigned char b = PixelController_loadAndScale0(pixels);
  PixelController_preStepFirstByteDithering(pixels);
  
  PR_DEBUG(" pixels len:%d, remain:%d ", pixels->mLen, pixels->mLenRemaining);
  for(int i=0;i<pixels->mLen;++i)
  {
    //PR_DEBUG(" %02x %02x %02x",pixels->mData[i], pixels->mData[i+1], pixels->mData[i+2]);
  }
  PR_DEBUG("\n");

  while (PixelController_has(pixels, 1))
  {
    // Write first byte, read next byte
    write_byte(c_this, offset++, b);
    b = PixelController_loadAndScale1(pixels);
    // Write second byte, read 3rd byte
    write_byte(c_this, offset++, b);
    b = PixelController_loadAndScale2(pixels);
    // Write third byte, read 1st byte of next pixel
    write_byte(c_this, offset++, b);
    b = PixelController_advanceAndLoadAndScale0(pixels);
    PixelController_stepDithering(pixels);
  };
}


void WS2812Controller800Khz_showPixels(void* base, PixelController* pixels)
{
  //printf(" WS2812Controller800Khz show pixelController\n");
  // mWait.wait();
  if(is_led_busy())
    return;
  WS2812Controller800Khz* c_this = (WS2812Controller800Khz*)(base);
  LED_MutexLock(c_this->mutex_handle);
  showRGBInternal (c_this, pixels);
  c_this->is_front_buf_updated = 1;
  set_driver_busy();
  
  LED_MutexUnLock(c_this->mutex_handle);
}


/************ 线程初始化 **************/
void WS2812Controller800Khz_init(WS2812Controller800Khz* c_this, int num_led)
{
  if(c_this->front_buf == NULL)
  {
    /***** 设置显示数组长度 *****/
    c_this->front_buf_len = num_led * 3;
    //to do. malloc bytes will be conside spi bytes.
    c_this->front_buf = (unsigned char*)(LED_MALLOC(c_this->front_buf_len));
    if(c_this->front_buf == NULL)
    {
      PR_DEBUG("g_front_buf malloc %d fail\n", num_led * 3);
      return;
    }
    get_driver_len(c_this->front_buf_len);
  }
  c_this->is_front_buf_updated = 0;
  /** 创建线程并创建互斥信号量 **/
  LED_CreateMutexAndInit(&(c_this->mutex_handle));
  
  /*** 控制器初始化 ***/
  CPixelLEDController_init(&(c_this->base), WS2812Controller800Khz_showPixels, GRB);
}

unsigned short WS2812Controller800Khz_getMaxRefreshRate() 
{
  return 800;
}

