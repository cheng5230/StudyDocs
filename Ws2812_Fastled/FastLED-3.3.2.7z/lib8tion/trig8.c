#include "trig8.h"

const unsigned char b_m16_interleave[] = { 0, 49, 49, 41, 90, 27, 117, 10 };

