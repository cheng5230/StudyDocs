#ifndef __INC_COLORUTILS_H
#define __INC_COLORUTILS_H

///@file colorutils.h
/// functions for color fill, paletters, blending, and more

#include "pixeltypes.h"

///@defgroup Colorutils Color utility functions
///A variety of functions for working with color, palletes, and leds
///@{

/// fill_solid -   fill a range of LEDs with a solid color
///                Example: fill_solid( leds, NUM_LEDS, CRGB(50,0,200));
void fill_solid_rgb ( CRGB* leds, int numToFill,
                      CRGB color);

/// fill_solid -   fill a range of LEDs with a solid color
///                Example: fill_solid( leds, NUM_LEDS, CRGB(50,0,200));
void fill_solid_hsv ( CHSV* targetArray, int numToFill,
                      CHSV hsvColor);


/// fill_rainbow - fill a range of LEDs with a rainbow of colors, at
///                full saturation and full value (brightness)
//default deltahue = 5, *************default value**************************
void fill_rainbow_rgb ( CRGB* pFirstLED, int numToFill,
                        unsigned char initialhue,
                        unsigned char deltahue);

/// fill_rainbow - fill a range of LEDs with a rainbow of colors, at
///                full saturation and full value (brightness)
//default deltahue = 5, *************default value**************************
void fill_rainbow_hsv ( CHSV* targetArray, int numToFill,
                        unsigned char initialhue,
                        unsigned char deltahue);


// fill_gradient - fill an array of colors with a smooth HSV gradient
//                 between two specified HSV colors.
//                 Since 'hue' is a value around a color wheel,
//                 there are always two ways to sweep from one hue
//                 to another.
//                 This function lets you specify which way you want
//                 the hue gradient to sweep around the color wheel:
//                   FORWARD_HUES: hue always goes clockwise
//                   BACKWARD_HUES: hue always goes counter-clockwise
//                   SHORTEST_HUES: hue goes whichever way is shortest
//                   LONGEST_HUES: hue goes whichever way is longest
//                 The default is SHORTEST_HUES, as this is nearly
//                 always what is wanted.
//
// fill_gradient can write the gradient colors EITHER
//     (1) into an array of CRGBs (e.g., into leds[] array, or an RGB Palette)
//   OR
//     (2) into an array of CHSVs (e.g. an HSV Palette).
//
//   In the case of writing into a CRGB array, the gradient is
//   computed in HSV space, and then HSV values are converted to RGB
//   as they're written into the RGB array.

typedef enum { FORWARD_HUES, BACKWARD_HUES, SHORTEST_HUES, LONGEST_HUES } TGradientDirectionCode;

/// fill_gradient_rgb_hsv - fill an array of colors with a smooth HSV gradient
/// between two specified HSV colors.
/// Since 'hue' is a value around a color wheel,
/// there are always two ways to sweep from one hue
/// to another.
/// This function lets you specify which way you want
/// the hue gradient to sweep around the color wheel:
///
///     FORWARD_HUES: hue always goes clockwise
///     BACKWARD_HUES: hue always goes counter-clockwise
///     SHORTEST_HUES: hue goes whichever way is shortest
///     LONGEST_HUES: hue goes whichever way is longest
///
/// The default is SHORTEST_HUES, as this is nearly
/// always what is wanted.
///
/// fill_gradient_rgb_hsv can write the gradient colors EITHER
///     (1) into an array of CRGBs (e.g., into leds[] array, or an RGB Palette)
///   OR
///     (2) into an array of CHSVs (e.g. an HSV Palette).
///
///   In the case of writing into a CRGB array, the gradient is
///   computed in HSV space, and then HSV values are converted to RGB
///   as they're written into the RGB array.
//default directionCode  = SHORTEST_HUES, *************default value**************************
void fill_gradient_rgb_hsv ( void* targetArray,
                             unsigned short startpos, CHSV startcolor,
                             unsigned short endpos,   CHSV endcolor,
                             TGradientDirectionCode directionCode, char is_rgb_array );
// Convenience functions to fill an array of colors with a
// two-color, three-color, or four-color gradient
//default directionCode  = SHORTEST_HUES, *************default value**************************
void fill_gradient_rgb_hsv_c1c2 ( void* targetArray, unsigned short numLeds, CHSV c1, CHSV c2,
                                  TGradientDirectionCode directionCode, char is_rgb_array);

//default directionCode  = SHORTEST_HUES, *************default value**************************
void fill_gradient_rgb_hsv_c1c2c3 ( void* targetArray, unsigned short numLeds,
                                    CHSV c1, CHSV c2, CHSV c3,
                                    TGradientDirectionCode directionCode, char is_rgb_array);

//default directionCode  = SHORTEST_HUES, *************default value**************************
void fill_gradient_rgb_hsv_c1c2c3c4 ( void* targetArray, unsigned short numLeds,
                                      CHSV c1, CHSV c2, CHSV c3, CHSV c4,
                                      TGradientDirectionCode directionCode, char is_rgb_array);

// fill_gradient_RGB - fill a range of LEDs with a smooth RGB gradient
//                     between two specified RGB colors.
//                     Unlike HSV, there is no 'color wheel' in RGB space,
//                     and therefore there's only one 'direction' for the
//                     gradient to go, and no 'direction code' is needed.
void fill_gradient_RGB ( CRGB* leds,
                         unsigned short startpos, CRGB startcolor,
                         unsigned short endpos,   CRGB endcolor );
void fill_gradient_RGB_c1c2 ( CRGB* leds, unsigned short numLeds, CRGB c1, CRGB c2);
void fill_gradient_RGB_c1c2c3 ( CRGB* leds, unsigned short numLeds, CRGB c1, CRGB c2, CRGB c3);
void fill_gradient_RGB_c1c2c3c4 ( CRGB* leds, unsigned short numLeds, CRGB c1, CRGB c2, CRGB c3,
                                  CRGB c4);


// fadeLightBy and fade_video - reduce the brightness of an array
//                              of pixels all at once.  Guaranteed
//                              to never fade all the way to black.
//                              (The two names are synonyms.)
void fadeLightBy (   CRGB* leds, unsigned short num_leds, unsigned char fadeBy);
void fade_video (    CRGB* leds, unsigned short num_leds, unsigned char fadeBy);

// nscale8_video - scale down the brightness of an array of pixels
//                 all at once.  Guaranteed to never scale a pixel
//                 all the way down to black, unless 'scale' is zero.
void nscale8_video ( CRGB* leds, unsigned short num_leds, unsigned char scale);

// fadeToBlackBy and fade_raw - reduce the brightness of an array
//                              of pixels all at once.  These
//                              functions will eventually fade all
//                              the way to black.
//                              (The two names are synonyms.)
void fadeToBlackBy ( CRGB* leds, unsigned short num_leds, unsigned char fadeBy);
void fade_raw (      CRGB* leds, unsigned short num_leds, unsigned char fadeBy);

// nscale8 - scale down the brightness of an array of pixels
//           all at once.  This function can scale pixels all the
//           way down to black even if 'scale' is not zero.
void nscale8 (       CRGB* leds, unsigned short num_leds, unsigned char scale);

// fadeUsingColor - scale down the brightness of an array of pixels,
//                  as though it were seen through a transparent
//                  filter with the specified color.
//                  For example, if the colormask is
//                    CRGB( 200, 100, 50)
//                  then the pixels' red will be faded to 200/256ths,
//                  their green to 100/256ths, and their blue to 50/256ths.
//                  This particular example give a 'hot fade' look,
//                  with white fading to yellow, then red, then black.
//                  You can also use colormasks like CRGB::Blue to
//                  zero out the red and green elements, leaving blue
//                  (largely) the same.
void fadeUsingColor ( CRGB* leds, unsigned short numLeds, CRGB colormask);


// Pixel blending
//
// blend - computes a new color blended some fraction of the way
//         between two other colors.
CRGB  blend ( CRGB p1, CRGB p2, fract8 amountOfP2 );
//default directionCode  = SHORTEST_HUES, *************default value**************************
CHSV  blend_dir ( CHSV p1, CHSV p2, fract8 amountOfP2,
                  TGradientDirectionCode directionCode );

// blend - computes a new color blended array of colors, each
//         a given fraction of the way between corresponding
//         elements of two source arrays of colors.
//         Useful for blending palettes.
CRGB* blend_count ( const CRGB* src1, const CRGB* src2, CRGB* dest,
                    unsigned short count, fract8 amountOfsrc2 );

//default directionCode  = SHORTEST_HUES, *************default value**************************
CHSV* blend_count_dir ( const CHSV* src1, const CHSV* src2, CHSV* dest,
                        unsigned short count, fract8 amountOfsrc2,
                        TGradientDirectionCode directionCode );

// nblend - destructively modifies one color, blending
//          in a given fraction of an overlay color
CRGB nblend ( CRGB existing, CRGB overlay, fract8 amountOfOverlay );

//default directionCode  = SHORTEST_HUES, *************default value**************************
CHSV nblend_dir ( CHSV existing, CHSV overlay, fract8 amountOfOverlay,
                   TGradientDirectionCode directionCode );

// nblend - destructively blends a given fraction of
//          a new color array into an existing color array
void  nblend_count ( CRGB* existing, CRGB* overlay, unsigned short count, fract8 amountOfOverlay);
//default directionCode  = SHORTEST_HUES, *************default value**************************
void  nblend_count_dir ( CHSV* existing, CHSV* overlay, unsigned short count, fract8 amountOfOverlay,
                         TGradientDirectionCode directionCode);

unsigned short XY(unsigned char matrix_width, unsigned char x, unsigned char y);

// blur1d: one-dimensional blur filter. Spreads light to 2 line neighbors.
// blur2d: two-dimensional blur filter. Spreads light to 8 XY neighbors.
//
//           0 = no spread at all
//          64 = moderate spreading
//         172 = maximum smooth, even spreading
//
//         173..255 = wider spreading, but increasing flicker
//
//         Total light is NOT entirely conserved, so many repeated
//         calls to 'blur' will also result in the light fading,
//         eventually all the way to black; this is by design so that
//         it can be used to (slowly) clear the LEDs to black.
void blur1d ( CRGB* leds, unsigned short numLeds, fract8 blur_amount);
void blur2d ( CRGB* leds, unsigned char width, unsigned char height, fract8 blur_amount);

// blurRows: perform a blur1d on every row of a rectangular matrix
void blurRows ( CRGB* leds, unsigned char width, unsigned char height, fract8 blur_amount);
// blurColumns: perform a blur1d on each column of a rectangular matrix
void blurColumns (CRGB* leds, unsigned char width, unsigned char height, fract8 blur_amount);


// CRGB HeatColor( unsigned char temperature)
//
// Approximates a 'black body radiation' spectrum for
// a given 'heat' level.  This is useful for animations of 'fire'.
// Heat is specified as an arbitrary scale from 0 (cool) to 255 (hot).
// This is NOT a chromatically correct 'black body radiation'
// spectrum, but it's surprisingly close, and it's fast and small.
CRGB HeatColor ( unsigned char temperature);


// Palettes
//
// RGB Palettes map an 8-bit value (0..255) to an RGB color.
//
// You can create any color palette you wish; a couple of starters
// are provided: Forest, Clouds, Lava, Ocean, Rainbow, and Rainbow Stripes.
//
// Palettes come in the traditional 256-entry variety, which take
// up 768 bytes of RAM, and lightweight 16-entry varieties.  The 16-entry
// variety automatically interpolates between its entries to produce
// a full 256-element color map, but at a cost of only 48 bytes or RAM.
//
// Basic operation is like this: (example shows the 16-entry variety)
// 1. Declare your palette storage:
//    CRGBPalette16 myPalette;
//
// 2. Fill myPalette with your own 16 colors, or with a preset color scheme.
//    You can specify your 16 colors a variety of ways:
//      CRGBPalette16 myPalette(
//          CRGB::Black,
//          CRGB::Black,
//          CRGB::Red,
//          CRGB::Yellow,
//          CRGB::Green,
//          CRGB::Blue,
//          CRGB::Purple,
//          CRGB::Black,
//
//          0x100000,
//          0x200000,
//          0x400000,
//          0x800000,
//
//          CHSV( 30,255,255),
//          CHSV( 50,255,255),
//          CHSV( 70,255,255),
//          CHSV( 90,255,255)
//      );
//
//    Or you can initiaize your palette with a preset color scheme:
//      myPalette = RainbowStripesColors_p;
//
// 3. Any time you want to set a pixel to a color from your palette, use
//    "ColorFromPalette(...)" as shown:
//
//      unsigned char index = /* any value 0..255 */;
//      leds[i] = ColorFromPalette( myPalette, index);
//
//    Even though your palette has only 16 explicily defined entries, you
//    can use an 'index' from 0..255.  The 16 explicit palette entries will
//    be spread evenly across the 0..255 range, and the intermedate values
//    will be RGB-interpolated between adjacent explicit entries.
//
//    It's easier to use than it sounds.
//

typedef unsigned int TProgmemRGBPalette16[16];
typedef unsigned int TProgmemHSVPalette16[16];
#define TProgmemPalette16 TProgmemRGBPalette16
typedef unsigned int TProgmemRGBPalette32[32];
typedef unsigned int TProgmemHSVPalette32[32];
#define TProgmemPalette32 TProgmemRGBPalette32

typedef unsigned char TProgmemRGBGradientPalette_byte ;
typedef TProgmemRGBGradientPalette_byte* TProgmemRGBGradientPalette_bytes;
typedef TProgmemRGBGradientPalette_bytes TProgmemRGBGradientPalettePtr;
typedef union
{
  struct
  {
    unsigned char index;
    unsigned char r;
    unsigned char g;
    unsigned char b;
  };
  unsigned int dword;
  unsigned char  bytes[4];
} TRGBGradientPaletteEntryUnion;

typedef unsigned char TDynamicRGBGradientPalette_byte ;
typedef const TDynamicRGBGradientPalette_byte* TDynamicRGBGradientPalette_bytes;
typedef TDynamicRGBGradientPalette_bytes TDynamicRGBGradientPalettePtr;

typedef struct
{
  CHSV entries[16];
} CHSVPalette16;

typedef struct
{
  CHSV entries[32];
} CHSVPalette32;

typedef struct
{
  CHSV entries[256];
} CHSVPalette256;

typedef struct
{
  CRGB entries[16];
} CRGBPalette16;

typedef struct
{
  CRGB entries[32];
} CRGBPalette32;

typedef struct
{
  CRGB entries[256];
} CRGBPalette256;

// Convert a 16-entry palette to a 256-entry palette
void UpscalePalette_16to256_rgb (CRGBPalette16 srcpal16, CRGBPalette256* destpal256);
void UpscalePalette_16to256_hsv (CHSVPalette16 srcpal16, CHSVPalette256* destpal256);

// Convert a 16-entry palette to a 32-entry palette
void UpscalePalette_16to32_rgb (CRGBPalette16 srcpal16, CRGBPalette32* destpal32);
void UpscalePalette_16to32_hsv (CHSVPalette16 srcpal16, CHSVPalette32* destpal32);

// Convert a 32-entry palette to a 256-entry palette
void UpscalePalette_32to256_rgb (CRGBPalette32 srcpal32, CRGBPalette256* destpal256);
void UpscalePalette_32to256_hsv (CHSVPalette32 srcpal32, CHSVPalette256* destpal256);

#define FL_PGM_READ_DWORD_NEAR(x) (*((const unsigned int*)(x)))

void CHSVPalette16_init_by_c16 ( CHSVPalette16* c_this, CHSV c00, CHSV c01, CHSV c02, CHSV c03,
                                 CHSV c04, CHSV c05, CHSV c06, CHSV c07,
                                 CHSV c08, CHSV c09, CHSV c10, CHSV c11,
                                 CHSV c12, CHSV c13, CHSV c14, CHSV c15 );

void CHSVPalette16_init_by_self_type (CHSVPalette16* c_this, CHSVPalette16 rhs);

void CHSVPalette16_init_by_programedHSVPalette16 (CHSVPalette16* c_this, TProgmemHSVPalette16 rhs);

void CHSVPalette16_init_by_c1 (CHSVPalette16* c_this, CHSV c1);
void CHSVPalette16_init_by_c1c2 (CHSVPalette16* c_this, CHSV c1, CHSV c2);
void CHSVPalette16_init_by_c1c2c3 (CHSVPalette16* c_this, CHSV c1, CHSV c2, CHSV c3);
void CHSVPalette16_init_by_c1c2c3c4 (CHSVPalette16* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4);

inline CHSV CHSVPalette16_get_hsv (CHSVPalette16* c_this, unsigned char x)
{
  return c_this->entries[x];
}

inline CHSV* CHSVPalette16_get_entries (CHSVPalette16* c_this)
{
  return & (c_this->entries[0]);
}

int CHSVPalette16_is_equal (CHSVPalette16* c_this, CHSVPalette16 rhs);

void CHSVPalette256_init_by_hsvPalette16 (CHSVPalette256* c_this,  CHSVPalette16 rhs16);


void CHSVPalette256_init_by_c16 (CHSVPalette256* c_this, CHSV c00, CHSV c01, CHSV c02, CHSV c03,
                                 CHSV c04, CHSV c05, CHSV c06, CHSV c07,
                                 CHSV c08, CHSV c09, CHSV c10, CHSV c11,
                                 CHSV c12, CHSV c13, CHSV c14, CHSV c15 );

void CHSVPalette256_init_by_self_type (CHSVPalette256* c_this, CHSVPalette256 rhs);

void CHSVPalette256_init_by_programHSVPalette16 (CHSVPalette256* c_this, TProgmemHSVPalette16 rhs);

void CHSVPalette256_init_by_c1 (CHSVPalette256* c_this, CHSV c1);
void CHSVPalette256_init_by_c1c2 (CHSVPalette256* c_this, CHSV c1, CHSV c2);
void CHSVPalette256_init_by_c1c2c3 (CHSVPalette256* c_this, CHSV c1, CHSV c2, CHSV c3);
void CHSVPalette256_init_by_c1c2c3c4 (CHSVPalette256* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4);

inline CHSV CHSVPalette256_get_hsv (CHSVPalette256* c_this, unsigned char x)
{
  return c_this->entries[x];
}

inline CHSV* CHSVPalette256_get_entries (CHSVPalette256* c_this)
{
  return & (c_this->entries[0]);
}

int CHSVPalette256_is_equal (CHSVPalette256* c_this, CHSVPalette256 rhs);

void CRGBPalette16_init_by_c16 ( CRGBPalette16* c_this, CRGB c00, CRGB c01, CRGB c02, CRGB c03,
                                 CRGB c04, CRGB c05, CRGB c06, CRGB c07,
                                 CRGB c08, CRGB c09, CRGB c10, CRGB c11,
                                 CRGB c12, CRGB c13, CRGB c14, CRGB c15 );

void CRGBPalette16_init_by_self_type ( CRGBPalette16* c_this, const CRGBPalette16 rhs);

void CRGBPalette16_init_by_rgb ( CRGBPalette16* c_this, CRGB rhs[16]);

void CRGBPalette16_init_by_hsvPalette16 (CRGBPalette16* c_this,                  CHSVPalette16 rhs);

void CRGBPalette16_init_by_hsv (CRGBPalette16* c_this, CHSV rhs[16]);

void CRGBPalette16_init_by_programRGBPalette16 (CRGBPalette16* c_this, TProgmemRGBPalette16 rhs);

void CRGBPalette16_init_by_hsv_c1 (CRGBPalette16* c_this, CHSV c1);

void CRGBPalette16_init_by_hsv_c1c2 (CRGBPalette16* c_this, CHSV c1, CHSV c2);

void CRGBPalette16_init_by_hsv_c1c2c3 (CRGBPalette16* c_this, CHSV c1, CHSV c2, CHSV c3);

void CRGBPalette16_init_by_hsv_c1c2c3c4 (CRGBPalette16* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4);
void CRGBPalette16_init_by_rgb_c1 (CRGBPalette16* c_this, CRGB c1);
void CRGBPalette16_init_by_rgb_c1c2 (CRGBPalette16* c_this, CRGB c1, CRGB c2);

void CRGBPalette16_init_by_rgb_c1c2c3 (CRGBPalette16* c_this, CRGB c1, CRGB c2, CRGB c3);

void CRGBPalette16_init_by_rgb_c1c2c3c4 (CRGBPalette16* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4);

// Gradient palettes are loaded into CRGB16Palettes in such a way
// that, if possible, every color represented in the gradient palette
// is also represented in the CRGBPalette16.
// For example, consider a gradient palette that is all black except
// for a single, one-element-wide (1/256th!) spike of red in the middle:
//     0,   0,0,0
//   124,   0,0,0
//   125, 255,0,0  // one 1/256th-palette-wide red stripe
//   126,   0,0,0
//   255,   0,0,0
// A naive conversion of this 256-element palette to a 16-element palette
// might accidentally completely eliminate the red spike, rendering the
// palette completely black.
// However, the conversions provided here would attempt to include a
// the red stripe in the output, more-or-less as faithfully as possible.
// So in this case, the resulting CRGBPalette16 palette would have a red
// stripe in the middle which was 1/16th of a palette wide -- the
// narrowest possible in a CRGBPalette16.
// This means that the relative width of stripes in a CRGBPalette16
// will be, by definition, different from the widths in the gradient
// palette.  This code attempts to preserve "all the colors", rather than
// the exact stripe widths at the expense of dropping some colors.
void CRGBPalette16_init_by_RGB_Gradient_bytes (CRGBPalette16* c_this, TProgmemRGBGradientPalette_bytes progpal );
int CRGBPalette16_is_equal (CRGBPalette16* c_this, CRGBPalette16 rhs);

inline CRGB CRGBPalette16_get_rgb (CRGBPalette16* c_this, unsigned char x)
{
  return c_this->entries[x];
}

inline CRGB* CRGBPalette16_get_entries (CRGBPalette16* c_this)
{
  return & (c_this->entries[0]);
}

void CHSVPalette32_init_by_c16 ( CHSVPalette32* c_this, CHSV c00, CHSV c01, CHSV c02, CHSV c03,
                                 CHSV c04, CHSV c05, CHSV c06, CHSV c07,
                                 CHSV c08, CHSV c09, CHSV c10, CHSV c11,
                                 CHSV c12, CHSV c13, CHSV c14, CHSV c15 );

void CHSVPalette32_init_by_self_type ( CHSVPalette32* c_this, CHSVPalette32 rhs);

void CHSVPalette32_init_by_programHSVPalette32 (CHSVPalette32* c_this, TProgmemHSVPalette32 rhs);

inline CHSV CHSVPalette32_get_hsv (CHSVPalette32* c_this, unsigned char x)
{
  return c_this->entries[x];
}

inline CHSV* CHSVPalette32_get_entries (CHSVPalette32* c_this)
{
  return & (c_this->entries[0]);
}

int CHSVPalette32_is_equal (CHSVPalette32* c_this, CHSVPalette32 rhs);

void CHSVPalette32_init_by_c1 (CHSVPalette32* c_this, CHSV c1);

void CHSVPalette32_init_by_c1c2 (CHSVPalette32* c_this, CHSV c1, CHSV c2);
void CHSVPalette32_init_by_c1c2c3 (CHSVPalette32* c_this, CHSV c1, CHSV c2, CHSV c3);

void CHSVPalette32_init_by_c1c2c3c4 (CHSVPalette32* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4);

void CRGBPalette32_init_by_c16 (CRGBPalette32* c_this, CRGB c00, CRGB c01, CRGB c02, CRGB c03,
                                CRGB c04, CRGB c05, CRGB c06, CRGB c07,
                                CRGB c08, CRGB c09, CRGB c10, CRGB c11,
                                CRGB c12, CRGB c13, CRGB c14, CRGB c15 );

void CRGBPalette32_init_by_self_type (CRGBPalette32* c_this, CRGBPalette32 rhs);

void CRGBPalette32_init_by_rgb (CRGBPalette32* c_this, CRGB rhs[32]);

void CRGBPalette32_init_by_hsvPalette (CRGBPalette32* c_this, CHSVPalette32 rhs);

void CRGBPalette32_init_by_hsv (CRGBPalette32* c_this, CHSV rhs[32]);

void CRGBPalette32_init_by_programRGBPalette32 (CRGBPalette32* c_this, TProgmemRGBPalette32 rhs);

void CRGBPalette32_init_by_hsv_c1 (CRGBPalette32* c_this, CHSV c1);

void CRGBPalette32_init_by_hsv_c1c2 (CRGBPalette32* c_this, CHSV c1, CHSV c2);
void CRGBPalette32_init_by_hsv_c1c2c3 (CRGBPalette32* c_this, CHSV c1, CHSV c2, CHSV c3);
void CRGBPalette32_init_by_hsv_c1c2c3c4 (CRGBPalette32* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4);

void CRGBPalette32_init_by_rgb_c1 (CRGBPalette32* c_this, CRGB c1);
void CRGBPalette32_init_by_rgb_c1c2 (CRGBPalette32* c_this, CRGB c1, CRGB c2);
void CRGBPalette32_init_by_rgb_c1c2c3 (CRGBPalette32* c_this, CRGB c1, CRGB c2, CRGB c3);
void CRGBPalette32_init_by_rgb_c1c2c3c4 (CRGBPalette32* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4);
void CRGBPalette32_init_by_rgbPalette (CRGBPalette32* c_this, CRGBPalette16 rhs16);
void CRGBPalette32_init_by_programRGBPalette16 (CRGBPalette32* c_this, TProgmemRGBPalette16 rhs);

int CRGBPalette32_is_equal (CRGBPalette32* c_this, CRGBPalette32 rhs);

inline CRGB CRGBPalette32_get_RGB (CRGBPalette32* c_this, unsigned char x)
{
  return c_this->entries[x];
}
inline CRGB* CRGBPalette32_get_entries (CRGBPalette32* c_this)
{
  return & (c_this->entries[0]);
}

// Gradient palettes are loaded into CRGB16Palettes in such a way
// that, if possible, every color represented in the gradient palette
// is also represented in the CRGBPalette32.
// For example, consider a gradient palette that is all black except
// for a single, one-element-wide (1/256th!) spike of red in the middle:
//     0,   0,0,0
//   124,   0,0,0
//   125, 255,0,0  // one 1/256th-palette-wide red stripe
//   126,   0,0,0
//   255,   0,0,0
// A naive conversion of this 256-element palette to a 16-element palette
// might accidentally completely eliminate the red spike, rendering the
// palette completely black.
// However, the conversions provided here would attempt to include a
// the red stripe in the output, more-or-less as faithfully as possible.
// So in this case, the resulting CRGBPalette32 palette would have a red
// stripe in the middle which was 1/16th of a palette wide -- the
// narrowest possible in a CRGBPalette32.
// This means that the relative width of stripes in a CRGBPalette32
// will be, by definition, different from the widths in the gradient
// palette.  This code attempts to preserve "all the colors", rather than
// the exact stripe widths at the expense of dropping some colors.
void CRGBPalette32_init_by_programRGBGradientPalette (CRGBPalette32* c_this, TProgmemRGBGradientPalette_bytes progpal);

void CRGBPalette256_init_by_c16 (CRGBPalette256* c_this, CRGB c00, CRGB c01, CRGB c02, CRGB c03,
                                 CRGB c04, CRGB c05, CRGB c06, CRGB c07,
                                 CRGB c08, CRGB c09, CRGB c10, CRGB c11,
                                 CRGB c12, CRGB c13, CRGB c14, CRGB c15 );
void CRGBPalette256_init_by_self_type (CRGBPalette256* c_this, CRGBPalette256 rhs);

void CRGBPalette256_init_by_rgb (CRGBPalette256* c_this, CRGB rhs[256]);

void CRGBPalette256_init_by_HSVPalette256 (CRGBPalette256* c_this,                   CHSVPalette256 rhs);

void CRGBPalette256_init_by_hsv (CRGBPalette256* c_this, CHSV rhs[256]);
void CRGBPalette256_init_by_RGBPalette16 (CRGBPalette256* c_this, CRGBPalette16 rhs16);

void CRGBPalette256_init_by_ProgramRGBPalette16 (CRGBPalette256* c_this, TProgmemRGBPalette16 rhs);

int CRGBPalette256_is_equal (CRGBPalette256* c_this, CRGBPalette256 rhs);

inline CRGB CRGBPalette256_get_rgb (CRGBPalette256* c_this, unsigned char x)
{
  return c_this->entries[x];
}

inline CRGB* CRGBPalette256_get_entries (CRGBPalette256* c_this)
{
  return & (c_this->entries[0]);
}

void CRGBPalette256_init_by_hsv_c1 (CRGBPalette256* c_this, CHSV c1);

void CRGBPalette256_init_by_hsv_c1c2 (CRGBPalette256* c_this, CHSV c1, CHSV c2);
void CRGBPalette256_init_by_hsv_c1c2c3 (CRGBPalette256* c_this, CHSV c1, CHSV c2, CHSV c3);

void CRGBPalette256_init_by_hsv_c1c2c3c4 (CRGBPalette256* c_this, CHSV c1, CHSV c2, CHSV c3, CHSV c4);
void CRGBPalette256_init_by_rgb_c1 (CRGBPalette256* c_this, CRGB c1);

void CRGBPalette256_init_by_rgb_c1c2 (CRGBPalette256* c_this, CRGB c1, CRGB c2);
void CRGBPalette256_init_by_rgb_c1c2c3 (CRGBPalette256* c_this, CRGB c1, CRGB c2, CRGB c3);
void CRGBPalette256_init_by_rgb_c1c2c3c4 (CRGBPalette256* c_this, CRGB c1, CRGB c2, CRGB c3, CRGB c4);
void CRGBPalette256_init_by_programRGBGradientPalette (CRGBPalette256* c_this, TProgmemRGBGradientPalette_bytes progpal );

typedef enum { NOBLEND=0, LINEARBLEND=1 } TBlendType;
//default brightness=255, blendType=LINEARBLEND, *************default value**************************
CRGB RGBColorFromRGBPalette16 ( CRGBPalette16 pal,
                                unsigned char index,
                                unsigned char brightness,
                                TBlendType blendType);
//default brightness=255, blendType=LINEARBLEND, *************default value**************************
CRGB RGBColorFromProgmemRGBPalette16 (TProgmemRGBPalette16 pal,
                                       unsigned char index,
                                       unsigned char brightness,
                                       TBlendType blendType);
//default brightness=255, blendType=NOBLEND, *************default value**************************
CRGB RGBColorFromRGBPalette256(  CRGBPalette256 pal,
                        unsigned char index,
                        unsigned char brightness,
                        TBlendType blendType );

//default brightness=255, blendType=LINEARBLEND, *************default value**************************
CHSV HSVColorFromHSVPalette16 (CHSVPalette16 pal,
                                unsigned char index,
                                unsigned char brightness,
                                TBlendType blendType);
//default brightness=255, blendType=NOBLEND, *************default value**************************
CHSV HSVColorFromHSVPalette256(CHSVPalette256 pal,
                        unsigned char index,
                        unsigned char brightness,
                        TBlendType blendType );
//default brightness=255, blendType=LINEARBLEND, *************default value**************************
CRGB RGBColorFromRGBPalette32(CRGBPalette32 pal,
                        unsigned char index,
                        unsigned char brightness,
                        TBlendType blendType);
//default brightness=255, blendType=LINEARBLEND, *************default value**************************
CRGB RGBColorFromProgramRGBPalette32(TProgmemRGBPalette32 pal,
                        unsigned char index,
                        unsigned char brightness,
                        TBlendType blendType);
//default brightness=255, blendType=LINEARBLEND, *************default value**************************
CHSV HSVColorFromHSVPalette32(CHSVPalette32 pal,
                                unsigned char index,
                                unsigned char brightness,
                                TBlendType blendType);

                                   
void fill_palette_CRGBPalette16(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                      CRGBPalette16 pal, unsigned char brightness, TBlendType blendType);

void fill_palette_ProgmemRGBPalette16(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                          TProgmemRGBPalette16 pal, unsigned char brightness, TBlendType blendType);
                                    
void fill_palette_CRGBPalette256(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                      CRGBPalette256 pal, unsigned char brightness, TBlendType blendType);
                                                                                          
void fill_palette_CRGBPalette32(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                        CRGBPalette32 pal, unsigned char brightness, TBlendType blendType);

void fill_palette_ProgmemRGBPalette32(CRGB* L, unsigned short N, unsigned char startIndex, unsigned char incIndex,
                                                          TProgmemRGBPalette32 pal, unsigned char brightness, TBlendType blendType);
//default brightness=255, unsigned char opacity=255, TBlendType blendType = LINEARBLEND *************default value**************************
void map_data_into_colors_through_CRGBPalette16 (unsigned char* dataArray, unsigned short dataCount,
                                                              CRGB* targetColorArray, CRGBPalette16 pal,
                                                              unsigned char brightness, unsigned char opacity,
                                                              TBlendType blendType);
//default brightness=255, unsigned char opacity=255, TBlendType blendType = LINEARBLEND *************default value**************************
void map_data_into_colors_through_ProgmemRGBPalette16 (unsigned char* dataArray, unsigned short dataCount,
                                                                  CRGB* targetColorArray, TProgmemRGBPalette16 pal,
                                                                  unsigned char brightness, unsigned char opacity,
                                                                  TBlendType blendType);
//default brightness=255, unsigned char opacity=255, TBlendType blendType = LINEARBLEND *************default value**************************
void map_data_into_colors_through_CRGBPalette256(unsigned char* dataArray, unsigned short dataCount,
                                                                CRGB* targetColorArray, CRGBPalette256 pal,
                                                                unsigned char brightness, unsigned char opacity,
                                                                TBlendType blendType);
//default brightness=255, unsigned char opacity=255, TBlendType blendType = LINEARBLEND *************default value**************************
void map_data_into_colors_through_CRGBPalette32(unsigned char* dataArray, unsigned short dataCount,
                                                                CRGB* targetColorArray, CRGBPalette32 pal,
                                                                unsigned char brightness, unsigned char opacity,
                                                                TBlendType blendType);
//default brightness=255, unsigned char opacity=255, TBlendType blendType = LINEARBLEND *************default value**************************
void map_data_into_colors_through_ProgmemRGBPalette32(unsigned char* dataArray, unsigned short dataCount,
                                                                CRGB* targetColorArray, TProgmemRGBPalette32 pal,
                                                                unsigned char brightness, unsigned char opacity,
                                                                TBlendType blendType);
// nblendPaletteTowardPalette:
//               Alter one palette by making it slightly more like
//               a 'target palette', used for palette cross-fades.
//
//               It does this by comparing each of the R, G, and B channels
//               of each entry in the current palette to the corresponding
//               entry in the target palette and making small adjustments:
//                 If the Red channel is too low, it will be increased.
//                 If the Red channel is too high, it will be slightly reduced.
//                 ... and likewise for Green and Blue channels.
//
//               Additionally, there are two significant visual improvements
//               to this algorithm implemented here.  First is this:
//                 When increasing a channel, it is stepped up by ONE.
//                 When decreasing a channel, it is stepped down by TWO.
//               Due to the way the eye perceives light, and the way colors
//               are represented in RGB, this produces a more uniform apparent
//               brightness when cross-fading between most palette colors.
//
//               The second visual tweak is limiting the number of changes
//               that will be made to the palette at once.  If all the palette
//               entries are changed at once, it can give a muddled appearance.
//               However, if only a few palette entries are changed at once,
//               you get a visually smoother transition: in the middle of the
//               cross-fade your current palette will actually contain some
//               colors from the old palette, a few blended colors, and some
//               colors from the new palette.
//               The maximum number of possible palette changes per call
//               is 48 (sixteen color entries time three channels each).
//               The default 'maximim number of changes' here is 12, meaning
//               that only approximately a quarter of the palette entries
//               will be changed per call.
//default maxChanges=24 *************default value**************************
void nblendPaletteTowardPalette ( CRGBPalette16 currentPalette,
                                  CRGBPalette16 targetPalette,
                                  unsigned char maxChanges);




//  You can also define a static RGB palette very compactly in terms of a series
//  of connected color gradients.
//  For example, if you want the first 3/4ths of the palette to be a slow
//  gradient ramping from black to red, and then the remaining 1/4 of the
//  palette to be a quicker ramp to white, you specify just three points: the
//  starting black point (at index 0), the red midpoint (at index 192),
//  and the final white point (at index 255).  It looks like this:
//
//    index:  0                                    192          255
//            |----------r-r-r-rrrrrrrrRrRrRrRrRRRR-|-RRWRWWRWWW-|
//    color: (0,0,0)                           (255,0,0)    (255,255,255)
//
//  Here's how you'd define that gradient palette:
//
//    DEFINE_GRADIENT_PALETTE( black_to_red_to_white_p ) {
//          0,      0,  0,  0,    /* at index 0, black(0,0,0) */
//        192,    255,  0,  0,    /* at index 192, red(255,0,0) */
//        255,    255,255,255    /* at index 255, white(255,255,255) */
//    };
//
//  This format is designed for compact storage.  The example palette here
//  takes up just 12 bytes of PROGMEM (flash) storage, and zero bytes
//  of SRAM when not currently in use.
//
//  To use one of these gradient palettes, simply assign it into a
//  CRGBPalette16 or a CRGBPalette256, like this:
//
//    CRGBPalette16 pal = black_to_red_to_white_p;
//
//  When the assignment is made, the gradients are expanded out into
//  either 16 or 256 palette entries, depending on the kind of palette
//  object they're assigned to.
//
//  IMPORTANT NOTES & CAVEATS:
//
//  - The last 'index' position MUST BE 255!  Failure to end with
//    index 255 will result in program hangs or crashes.
//
//  - At this point, these gradient palette definitions MUST BE
//    stored in PROGMEM on AVR-based Arduinos.  If you use the
//    DEFINE_GRADIENT_PALETTE macro, this is taken care of automatically.
//

#define DEFINE_GRADIENT_PALETTE(X) \
  extern const TProgmemRGBGradientPalette_byte X[] =

#define DECLARE_GRADIENT_PALETTE(X) \
  extern const TProgmemRGBGradientPalette_byte X[]


// Functions to apply gamma adjustments, either:
// - a single gamma adjustment to a single scalar value,
// - a single gamma adjustment to each channel of a CRGB color, or
// - different gamma adjustments for each channel of a CRFB color.
//
// Note that the gamma is specified as a traditional floating point value
// e.g., "2.5", and as such these functions should not be called in
// your innermost pixel loops, or in animations that are extremely
// low on program storage space.  Nevertheless, if you need these
// functions, here they are.
//
// Furthermore, bear in mind that CRGB leds have only eight bits
// per channel of color resolution, and that very small, subtle shadings
// may not be visible.
unsigned char applyGamma_video_bright_gamma ( unsigned char brightness, float gamma);
CRGB    applyGamma_video_gamm ( CRGB orig, float gamma);
CRGB    applyGamma_video_gammaRGB ( CRGB orig, float gammaR, float gammaG, float gammaB);
// The "n" versions below modify their arguments in-place.
CRGB  napplyGamma_video_gamma ( CRGB rgb, float gamma);
CRGB  napplyGamma_video_rammaRGB ( CRGB rgb, float gammaR, float gammaG, float gammaB);
void   napplyGamma_video_count_gamma ( CRGB* rgbarray, unsigned short count, float gamma);
void   napplyGamma_video_count_gammaRGB ( CRGB* rgbarray, unsigned short count, float gammaR, float gammaG, float gammaB);


///@}
#endif
