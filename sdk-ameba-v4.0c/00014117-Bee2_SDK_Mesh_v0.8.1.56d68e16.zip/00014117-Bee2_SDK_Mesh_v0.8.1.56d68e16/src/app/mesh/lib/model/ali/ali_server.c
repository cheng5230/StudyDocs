/**
*****************************************************************************************
*     Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
* @file     ali_server.c
* @brief    Source file for ali model.
* @details  Data types and external functions declaration.
* @author   bill
* @date     2018-5-17
* @version  v1.0
* *************************************************************************************
*/

/* Add Includes here */
#include <string.h>
#include "trace.h"
