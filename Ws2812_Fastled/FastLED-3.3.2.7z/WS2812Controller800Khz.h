#ifndef __WS2812CONTROLLER800KHZ_H
#define __WS2812CONTROOLER800KHZ_H

#include "tuya_adapter_platform.h"
  


#ifdef __cplusplus
}
#endif

#endif

