#include "Blink_demo.h"

// Define the array of leds
CRGB leds[NUM_LEDS];
WS2812Controller800Khz WS2812;
CFastLED fast_led;

extern void lockSinal(void);
extern void unlockSinal(void);


void FastledSetup(void)
{
  WS2812Controller800Khz_init(&WS2812, NUM_LEDS);
  CFastLED_init(&fast_led);
  CFastLED_addLeds(&fast_led, &(WS2812.base.base), leds, NUM_LEDS, 0);
}

void Blinkloop(void)
{
  // Turn the LED on, then pause
  //RGB_SetOnePixelColor(leds,0,Red);
  //RGB_SetOnePixelColor(leds,1,Green);
  //RGB_SetOnePixelColor(leds,2,Blue);
  WaitSemaphore(__ledShow);
  //lockSinal();
  CFastLED_show(&fast_led);
  //unlockSinal();
  CFastLED_delay(1);
  
  // Now turn the LED off, then pause
  //RGB_SetOnePixelColor(leds,0,Black);
  //RGB_SetOnePixelColor(leds,1,Black);
  //RGB_SetOnePixelColor(leds,2,Black);

  //CFastLED_show(&fast_led);
  //CFastLED_delay(500);
}

