#ifndef __INC_CHIPSETS_H
#define __INC_CHIPSETS_H
#include "controller.h"
#include "tuya_adapter_platform.h"

///@file chipsets.h
/// contains the bulk of the definitions for the various LED chipsets supported.

typedef struct
{
  CPixelLEDController base;  
  unsigned char* front_buf;
  unsigned int front_buf_len;
  //int mutex_handle;
  MUTEX_HANDLE mutex_handle;
  int is_front_buf_updated;
}WS2812Controller800Khz;

void WS2812Controller800Khz_showPixels(void* base, PixelController* pixels);

void WS2812Controller800Khz_init(WS2812Controller800Khz* c_this, int num_led);

unsigned short WS2812Controller800Khz_getMaxRefreshRate(); 

#endif
